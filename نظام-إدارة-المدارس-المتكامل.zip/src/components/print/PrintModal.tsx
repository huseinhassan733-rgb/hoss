import React from 'react';
import { Printer, X, Check, Building2, ShieldCheck, Award } from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Student, Voucher, GradeRecord } from '../../types';
import { tafqeet, formatCurrency } from '../../utils/numberToWordsArabic';

export const PrintModal: React.FC = () => {
  const { printModal, closePrintModal, schoolInfo } = useSchool();

  if (!printModal.isOpen || !printModal.payload) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl w-full max-w-2xl border border-slate-300 shadow-2xl overflow-hidden my-6">
        
        {/* Modal Action Bar (Hidden on print) */}
        <div className="no-print p-3.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold">
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>معاينة المستند الرسمي قبل الطباعة</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة المستند الآن</span>
            </button>
            <button
              onClick={closePrintModal}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Canvas */}
        <div className="p-6 sm:p-8 bg-white text-black font-['Cairo'] text-xs leading-relaxed max-h-[80vh] overflow-y-auto print:max-h-none print:overflow-visible print:p-0">
          
          {/* TEMPLATE 1: Official Payment / Receipt Voucher */}
          {printModal.type === 'voucher' && (() => {
            const v = printModal.payload as Voucher;
            const isReceipt = v.type === 'receipt';
            return (
              <div className="border-2 border-slate-800 p-5 rounded-xl space-y-4 relative">
                {/* School Header */}
                <div className="flex items-center justify-between pb-3 border-b-2 border-slate-800 text-center">
                  <div className="text-right text-[11px] leading-tight">
                    <div className="font-bold text-slate-900">{schoolInfo.subName}</div>
                    <div className="font-extrabold text-sm text-slate-900">{schoolInfo.name}</div>
                    <div className="text-slate-600">{schoolInfo.address}</div>
                  </div>

                  <div className="text-center px-3">
                    <div className="w-12 h-12 mx-auto rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xl mb-1">
                      ن
                    </div>
                    <div className="text-[10px] font-bold text-slate-600">{schoolInfo.currentYear}</div>
                  </div>

                  <div className="text-left font-mono text-[11px] leading-tight">
                    <div className="font-bold">التاريخ: {v.date}</div>
                    <div className="font-bold text-emerald-800 text-sm">
                      رقم السند: #{v.voucherNumber}
                    </div>
                  </div>
                </div>

                {/* Title Banner */}
                <div className="text-center py-1">
                  <span className="inline-block px-6 py-1 bg-slate-100 border border-slate-400 rounded-lg text-sm font-black tracking-wide">
                    {isReceipt ? 'سـنـد قـبـض رسـمـي' : 'سـنـد صـرف رسـمـي'}
                  </span>
                </div>

                {/* Amount Box */}
                <div className="flex justify-between items-center bg-slate-50 border border-slate-300 p-2.5 rounded-lg">
                  <span className="font-bold">المبلغ رقماً:</span>
                  <span className="font-mono font-black text-base tabular-nums text-slate-900">
                    {v.amount.toLocaleString()} ريال يمني (YER)
                  </span>
                </div>

                {/* Main Body */}
                <div className="space-y-2.5 text-xs text-slate-800">
                  <div className="flex items-baseline">
                    <span className="font-bold min-w-[130px] shrink-0">
                      {isReceipt ? 'استلمنا من الأخ / ولي الأمر:' : 'يصرف للأخ / الجهة:'}
                    </span>
                    <span className="font-bold text-slate-900 border-b border-dotted border-slate-400 flex-1 pb-0.5">
                      {v.recipientOrPayer}
                    </span>
                  </div>

                  <div className="flex items-baseline">
                    <span className="font-bold min-w-[130px] shrink-0">مبلغ وقدره (كتابةً):</span>
                    <span className="font-semibold text-slate-900 border-b border-dotted border-slate-400 flex-1 pb-0.5">
                      {v.amountInWords || tafqeet(v.amount, 'ريال يمني')}
                    </span>
                  </div>

                  <div className="flex items-baseline">
                    <span className="font-bold min-w-[130px] shrink-0">وذلك مقابل:</span>
                    <span className="text-slate-800 border-b border-dotted border-slate-400 flex-1 pb-0.5">
                      {v.category} {v.notes ? ` - (${v.notes})` : ''}
                    </span>
                  </div>

                  <div className="flex items-baseline">
                    <span className="font-bold min-w-[130px] shrink-0">طريقة الدفع والحساب:</span>
                    <span className="text-slate-800 border-b border-dotted border-slate-400 flex-1 pb-0.5">
                      {v.paymentMethod} · مرحل لحساب ({v.accountTo})
                    </span>
                  </div>
                </div>

                {/* Signatures and School Seal */}
                <div className="pt-6 grid grid-cols-3 text-center text-xs font-bold gap-4">
                  <div>
                    <div className="mb-8">المستلم / المحاسب</div>
                    <div className="border-t border-slate-400 pt-1 text-[11px] text-slate-600">
                      {v.preparedBy}
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center">
                    <div className="w-16 h-16 rounded-full border-2 border-dashed border-emerald-700/60 flex items-center justify-center text-[10px] text-emerald-800 font-bold p-1 text-center rotate-[-12deg]">
                      ختم الإدارة المعتمد
                    </div>
                  </div>

                  <div>
                    <div className="mb-8">المدير العام للمدارس</div>
                    <div className="border-t border-slate-400 pt-1 text-[11px] text-slate-600">
                      أ.د. عبدالجليل الأهدل
                    </div>
                  </div>
                </div>

                {/* Verification Footer */}
                <div className="pt-2 border-t border-slate-200 text-[10px] text-slate-400 text-center flex items-center justify-between">
                  <span>سند مالي إلكتروني معتمد رسمياً</span>
                  <span>هاتف الإدارة: {schoolInfo.phone} - {schoolInfo.phoneAlt}</span>
                </div>
              </div>
            );
          })()}

          {/* TEMPLATE 2: Student ID Card */}
          {printModal.type === 'card' && (() => {
            const s = printModal.payload as Student;
            return (
              <div className="max-w-sm mx-auto border-2 border-emerald-800 rounded-2xl overflow-hidden shadow-lg bg-white">
                {/* Card Top Brand */}
                <div className="bg-emerald-700 text-white p-3 text-center">
                  <div className="text-[10px] font-semibold">{schoolInfo.subName}</div>
                  <div className="font-extrabold text-sm">{schoolInfo.name}</div>
                  <div className="text-[9px] tracking-wider text-emerald-100">بطاقة الطالب المدرسية الرسمية {schoolInfo.currentYear}</div>
                </div>

                {/* Card Body */}
                <div className="p-4 flex gap-3 items-center">
                  <img 
                    src={s.photoUrl} 
                    alt={s.fullName} 
                    className="w-20 h-24 rounded-lg object-cover border-2 border-emerald-600 shrink-0"
                  />

                  <div className="min-w-0 space-y-1 text-xs">
                    <div className="font-bold text-slate-900 text-sm leading-tight">{s.fullName}</div>
                    <div className="text-slate-600"><b className="text-slate-800">الرقم:</b> <span className="font-mono text-emerald-800 font-bold">{s.id}</span></div>
                    <div className="text-slate-600"><b className="text-slate-800">الصف:</b> {s.grade}</div>
                    <div className="text-slate-600"><b className="text-slate-800">الشعبة:</b> ({s.section})</div>
                    <div className="text-slate-600"><b className="text-slate-800">ولي الأمر:</b> {s.parentPhone}</div>
                  </div>
                </div>

                {/* Barcode & Verification */}
                <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[9px] text-slate-500">
                  <div className="font-mono font-bold tracking-widest text-slate-800 text-[10px]">
                    ||| | |||| | |||||| || |
                  </div>
                  <div>توقيع مدير المدرسة والختم</div>
                </div>
              </div>
            );
          })()}

          {/* TEMPLATE 3: Student Admission Registration Form */}
          {printModal.type === 'admission_form' && (() => {
            const s = printModal.payload as Student;
            return (
              <div className="border border-slate-300 p-6 rounded-xl space-y-4">
                <div className="flex justify-between items-center border-b pb-3 text-center">
                  <div className="text-right">
                    <div className="font-bold text-slate-800">{schoolInfo.subName}</div>
                    <div className="font-extrabold text-base text-slate-900">{schoolInfo.name}</div>
                    <div className="text-[11px] text-slate-500">إدارة القبول والتسجيل وشؤون الطلاب</div>
                  </div>
                  <div className="w-14 h-14 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-2xl">
                    ن
                  </div>
                  <div className="text-left font-mono text-xs">
                    <div>الرقم: {s.id}</div>
                    <div>العام: {schoolInfo.currentYear}</div>
                  </div>
                </div>

                <div className="text-center">
                  <h3 className="text-sm font-black inline-block bg-slate-100 px-4 py-1 rounded border border-slate-300">
                    استمارة تسجيل وقيد طالب
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div><b>اسم الطالب الرباعي:</b> {s.fullName}</div>
                  <div><b>الجنس:</b> {s.gender}</div>
                  <div><b>تاريخ ومكان الميلاد:</b> {s.birthDate} ({s.birthPlace})</div>
                  <div><b>المرحلة والصف المقيد به:</b> {s.grade} - شعبة ({s.section})</div>
                  <div><b>اسم ولي الأمر:</b> {s.parentName} ({s.parentRelation})</div>
                  <div><b>هاتف ولي الأمر:</b> {s.parentPhone}</div>
                  <div><b>مهنة ولي الأمر:</b> {s.parentJob}</div>
                  <div><b>العنوان السكني:</b> {s.address}</div>
                </div>

                <div className="p-3 bg-slate-50 border rounded text-[11px] text-slate-600 leading-relaxed">
                  <b>تعهد ولي الأمر:</b> أتعهد أنا ولي أمر الطالب المذكور أعلاه بالالتزام باللوائح والأنظمة المدرسية الصادرة عن المدرسة ووزارة التربية والتعليم، وسداد الرسوم المدرسية المقررة في مواعيدها المحددة.
                </div>

                <div className="pt-4 grid grid-cols-3 text-center font-bold text-xs gap-4">
                  <div>
                    <div className="mb-6">توقيع ولي الأمر</div>
                    <div className="border-t border-slate-300 pt-1 text-[11px] text-slate-500">........................</div>
                  </div>
                  <div>
                    <div className="mb-6">مسجل شؤون الطلاب</div>
                    <div className="border-t border-slate-300 pt-1 text-[11px] text-slate-500">أ. سحر الأكوع</div>
                  </div>
                  <div>
                    <div className="mb-6">مدير عام المدارس والختم</div>
                    <div className="border-t border-slate-300 pt-1 text-[11px] text-slate-500">أ.د. عبدالجليل الأهدل</div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* TEMPLATE 4: Academic Report Card (الشهادة الرسمية) */}
          {printModal.type === 'report_card' && (() => {
            const data = printModal.payload as {
              student: Student;
              grades: GradeRecord[];
              average: number;
              letter: string;
              term: string;
            };
            return (
              <div className="border-2 border-emerald-900 p-6 rounded-2xl space-y-4 bg-white relative">
                {/* Certificate Frame Decor */}
                <div className="flex justify-between items-center border-b-2 border-emerald-800 pb-3">
                  <div className="text-right">
                    <div className="font-bold text-slate-700">{schoolInfo.subName}</div>
                    <div className="font-extrabold text-base text-emerald-900">{schoolInfo.name}</div>
                    <div className="text-[11px] text-slate-500">إدارة الكنترول والاختبارات</div>
                  </div>
                  <div className="text-center">
                    <div className="w-14 h-14 mx-auto rounded-full bg-emerald-800 text-white flex items-center justify-center font-black text-2xl mb-1 shadow-md">
                      ن
                    </div>
                    <div className="text-[10px] font-bold text-emerald-800">{schoolInfo.currentYear}</div>
                  </div>
                  <div className="text-left font-mono text-xs">
                    <div>رقم الطالب: {data.student.id}</div>
                    <div>{data.term}</div>
                  </div>
                </div>

                <div className="text-center">
                  <h3 className="text-base font-black text-slate-900 tracking-wide">
                    إشعار نتيجة درجات الطالب (شهادة رسمية)
                  </h3>
                  <p className="text-slate-600 text-xs mt-1">
                    تشهد إدارة المدارس بأن الطالب/ة: <b className="text-slate-900 text-sm">{data.student.fullName}</b>
                    <br />
                    المقيد بالصف: <b>{data.student.grade}</b> - شعبة (<b>{data.student.section}</b>) قد حقق النتائج التالية:
                  </p>
                </div>

                {/* Grades Table */}
                <table className="w-full text-right border border-slate-300">
                  <thead className="bg-emerald-50 text-emerald-950 font-bold border-b border-slate-300">
                    <tr>
                      <th className="p-2 border-l border-slate-300">المادة الدراسية</th>
                      <th className="p-2 text-center border-l border-slate-300">شهري 1 (20)</th>
                      <th className="p-2 text-center border-l border-slate-300">شهري 2 (20)</th>
                      <th className="p-2 text-center border-l border-slate-300">أنشطة (10)</th>
                      <th className="p-2 text-center border-l border-slate-300">نهائي (50)</th>
                      <th className="p-2 text-center border-l border-slate-300">المجموع (100)</th>
                      <th className="p-2 text-center">التقدير</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {data.grades.map(g => (
                      <tr key={g.id}>
                        <td className="p-2 border-l border-slate-200 font-semibold">{g.subject}</td>
                        <td className="p-2 text-center border-l border-slate-200 font-mono">{g.monthlyScore1}</td>
                        <td className="p-2 text-center border-l border-slate-200 font-mono">{g.monthlyScore2}</td>
                        <td className="p-2 text-center border-l border-slate-200 font-mono">{g.activitiesScore}</td>
                        <td className="p-2 text-center border-l border-slate-200 font-mono">{g.finalExamScore}</td>
                        <td className="p-2 text-center border-l border-slate-200 font-mono font-bold text-slate-900">{g.totalScore}</td>
                        <td className="p-2 text-center font-bold text-[11px] text-emerald-800">{g.gradeLetter}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Final Average & Evaluation */}
                <div className="p-3 bg-slate-50 border border-slate-300 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <span>المعدل العام: <b className="font-mono text-base text-emerald-800 font-black">{data.average}%</b></span>
                    <span>التقدير العام: <b className="text-emerald-800 font-bold">{data.letter}</b></span>
                    <span>النتيجة العامة: <b className="text-slate-900 font-bold">نـاجـح ومـتـفـوق</b></span>
                  </div>
                </div>

                {/* Signatures */}
                <div className="pt-6 grid grid-cols-3 text-center font-bold text-xs gap-4">
                  <div>
                    <div className="mb-6">رئيس لجنة الكنترول</div>
                    <div className="border-t border-slate-300 pt-1 text-[11px] text-slate-600">أ. فؤاد الزبيري</div>
                  </div>
                  <div className="flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full border-2 border-dashed border-emerald-800 flex items-center justify-center text-[10px] text-emerald-900 font-bold rotate-[-10deg]">
                      ختم الكنترول الرسمي
                    </div>
                  </div>
                  <div>
                    <div className="mb-6">مدير عام المدارس</div>
                    <div className="border-t border-slate-300 pt-1 text-[11px] text-slate-600">أ.د. عبدالجليل الأهدل</div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* TEMPLATE 5: Student Roster List */}
          {printModal.type === 'student_list' && (() => {
            const list = printModal.payload as Student[];
            return (
              <div className="space-y-4">
                <div className="text-center border-b pb-2">
                  <h3 className="font-bold text-base">{schoolInfo.name}</h3>
                  <div className="text-xs text-slate-600">كشف بأسماء الطلاب المقيدين للعام الدراسي {schoolInfo.currentYear}</div>
                </div>

                <table className="w-full text-right border text-xs">
                  <thead className="bg-slate-100 font-bold">
                    <tr>
                      <th className="p-2 border">#</th>
                      <th className="p-2 border">رقم الطالب</th>
                      <th className="p-2 border">اسم الطالب الرباعي</th>
                      <th className="p-2 border">الصف والشعبة</th>
                      <th className="p-2 border">ولي الأمر</th>
                      <th className="p-2 border">الهاتف</th>
                    </tr>
                  </thead>
                  <tbody>
                    {list.map((s, idx) => (
                      <tr key={s.id}>
                        <td className="p-2 border font-mono">{idx + 1}</td>
                        <td className="p-2 border font-mono">{s.id}</td>
                        <td className="p-2 border font-bold">{s.fullName}</td>
                        <td className="p-2 border">{s.grade} ({s.section})</td>
                        <td className="p-2 border">{s.parentName}</td>
                        <td className="p-2 border font-mono">{s.parentPhone}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          })()}

        </div>

      </div>
    </div>
  );
};
