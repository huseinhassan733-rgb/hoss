import React from 'react';
import { 
  LayoutDashboard, 
  GraduationCap, 
  Receipt, 
  Calculator, 
  Award, 
  UserCheck, 
  Users, 
  Calendar, 
  BookOpen, 
  Package, 
  FolderArchive, 
  MessageSquare, 
  FileSpreadsheet, 
  Settings, 
  X,
  ChevronLeft,
  Building,
  LogOut
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({ isOpen, onClose }) => {
  const { activeTab, setActiveTab, schoolInfo, currentRole, currentUser, logout } = useSchool();

  const moduleCategories = [
    {
      category: 'الأقسام الرئيسية',
      items: [
        { id: 'dashboard', label: 'لوحة التحكم والمؤشرات', icon: LayoutDashboard },
        { id: 'students', label: 'إدارة الطلاب والشعب', icon: GraduationCap },
        { id: 'fees', label: 'الرسوم المدرسية والأقساط', icon: Receipt },
        { id: 'accounting', label: 'النظام المحاسبي والسندات', icon: Calculator },
        { id: 'grades', label: 'الدرجات والكنترول والشهادات', icon: Award },
        { id: 'attendance', label: 'الحضور والغياب المدرسي', icon: UserCheck },
      ]
    },
    {
      category: 'الكادر الأكاديمي والإداري',
      items: [
        { id: 'staff', label: 'شؤون الموظفين والرواتب', icon: Users },
        { id: 'teachers', label: 'شؤون المعلمين والجدول الدراسي', icon: Calendar },
      ]
    },
    {
      category: 'الخدمات المساندة والأرشفة',
      items: [
        { id: 'library', label: 'المكتبة والإعارات', icon: BookOpen },
        { id: 'warehouse', label: 'المخزن والمستودع المدرسي', icon: Package },
        { id: 'archive', label: 'الأرشيف الإلكتروني والوثائق', icon: FolderArchive },
        { id: 'messages', label: 'الرسائل والإشعارات (واتساب / SMS)', icon: MessageSquare },
      ]
    },
    {
      category: 'التقارير والنظام',
      items: [
        { id: 'reports', label: 'التقارير والطباعة الشاملة', icon: FileSpreadsheet },
        { id: 'settings', label: 'إعدادات المدرسة والنسخ الاحتياطي', icon: Settings },
      ]
    }
  ];

  const handleSelectTab = (tabId: string) => {
    setActiveTab(tabId);
    onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 lg:hidden transition-opacity"
          onClick={onClose}
        />
      )}

      {/* Drawer Container (Sidebar on desktop, off-canvas on mobile) */}
      <aside 
        className={`fixed top-0 bottom-0 right-0 z-50 w-72 sm:w-80 bg-white border-l border-slate-200 flex flex-col transition-transform duration-200 ease-out no-print lg:static lg:translate-x-0 lg:z-10 lg:w-64 xl:w-72 shrink-0 ${
          isOpen ? 'translate-x-0 shadow-2xl' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Drawer Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
              <Building className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900 leading-tight">
                {schoolInfo.name}
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                نظام الإدارة الذكي (نسخة الجوال)
              </div>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg lg:hidden"
            aria-label="إغلاق القائمة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Modules List */}
        <div className="flex-1 overflow-y-auto px-3 py-3 space-y-4 text-right">
          {moduleCategories.map((group, groupIdx) => (
            <div key={groupIdx}>
              <div className="px-2 pb-1.5 text-[11px] font-bold text-slate-400 tracking-wider">
                {group.category}
              </div>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleSelectTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all group ${
                        isActive 
                          ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-600/20' 
                          : 'text-slate-700 hover:bg-slate-100 hover:text-slate-950'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500 group-hover:text-slate-800'}`} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      <ChevronLeft className={`w-3.5 h-3.5 shrink-0 opacity-60 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* User Account & Logout in Sidebar */}
        {currentUser && (
          <div className="p-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80'}
                alt=""
                className="w-8 h-8 rounded-full object-cover border border-slate-200"
              />
              <div className="min-w-0">
                <div className="font-bold text-slate-900 truncate text-xs">{currentUser.name}</div>
                <div className="text-[10px] text-slate-500 truncate">{currentUser.roleLabel}</div>
              </div>
            </div>
            <button
              onClick={() => {
                onClose();
                logout();
              }}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
              title="تسجيل الخروج"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Footer / Status Indicator */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/70 text-[11px] text-slate-500 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
            <span>يعمل بدون إنترنت (محلي)</span>
          </div>
          <span className="font-mono text-[10px] text-slate-400">2026/2027</span>
        </div>
      </aside>
    </>
  );
};
