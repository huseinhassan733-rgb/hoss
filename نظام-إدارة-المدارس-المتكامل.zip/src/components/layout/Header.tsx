import React, { useState } from 'react';
import { 
  Building2, 
  Search, 
  Bell, 
  UserCheck, 
  Menu, 
  ShieldCheck, 
  Printer, 
  CalendarDays,
  Sparkles,
  LogOut,
  User
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { SchoolRole } from '../../types';

interface HeaderProps {
  onOpenMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenMenu }) => {
  const { 
    schoolInfo, 
    currentRole, 
    setCurrentRole, 
    currentUser,
    logout,
    searchQuery, 
    setSearchQuery,
    notifications,
    setActiveTab,
    activeTab
  } = useSchool();

  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const roleLabels: Record<SchoolRole, { title: string; color: string }> = {
    admin: { title: 'مدير النظام (كامل الصلاحيات)', color: 'text-amber-600 bg-amber-50 border-amber-200' },
    principal: { title: 'المدير العام للمدارس', color: 'text-blue-600 bg-blue-50 border-blue-200' },
    accountant: { title: 'المحاسب المالي', color: 'text-emerald-600 bg-emerald-50 border-emerald-200' },
    student_affairs: { title: 'شؤون الطلاب والتسجيل', color: 'text-indigo-600 bg-indigo-50 border-indigo-200' },
    control: { title: 'الكنترول والاختبارات', color: 'text-purple-600 bg-purple-50 border-purple-200' },
    archive: { title: 'الأرشيف والوثائق', color: 'text-teal-600 bg-teal-50 border-teal-200' },
    teacher: { title: 'المعلم (درجات وحضور)', color: 'text-rose-600 bg-rose-50 border-rose-200' },
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 no-print transition-all">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2">
          
          {/* Right Zone (RTL start): Menu button & School Branding */}
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button 
              onClick={onOpenMenu}
              className="p-2 -mr-1 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg lg:hidden transition-colors min-w-[40px] min-h-[40px] flex items-center justify-center"
              title="القائمة الشاملة"
              aria-label="القائمة"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div 
              onClick={() => setActiveTab('dashboard')}
              className="flex items-center gap-2 cursor-pointer select-none truncate"
            >
              <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-black text-sm sm:text-base shrink-0 shadow-sm">
                ن
              </div>
              <div className="min-w-0">
                <h1 className="text-sm sm:text-base font-bold text-slate-900 truncate leading-tight">
                  {schoolInfo.name}
                </h1>
                <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                  <span>{schoolInfo.city}</span>
                  <span>·</span>
                  <span>{schoolInfo.currentYear}</span>
                  <span>·</span>
                  <span className="text-emerald-700 font-semibold">{schoolInfo.currentTerm}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Zone: Quick Search (on md+) */}
          <div className="hidden md:flex items-center flex-1 max-w-xs mx-4">
            <div className="relative w-full">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث سريع عن طالب، سند، موظف..."
                className="w-full pr-9 pl-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Left Zone (RTL end): Role switcher, Notifications, Quick Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            
            {/* Quick role selector */}
            <div className="relative">
              <button 
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${roleLabels[currentRole].color}`}
                title="تغيير صلاحيات المستخدم"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span className="max-w-[85px] sm:max-w-none truncate">
                  {currentRole === 'admin' ? 'المدير العام' : currentRole === 'accountant' ? 'المحاسب' : currentRole === 'student_affairs' ? 'شؤون الطلاب' : currentRole === 'control' ? 'الكنترول' : 'المعلم'}
                </span>
              </button>

              {showRoleMenu && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setShowRoleMenu(false)}
                  />
                  <div className="absolute left-0 mt-1 w-64 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 text-right">
                    
                    {/* Current User Card */}
                    {currentUser && (
                      <div className="p-3 border-b border-slate-100 bg-slate-50/70">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80'}
                            alt=""
                            className="w-8 h-8 rounded-full object-cover border border-slate-200"
                          />
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900 truncate text-xs">{currentUser.name}</div>
                            <div className="text-[10px] text-slate-500 font-mono">@{currentUser.username}</div>
                          </div>
                        </div>
                      </div>
                    )}

                    <div className="px-3 py-1.5 border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase">
                      تبديل الصلاحية النشطة
                    </div>
                    {(Object.keys(roleLabels) as SchoolRole[]).map((role) => (
                      <button
                        key={role}
                        onClick={() => {
                          setCurrentRole(role);
                          setShowRoleMenu(false);
                        }}
                        className={`w-full text-right px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 transition-colors ${currentRole === role ? 'font-bold text-emerald-700 bg-emerald-50/50' : 'text-slate-700'}`}
                      >
                        <span>{roleLabels[role].title}</span>
                        {currentRole === role && <span className="text-emerald-600 font-bold">✓</span>}
                      </button>
                    ))}

                    {/* Logout Option */}
                    <div className="pt-1 mt-1 border-t border-slate-100">
                      <button
                        onClick={() => {
                          setShowRoleMenu(false);
                          logout();
                        }}
                        className="w-full text-right px-3 py-2 text-xs flex items-center gap-2 text-rose-600 hover:bg-rose-50 font-bold transition-colors"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>تسجيل الخروج من النظام</span>
                      </button>
                    </div>

                  </div>
                </>
              )}
            </div>

            {/* Notifications Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifMenu(!showNotifMenu)}
                className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors min-w-[36px] min-h-[36px] flex items-center justify-center"
                title="الإشعارات والرسائل"
                aria-label="الإشعارات"
              >
                <Bell className="w-4 h-4" />
                {notifications.length > 0 && (
                  <span className="absolute top-1 left-1 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white" />
                )}
              </button>

              {showNotifMenu && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setShowNotifMenu(false)}
                  />
                  <div className="absolute left-0 mt-1 w-72 sm:w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-right">
                    <div className="px-3.5 py-1.5 border-b border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800">أحدث الإشعارات</span>
                      <button 
                        onClick={() => {
                          setActiveTab('messages');
                          setShowNotifMenu(false);
                        }}
                        className="text-[11px] text-emerald-600 hover:underline"
                      >
                        عرض الكل
                      </button>
                    </div>
                    <div className="max-h-60 overflow-y-auto divide-y divide-slate-100">
                      {notifications.slice(0, 4).map(n => (
                        <div key={n.id} className="p-3 text-xs hover:bg-slate-50 transition-colors">
                          <div className="font-semibold text-slate-900 mb-0.5">{n.title}</div>
                          <div className="text-slate-500 line-clamp-2 text-[11px]">{n.content}</div>
                          <div className="text-[10px] text-slate-400 mt-1">{n.date} · {n.channel}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Quick Print current view button */}
            <button
              onClick={() => window.print()}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
              title="طباعة الصفحة الحالية"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة</span>
            </button>

          </div>

        </div>

        {/* Mobile Search Bar Row (small screens) */}
        <div className="md:hidden pb-2.5 pt-0.5">
          <div className="relative w-full">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث سريع برقم الطالب، الاسم، السند..."
              className="w-full pr-9 pl-3 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-colors"
            />
          </div>
        </div>
      </div>
    </header>
  );
};
