import React from 'react';
import { 
  LayoutDashboard, 
  GraduationCap, 
  Receipt, 
  Award, 
  Layers
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';

interface BottomNavProps {
  onOpenMore: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ onOpenMore }) => {
  const { activeTab, setActiveTab } = useSchool();

  const navItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard },
    { id: 'students', label: 'الطلاب', icon: GraduationCap },
    { id: 'fees', label: 'الرسوم والسندات', icon: Receipt },
    { id: 'grades', label: 'الدرجات', icon: Award },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 no-print sm:hidden transition-all shadow-[0_-2px_10px_rgba(0,0,0,0.04)]">
      <div className="grid grid-cols-5 items-center h-14 px-1 pb-safe">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center h-full transition-colors relative min-h-[44px] ${
                isActive ? 'text-emerald-700 font-bold' : 'text-slate-500 hover:text-slate-800 font-medium'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4px]' : 'stroke-[1.8px]'}`} />
              <span className="text-[10px] tracking-tight mt-0.5 whitespace-nowrap">
                {item.label}
              </span>
              {isActive && (
                <span className="absolute bottom-1 w-1.5 h-1.5 rounded-full bg-emerald-600" />
              )}
            </button>
          );
        })}

        {/* More / All Modules Button */}
        <button
          onClick={onOpenMore}
          className={`flex flex-col items-center justify-center h-full transition-colors min-h-[44px] ${
            !['dashboard', 'students', 'fees', 'grades'].includes(activeTab)
              ? 'text-emerald-700 font-bold'
              : 'text-slate-500 hover:text-slate-800 font-medium'
          }`}
        >
          <Layers className="w-5 h-5 stroke-[1.8px]" />
          <span className="text-[10px] tracking-tight mt-0.5 whitespace-nowrap">
            كل الأقسام
          </span>
          {!['dashboard', 'students', 'fees', 'grades'].includes(activeTab) && (
            <span className="absolute bottom-1 w-1.5 h-1.5 rounded-full bg-emerald-600" />
          )}
        </button>
      </div>
    </nav>
  );
};
