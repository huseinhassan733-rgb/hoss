import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Lock, 
  User, 
  Eye, 
  EyeOff, 
  ArrowLeft, 
  CheckCircle2, 
  Sparkles,
  Phone,
  HelpCircle,
  KeyRound
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { DEFAULT_USERS } from '../../context/SchoolContext';
import { SchoolRole } from '../../types';

export const LoginScreen: React.FC = () => {
  const { schoolInfo, login } = useSchool();

  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('123456');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setErrorMessage('يرجى إدخال اسم المستخدم أو رقم الهوية');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');

    setTimeout(() => {
      login(username, password);
      setIsLoading(false);
    }, 350);
  };

  const handleQuickLogin = (userItem: typeof DEFAULT_USERS[0]) => {
    setUsername(userItem.username);
    setPassword('123456');
    setIsLoading(true);
    setTimeout(() => {
      login(userItem.username, '123456', userItem.role);
      setIsLoading(false);
    }, 250);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-950 flex flex-col justify-between p-4 sm:p-6 font-['Cairo',sans-serif] text-slate-100 selection:bg-emerald-500 selection:text-white">
      
      {/* Top Header Badge */}
      <div className="max-w-md w-full mx-auto flex items-center justify-between text-xs text-slate-400 pt-2 pb-4">
        <div className="flex items-center gap-1.5 font-medium">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>نظام الإدارة المدرسية الإلكتروني</span>
        </div>
        <div className="font-mono text-[11px] text-slate-400 bg-white/5 px-2.5 py-1 rounded-md border border-white/10">
          {schoolInfo.currentYear}
        </div>
      </div>

      {/* Main Login Card Container */}
      <div className="max-w-md w-full mx-auto my-auto">
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-100 text-slate-900 relative overflow-hidden">
          
          {/* Subtle decorative background glow */}
          <div className="absolute top-0 right-0 left-0 h-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600" />
          
          {/* School Brand & Logo */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-2xl shadow-lg shadow-emerald-600/30 mb-3 border-2 border-emerald-500">
              ن
            </div>
            <div className="text-xs text-emerald-700 font-semibold mb-0.5">
              {schoolInfo.subName}
            </div>
            <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
              {schoolInfo.name}
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              بوابة الدخول الموحدة للكادر الإداري والتعليمي وأولياء الأمور
            </p>
          </div>

          {/* Error Message if any */}
          {errorMessage && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-700 font-bold mb-1.5">
                اسم المستخدم أو الرقم الوظيفي *
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="مثال: admin أو accountant"
                  className="w-full pr-10 pl-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-slate-700 font-bold">
                  كلمة المرور *
                </label>
                <span className="text-[11px] text-slate-400 font-mono">
                  الافتراضية: 123456
                </span>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pr-10 pl-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                />
                <span className="text-slate-600 font-medium text-[11px]">تذكر تسجيل الدخول على هذا الهاتف</span>
              </label>

              <button
                type="button"
                onClick={() => alert('لإعادة ضبط كلمة المرور يرجى التواصل مع إدارة شؤون تكنولوجيا المعلومات بالمدرسة.')}
                className="text-[11px] font-semibold text-emerald-700 hover:underline"
              >
                نسيت كلمة المرور؟
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/25 transition-all mt-2 cursor-pointer"
            >
              {isLoading ? (
                <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>تسجيل الدخول للنظام</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Access Buttons */}
          <div className="mt-6 pt-5 border-t border-slate-100">
            <div className="text-[11px] font-bold text-slate-500 mb-2.5 flex items-center justify-between">
              <span>تسجيل دخول سريع وتجربة الصلاحيات:</span>
              <span className="text-emerald-700 text-[10px] font-normal">بنقرة واحدة</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {DEFAULT_USERS.map((usr) => (
                <button
                  key={usr.id}
                  type="button"
                  onClick={() => handleQuickLogin(usr)}
                  className="p-2 text-right rounded-xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/50 transition-all group flex items-center gap-2 bg-slate-50/70"
                >
                  <img
                    src={usr.avatar}
                    alt={usr.name}
                    className="w-7 h-7 rounded-full object-cover shrink-0 border border-slate-200 group-hover:border-emerald-500"
                  />
                  <div className="min-w-0">
                    <div className="font-bold text-slate-800 truncate text-[11px]">{usr.name}</div>
                    <div className="text-[10px] text-slate-500 truncate">{usr.roleLabel.split('(')[0]}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Footer Info & Contacts */}
      <div className="max-w-md w-full mx-auto text-center text-xs text-slate-400 py-3 space-y-1">
        <div className="flex items-center justify-center gap-3 text-[11px]">
          <span className="flex items-center gap-1">
            <Phone className="w-3 h-3 text-emerald-400" />
            <span>هاتف الإدارة: {schoolInfo.phone}</span>
          </span>
          <span>·</span>
          <span>واتساب: {schoolInfo.phoneAlt}</span>
        </div>
        <div className="text-[10px] text-slate-500">
          يعمل النظام محلياً مع تشفير البيانات والنسخ الاحتياطي التلقائي
        </div>
      </div>

    </div>
  );
};
