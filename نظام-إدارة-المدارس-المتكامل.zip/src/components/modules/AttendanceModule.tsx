import React, { useState, useMemo } from 'react';
import { 
  UserCheck, 
  Calendar, 
  Check, 
  X, 
  Clock, 
  FileText, 
  Users, 
  AlertTriangle, 
  Save, 
  Send 
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { allGrades, allSections } from '../../data/initialData';
import { AttendanceRecord } from '../../types';

export const AttendanceModule: React.FC = () => {
  const { 
    students, 
    employees, 
    attendance, 
    markBatchAttendance, 
    schoolInfo, 
    showToast 
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'students' | 'employees'>('students');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedGrade, setSelectedGrade] = useState<string>('تاسع أساسي');
  const [selectedSection, setSelectedSection] = useState<string>('أ');

  // Filter students for selected grade/section
  const classStudents = useMemo(() => {
    return students.filter(s => s.grade === selectedGrade && s.section === selectedSection);
  }, [students, selectedGrade, selectedSection]);

  // Current attendance map for students
  const [studentStatusMap, setStudentStatusMap] = useState<Record<string, AttendanceRecord['status']>>({});
  const [notesMap, setNotesMap] = useState<Record<string, string>>({});

  // Initialize or fetch attendance
  React.useEffect(() => {
    const map: Record<string, AttendanceRecord['status']> = {};
    const nMap: Record<string, string> = {};

    classStudents.forEach(stu => {
      const rec = attendance.find(a => a.date === selectedDate && a.type === 'student' && a.targetId === stu.id);
      if (rec) {
        map[stu.id] = rec.status;
        nMap[stu.id] = rec.notes || '';
      } else {
        map[stu.id] = 'حاضر'; // Default to present for quick mobile efficiency
        nMap[stu.id] = '';
      }
    });

    setStudentStatusMap(map);
    setNotesMap(nMap);
  }, [classStudents, selectedDate, attendance]);

  // Quick set all to present
  const handleMarkAllPresent = () => {
    const map: Record<string, AttendanceRecord['status']> = {};
    classStudents.forEach(s => {
      map[s.id] = 'حاضر';
    });
    setStudentStatusMap(map);
    showToast('تم تعيين جميع الطلاب حاضرين');
  };

  const handleSaveStudentAttendance = () => {
    const items = classStudents.map(stu => ({
      targetId: stu.id,
      status: studentStatusMap[stu.id] || 'حاضر',
      notes: notesMap[stu.id],
      grade: stu.grade,
      section: stu.section
    }));

    markBatchAttendance(selectedDate, 'student', items);
  };

  // Employee attendance map
  const [empStatusMap, setEmpStatusMap] = useState<Record<string, AttendanceRecord['status']>>({});
  React.useEffect(() => {
    const map: Record<string, AttendanceRecord['status']> = {};
    employees.forEach(emp => {
      const rec = attendance.find(a => a.date === selectedDate && a.type === 'employee' && a.targetId === emp.id);
      map[emp.id] = rec ? rec.status : 'حاضر';
    });
    setEmpStatusMap(map);
  }, [employees, selectedDate, attendance]);

  const handleSaveEmployeeAttendance = () => {
    const items = employees.map(emp => ({
      targetId: emp.id,
      status: empStatusMap[emp.id] || 'حاضر'
    }));
    markBatchAttendance(selectedDate, 'employee', items);
  };

  const handleNotifyAbsentParent = (studentName: string, phone: string) => {
    const text = encodeURIComponent(
      `المكرم ولي أمر الطالب/ة: ${studentName}\nتحية طيبة من إدارة ${schoolInfo.name}،\nنود إحاطتكم بغياب ابنكم/ابنتكم عن الدوام المدرسي لتاريخ ${selectedDate}.\nيرجى التواصل مع المدرسة لتوضيح العذر ومتابعة الدروس.`
    );
    window.open(`https://wa.me/967${phone}?text=${text}`, '_blank');
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Top Controller */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-emerald-600" />
              <span>نظام الحضور والغياب اليومي</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              رصد الحضور السريع، الأعذار، وإشعارات الغياب الفورية لأولياء الأمور
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setActiveTab('students')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeTab === 'students' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              حضور الطلاب
            </button>
            <button
              onClick={() => setActiveTab('employees')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeTab === 'employees' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              حضور الموظفين والكادر
            </button>
          </div>
        </div>

        {/* Date and Grade Filter */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">تاريخ التحضير</label>
            <input 
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
            />
          </div>

          {activeTab === 'students' && (
            <>
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">الصف</label>
                <select
                  value={selectedGrade}
                  onChange={(e) => setSelectedGrade(e.target.value)}
                  className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
                >
                  {allGrades.map(g => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">الشعبة</label>
                <select
                  value={selectedSection}
                  onChange={(e) => setSelectedSection(e.target.value)}
                  className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
                >
                  {allSections.map(s => (
                    <option key={s} value={s}>شعبة ({s})</option>
                  ))}
                </select>
              </div>
            </>
          )}
        </div>
      </div>

      {/* STUDENT ATTENDANCE TAB */}
      {activeTab === 'students' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs space-y-3">
          <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="font-bold text-slate-800">
              تحضير طلاب: {selectedGrade} (شعبة {selectedSection}) · {selectedDate}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleMarkAllPresent}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg text-xs"
              >
                تحديد الكل حاضر
              </button>
              <button
                onClick={handleSaveStudentAttendance}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
              >
                <Save className="w-3.5 h-3.5" />
                <span>حفظ التحضير</span>
              </button>
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {classStudents.map(student => {
              const status = studentStatusMap[student.id] || 'حاضر';
              return (
                <div key={student.id} className="p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <img src={student.photoUrl} alt="" className="w-9 h-9 rounded-full object-cover border" />
                    <div>
                      <div className="font-bold text-slate-900">{student.fullName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {student.id} · ولي الأمر: {student.parentPhone}
                      </div>
                    </div>
                  </div>

                  {/* Status Toggle Buttons */}
                  <div className="flex items-center gap-1.5 self-end sm:self-auto">
                    <button
                      onClick={() => setStudentStatusMap(prev => ({ ...prev, [student.id]: 'حاضر' }))}
                      className={`px-2.5 py-1 rounded font-bold transition-colors ${
                        status === 'حاضر' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      حاضر
                    </button>
                    <button
                      onClick={() => setStudentStatusMap(prev => ({ ...prev, [student.id]: 'غائب' }))}
                      className={`px-2.5 py-1 rounded font-bold transition-colors ${
                        status === 'غائب' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      غائب
                    </button>
                    <button
                      onClick={() => setStudentStatusMap(prev => ({ ...prev, [student.id]: 'متأخر' }))}
                      className={`px-2.5 py-1 rounded font-bold transition-colors ${
                        status === 'متأخر' ? 'bg-amber-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      متأخر
                    </button>
                    <button
                      onClick={() => setStudentStatusMap(prev => ({ ...prev, [student.id]: 'معذور' }))}
                      className={`px-2.5 py-1 rounded font-bold transition-colors ${
                        status === 'معذور' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      معذور
                    </button>

                    {status === 'غائب' && (
                      <button
                        onClick={() => handleNotifyAbsentParent(student.fullName, student.parentPhone)}
                        className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-md transition-colors mr-1"
                        title="إرسال إشعار غياب لولي الأمر عبر واتساب"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* EMPLOYEE ATTENDANCE TAB */}
      {activeTab === 'employees' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs space-y-3">
          <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="font-bold text-slate-800">
              تسجيل حضور الكادر التعليمي والإداري · {selectedDate}
            </div>
            <button
              onClick={handleSaveEmployeeAttendance}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Save className="w-3.5 h-3.5" />
              <span>حفظ حضور الكادر</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {employees.map(emp => {
              const status = empStatusMap[emp.id] || 'حاضر';
              return (
                <div key={emp.id} className="p-3 flex items-center justify-between hover:bg-slate-50">
                  <div>
                    <div className="font-bold text-slate-900">{emp.fullName}</div>
                    <div className="text-[11px] text-slate-500">{emp.role} · {emp.phone}</div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setEmpStatusMap(prev => ({ ...prev, [emp.id]: 'حاضر' }))}
                      className={`px-3 py-1 rounded font-bold ${
                        status === 'حاضر' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      حاضر
                    </button>
                    <button
                      onClick={() => setEmpStatusMap(prev => ({ ...prev, [emp.id]: 'غائب' }))}
                      className={`px-3 py-1 rounded font-bold ${
                        status === 'غائب' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      غائب
                    </button>
                    <button
                      onClick={() => setEmpStatusMap(prev => ({ ...prev, [emp.id]: 'متأخر' }))}
                      className={`px-3 py-1 rounded font-bold ${
                        status === 'متأخر' ? 'bg-amber-600 text-white' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      متأخر
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
};
