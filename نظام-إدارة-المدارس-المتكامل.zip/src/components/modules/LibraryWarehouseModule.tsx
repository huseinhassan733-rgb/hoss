import React, { useState } from 'react';
import { 
  BookOpen, 
  Package, 
  Plus, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Search, 
  CheckCircle2, 
  RotateCcw,
  AlertTriangle,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { LibraryBook, InventoryItem } from '../../types';

export const LibraryWarehouseModule: React.FC = () => {
  const { 
    libraryBooks, 
    borrowBook, 
    returnBook, 
    addBook, 
    inventory, 
    adjustStock, 
    addInventoryItem,
    showToast 
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'library' | 'warehouse'>('library');
  
  // Library Modals
  const [isBorrowModalOpen, setIsBorrowModalOpen] = useState(false);
  const [selectedBookForBorrow, setSelectedBookForBorrow] = useState<LibraryBook | null>(null);
  const [borrowerName, setBorrowerName] = useState('');
  const [borrowerType, setBorrowerType] = useState<'طالب' | 'معلم'>('طالب');
  const [borrowDays, setBorrowDays] = useState(14);

  // Add Book Modal
  const [isAddBookOpen, setIsAddBookOpen] = useState(false);
  const [newBook, setNewBook] = useState({ title: '', author: '', category: 'إسلامية', copiesTotal: 5 });

  // Warehouse Modals
  const [isAdjustStockOpen, setIsAdjustStockOpen] = useState(false);
  const [selectedInventoryItem, setSelectedInventoryItem] = useState<InventoryItem | null>(null);
  const [stockChangeQty, setStockChangeQty] = useState(10);
  const [stockChangeType, setStockChangeType] = useState<'in' | 'out'>('in');

  const handleBorrowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBookForBorrow || !borrowerName.trim()) return;

    borrowBook(selectedBookForBorrow.id, borrowerName, borrowerType, borrowDays);
    setIsBorrowModalOpen(false);
    setBorrowerName('');
  };

  const handleAddBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBook.title.trim()) return;
    addBook({
      title: newBook.title,
      author: newBook.author,
      category: newBook.category,
      copiesTotal: Number(newBook.copiesTotal),
      copiesAvailable: Number(newBook.copiesTotal)
    });
    setIsAddBookOpen(false);
    setNewBook({ title: '', author: '', category: 'إسلامية', copiesTotal: 5 });
  };

  const handleAdjustStockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInventoryItem || stockChangeQty <= 0) return;

    const diff = stockChangeType === 'in' ? stockChangeQty : -stockChangeQty;
    adjustStock(selectedInventoryItem.id, diff);
    setIsAdjustStockOpen(false);
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Header with Switcher */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              {activeTab === 'library' ? (
                <BookOpen className="w-5 h-5 text-emerald-600" />
              ) : (
                <Package className="w-5 h-5 text-emerald-600" />
              )}
              <span>{activeTab === 'library' ? 'المكتبة المدرسية والإعارات' : 'المخزن والمستودع المدرسي'}</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              {activeTab === 'library' ? 'فهرسة الكتب، متابعة الإعارات والتسليم' : 'جرد المقررات، القرطاسية، والأثاث مع حركات التوريد والصرف'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'library' ? (
              <button
                onClick={() => setIsAddBookOpen(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة كتاب جديد</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setSelectedInventoryItem(inventory[0]);
                  setIsAdjustStockOpen(true);
                }}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
              >
                <Plus className="w-4 h-4" />
                <span>حركة توريد / صرف</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setActiveTab('library')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeTab === 'library' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            المكتبة والكتب ({libraryBooks.length})
          </button>
          <button
            onClick={() => setActiveTab('warehouse')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeTab === 'warehouse' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            أصناف المستودع والجرد ({inventory.length})
          </button>
        </div>
      </div>

      {/* LIBRARY TAB */}
      {activeTab === 'library' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {libraryBooks.map(book => {
              const activeLoans = book.loans.filter(l => l.status === 'معار');
              return (
                <div key={book.id} className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs flex flex-col justify-between space-y-2.5">
                  <div>
                    <div className="text-[10px] text-emerald-700 font-semibold mb-1">{book.category}</div>
                    <div className="font-bold text-slate-900 text-sm leading-snug">{book.title}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">المؤلف: {book.author}</div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                    <span className="font-mono text-slate-600">المتاح: <b className="text-emerald-700">{book.copiesAvailable}</b> / {book.copiesTotal}</span>
                    <button
                      disabled={book.copiesAvailable <= 0}
                      onClick={() => {
                        setSelectedBookForBorrow(book);
                        setIsBorrowModalOpen(true);
                      }}
                      className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 disabled:opacity-40 rounded font-bold transition-colors"
                    >
                      إعارة كتاب
                    </button>
                  </div>

                  {/* Active Loans if any */}
                  {activeLoans.length > 0 && (
                    <div className="pt-1 text-[10px] text-slate-500 bg-slate-50 p-2 rounded">
                      <span className="font-semibold text-slate-700 block mb-0.5">الإعارات الحالية:</span>
                      {activeLoans.map(loan => (
                        <div key={loan.id} className="flex items-center justify-between py-0.5">
                          <span>{loan.borrowerName}</span>
                          <button
                            onClick={() => returnBook(book.id, loan.id)}
                            className="text-emerald-700 hover:underline font-bold flex items-center gap-0.5"
                          >
                            <RotateCcw className="w-2.5 h-2.5" />
                            <span>استرجاع</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* WAREHOUSE TAB */}
      {activeTab === 'warehouse' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <table className="w-full text-right">
            <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3">اسم الصنف والمستلزم</th>
                <th className="p-3">التصنيف</th>
                <th className="p-3 text-center">الرصيد المتبقي</th>
                <th className="p-3 text-center">الحد الأدنى الحرج</th>
                <th className="p-3 text-left">سعر التكلفة التقديري</th>
                <th className="p-3 text-center">إجراء سريع</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {inventory.map(item => {
                const isCritical = item.quantity <= item.minThreshold;
                return (
                  <tr key={item.id} className="hover:bg-slate-50">
                    <td className="p-3 font-sans font-bold text-slate-900">
                      {item.name}
                    </td>
                    <td className="p-3 font-sans text-slate-600">{item.category}</td>
                    <td className="p-3 text-center font-bold text-sm">
                      <span className={isCritical ? 'text-rose-600' : 'text-slate-900'}>
                        {item.quantity} {item.unit}
                      </span>
                      {isCritical && (
                        <span className="block font-sans text-[10px] text-rose-500 font-semibold">
                          رصيد حرج!
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-center text-slate-500">{item.minThreshold} {item.unit}</td>
                    <td className="p-3 text-left font-bold text-slate-800 tabular-nums">
                      {item.unitPrice.toLocaleString()} ر.ي
                    </td>
                    <td className="p-3 font-sans text-center">
                      <button
                        onClick={() => {
                          setSelectedInventoryItem(item);
                          setIsAdjustStockOpen(true);
                        }}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-[11px] transition-colors"
                      >
                        صرف / توريد
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* MODAL: Borrow Book */}
      {isBorrowModalOpen && selectedBookForBorrow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">إعارة كتاب: {selectedBookForBorrow.title}</h3>
              <button onClick={() => setIsBorrowModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleBorrowSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">اسم المستعير (طالب / معلم) *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: أسامة محمد الحميري"
                  value={borrowerName}
                  onChange={(e) => setBorrowerName(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">صفة المستعير</label>
                  <select
                    value={borrowerType}
                    onChange={(e) => setBorrowerType(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option value="طالب">طالب مدرسي</option>
                    <option value="معلم">معلم / كادر إداري</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">مدة الإعارة (أيام)</label>
                  <input 
                    type="number"
                    min="1"
                    max="60"
                    value={borrowDays}
                    onChange={(e) => setBorrowDays(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBorrowModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  تسجيل الإعارة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Add Book */}
      {isAddBookOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">إضافة كتاب إلى فهرس المكتبة</h3>
              <button onClick={() => setIsAddBookOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddBookSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">عنوان الكتاب *</label>
                <input 
                  type="text" 
                  required
                  value={newBook.title}
                  onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">المؤلف</label>
                <input 
                  type="text" 
                  value={newBook.author}
                  onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">التصنيف</label>
                  <input 
                    type="text" 
                    value={newBook.category}
                    onChange={(e) => setNewBook({ ...newBook, category: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">عدد النسخ</label>
                  <input 
                    type="number" 
                    min="1"
                    value={newBook.copiesTotal}
                    onChange={(e) => setNewBook({ ...newBook, copiesTotal: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddBookOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  حفظ الكتاب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Adjust Inventory Stock */}
      {isAdjustStockOpen && selectedInventoryItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">حركة مخزنية: {selectedInventoryItem.name}</h3>
              <button onClick={() => setIsAdjustStockOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAdjustStockSubmit} className="space-y-3">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStockChangeType('in')}
                  className={`flex-1 py-2 rounded-lg font-bold flex items-center justify-center gap-1.5 ${
                    stockChangeType === 'in' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  <ArrowDownLeft className="w-4 h-4" />
                  <span>توريد (+) للمخزن</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStockChangeType('out')}
                  className={`flex-1 py-2 rounded-lg font-bold flex items-center justify-center gap-1.5 ${
                    stockChangeType === 'out' ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>صرف (-) من المخزن</span>
                </button>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">
                  الكمية ({selectedInventoryItem.unit}) *
                </label>
                <input 
                  type="number"
                  required
                  min="1"
                  value={stockChangeQty}
                  onChange={(e) => setStockChangeQty(Number(e.target.value))}
                  className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold text-base"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAdjustStockOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  تأكيد الحركة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
