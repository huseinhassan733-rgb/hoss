import React, { useState } from 'react';
import { 
  Settings, 
  Building2, 
  Save, 
  Download, 
  Upload, 
  RefreshCw, 
  CheckCircle2, 
  ShieldCheck, 
  Phone, 
  MapPin, 
  Calendar,
  AlertTriangle
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';

export const SettingsModule: React.FC = () => {
  const { 
    schoolInfo, 
    updateSchoolInfo, 
    exportDatabaseToJson, 
    importDatabaseFromJson, 
    resetDatabase,
    showToast 
  } = useSchool();

  const [formData, setFormData] = useState({
    name: schoolInfo.name,
    subName: schoolInfo.subName,
    phone: schoolInfo.phone,
    phoneAlt: schoolInfo.phoneAlt,
    email: schoolInfo.email,
    city: schoolInfo.city,
    address: schoolInfo.address,
    currentYear: schoolInfo.currentYear,
    currentTerm: schoolInfo.currentTerm,
    seal: schoolInfo.seal
  });

  const handleInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSchoolInfo(formData);
  };

  const handleDownloadBackup = () => {
    const jsonStr = exportDatabaseToJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `نسخة_احتياطية_مدرسة_النهضة_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('تم تحميل النسخة الاحتياطية لقاعدة البيانات بنجاح');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        importDatabaseFromJson(content);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs max-w-4xl mx-auto">
      
      {/* Top Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-600" />
          <span>إعدادات المدرسة والبيانات الأساسية</span>
        </h2>
        <p className="text-slate-500 text-[11px] mt-0.5">
          تعديل الترويسة الرسمية، أرقام التواصل، الفروع، وإدارة النسخ الاحتياطي لقاعدة البيانات
        </p>
      </div>

      {/* Basic Info Form */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="font-bold text-slate-800 text-sm mb-4 pb-2 border-b border-slate-100 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-emerald-600" />
          <span>بيانات الترويسة المدرسية الرسمية (للطباعة والسندات)</span>
        </div>

        <form onSubmit={handleInfoSubmit} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-600 mb-1">اسم المدرسة الأهلية *</label>
              <input 
                type="text" 
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-600 mb-1">الجهة المشرفة والوزارة</label>
              <input 
                type="text" 
                value={formData.subName}
                onChange={(e) => setFormData({ ...formData, subName: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-600 mb-1">المدينة والمحافظة</label>
              <input 
                type="text" 
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-600 mb-1">الهاتف الثابت</label>
              <input 
                type="text" 
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-600 mb-1">الجوال / واتساب الإدارة</label>
              <input 
                type="text" 
                value={formData.phoneAlt}
                onChange={(e) => setFormData({ ...formData, phoneAlt: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-600 mb-1">العنوان التفصيلي</label>
            <input 
              type="text" 
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full p-2 border border-slate-300 rounded-lg text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-600 mb-1">العام الدراسي الحالي</label>
              <input 
                type="text" 
                value={formData.currentYear}
                onChange={(e) => setFormData({ ...formData, currentYear: e.target.value })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-600 mb-1">الفصل الدراسي النشط</label>
              <select
                value={formData.currentTerm}
                onChange={(e) => setFormData({ ...formData, currentTerm: e.target.value as any })}
                className="w-full p-2 border border-slate-300 rounded-lg text-xs font-bold"
              >
                <option value="الفصل الأول">الفصل الدراسي الأول</option>
                <option value="الفصل الثاني">الفصل الدراسي الثاني</option>
              </select>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-end">
            <button
              type="submit"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Save className="w-4 h-4" />
              <span>حفظ التعديلات</span>
            </button>
          </div>
        </form>
      </div>

      {/* Backup and Data Restore */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="font-bold text-slate-800 text-sm pb-2 border-b border-slate-100 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>الأرشفة وقاعدة البيانات والنسخ الاحتياطي (Backup)</span>
        </div>

        <p className="text-slate-600 text-xs leading-relaxed">
          النظام يعمل محلياً في متصفح الجوال أو الكمبيوتر دون الحاجة للاتصال بالإنترنت. لحماية بياناتك من الضياع أو لنقلها لجهاز آخر، يرجى تحميل نسخة احتياطية بشكل دوري.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {/* Download JSON Backup */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
            <div>
              <div className="font-bold text-slate-900 text-xs mb-1">تصدير نسخة احتياطية كاملة</div>
              <div className="text-[11px] text-slate-500">حفظ كافة الطلاب، السندات، الحسابات والدرجات في ملف واحد</div>
            </div>

            <button
              onClick={handleDownloadBackup}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>تحميل نسخة احتياطية (JSON)</span>
            </button>
          </div>

          {/* Restore JSON Backup */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
            <div>
              <div className="font-bold text-slate-900 text-xs mb-1">استعادة قاعدة بيانات سابقة</div>
              <div className="text-[11px] text-slate-500">استيراد ملف نسخة احتياطية (JSON) واسترجاع السجلات فوراً</div>
            </div>

            <label className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer transition-colors">
              <Upload className="w-4 h-4" />
              <span>استيراد ملف النسخة الاحتياطية</span>
              <input 
                type="file" 
                accept=".json" 
                onChange={handleFileUpload} 
                className="hidden" 
              />
            </label>
          </div>
        </div>

        {/* Factory Reset */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="font-bold text-rose-700 text-xs">استعادة البيانات النموذجية الأولية</div>
            <div className="text-[11px] text-slate-400">إعادة ضبط النظام إلى حالته الافتراضية مع عينات البيانات اليمنية</div>
          </div>

          <button
            onClick={() => {
              if (window.confirm('هل أنت متأكد من رغبتك في استعادة البيانات الافتراضية؟ سيتم مسح أي تعديلات غير محفوظة في نسخة احتياطية.')) {
                resetDatabase();
              }
            }}
            className="px-3 py-1.5 border border-rose-200 text-rose-700 hover:bg-rose-50 rounded-lg font-semibold flex items-center gap-1 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>إعادة الضبط</span>
          </button>
        </div>
      </div>

    </div>
  );
};
