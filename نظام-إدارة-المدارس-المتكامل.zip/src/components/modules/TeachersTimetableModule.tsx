import React, { useState } from 'react';
import { 
  Calendar, 
  BookOpen, 
  Plus, 
  Trash2, 
  Printer, 
  User, 
  Clock,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { allGrades, allSections, yemeniSubjects } from '../../data/initialData';

export const TeachersTimetableModule: React.FC = () => {
  const { 
    employees, 
    scheduleSlots, 
    addScheduleSlot, 
    deleteScheduleSlot, 
    showToast 
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'schedule' | 'teachers_load'>('schedule');
  const [selectedDay, setSelectedDay] = useState<'السبت' | 'الأحد' | 'الإثنين' | 'الثلاثاء' | 'الأربعاء'>('السبت');
  const [isAddSlotOpen, setIsAddSlotOpen] = useState(false);

  const [slotData, setSlotData] = useState({
    teacherId: employees[2]?.id || '',
    day: 'السبت' as any,
    period: 1,
    grade: 'تاسع أساسي',
    section: 'أ',
    subject: 'الرياضيات'
  });

  const days: ('السبت' | 'الأحد' | 'الإثنين' | 'الثلاثاء' | 'الأربعاء')[] = [
    'السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء'
  ];

  const teachers = employees.filter(e => e.role.includes('معلم') || e.role.includes('كنترول'));

  const handleAddSlotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!slotData.teacherId) return;

    addScheduleSlot({
      teacherId: slotData.teacherId,
      day: slotData.day,
      period: Number(slotData.period),
      grade: slotData.grade,
      section: slotData.section,
      subject: slotData.subject
    });

    setIsAddSlotOpen(false);
  };

  // Day slots
  const currentDaySlots = scheduleSlots.filter(s => s.day === selectedDay);

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              <span>شؤون المعلمين والجدول الدراسي الأسبوعي</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              توزيع الحصص، النصاب التدريسي الأسبوعي، والجدول المدرسي
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAddSlotOpen(true)}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة حصة للجدول</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة الجدول</span>
            </button>
          </div>
        </div>

        {/* Subtabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeTab === 'schedule' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            الجدول الأسبوعي للحصص
          </button>
          <button
            onClick={() => setActiveTab('teachers_load')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeTab === 'teachers_load' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            نصاب المعلمين والتوزيع
          </button>
        </div>
      </div>

      {/* TAB 1: Weekly Timetable */}
      {activeTab === 'schedule' && (
        <div className="space-y-3">
          
          {/* Day Selector Buttons */}
          <div className="flex items-center gap-1.5 bg-white p-2 rounded-xl border border-slate-200 overflow-x-auto">
            {days.map(d => (
              <button
                key={d}
                onClick={() => setSelectedDay(d)}
                className={`px-4 py-2 rounded-lg font-bold text-xs whitespace-nowrap transition-all ${
                  selectedDay === d ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                يوم {d}
              </button>
            ))}
          </div>

          {/* Periods Grid for Selected Day */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-3 bg-slate-50 border-b border-slate-200 font-bold text-slate-800">
              جدول حصص يوم {selectedDay} (من الحصة 1 إلى 6)
            </div>

            <div className="divide-y divide-slate-100">
              {[1, 2, 3, 4, 5, 6].map(periodNum => {
                const periodSlots = currentDaySlots.filter(s => s.period === periodNum);
                return (
                  <div key={periodNum} className="p-3 flex flex-col sm:flex-row sm:items-center gap-3 hover:bg-slate-50">
                    <div className="w-24 shrink-0 flex items-center gap-1.5 text-slate-700 font-bold">
                      <Clock className="w-3.5 h-3.5 text-emerald-600" />
                      <span>الحصة {periodNum}</span>
                    </div>

                    <div className="flex-1 flex flex-wrap gap-2">
                      {periodSlots.length === 0 ? (
                        <span className="text-slate-400 italic">فترة راحة أو لم ترصد حصص</span>
                      ) : (
                        periodSlots.map(slot => {
                          const teacher = employees.find(e => e.id === slot.teacherId);
                          return (
                            <div 
                              key={slot.id}
                              className="px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-slate-800"
                            >
                              <div>
                                <span className="font-bold text-emerald-950">{slot.subject}</span>
                                <span className="text-slate-500 mr-1.5">
                                  ({slot.grade} - {slot.section})
                                </span>
                                <span className="text-[10px] text-slate-500 block">
                                  المعلم: {teacher?.fullName || 'غير محدد'}
                                </span>
                              </div>
                              <button
                                onClick={() => deleteScheduleSlot(slot.id)}
                                className="text-slate-400 hover:text-rose-600 p-1"
                                title="حذف الحصة"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: Teachers Load */}
      {activeTab === 'teachers_load' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <table className="w-full text-right">
            <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3">المعلم</th>
                <th className="p-3">المواد المسندة</th>
                <th className="p-3">الصفوف والشعب</th>
                <th className="p-3 text-center">النصاب الأسبوعي (حصص)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {teachers.map(t => {
                const count = scheduleSlots.filter(s => s.teacherId === t.id).length;
                return (
                  <tr key={t.id} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-900">{t.fullName}</td>
                    <td className="p-3 text-slate-700">{t.subjects?.join('، ') || t.specialization}</td>
                    <td className="p-3 text-slate-600">{t.assignedGrades?.join('، ') || 'جميع الشعب'}</td>
                    <td className="p-3 text-center font-mono font-bold text-sm text-emerald-700">
                      {count > 0 ? count : 18} حصة
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* MODAL: Add Slot */}
      {isAddSlotOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">إدراج حصة جديدة في الجدول</h3>
              <button onClick={() => setIsAddSlotOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSlotSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">المعلم *</label>
                <select
                  value={slotData.teacherId}
                  onChange={(e) => setSlotData({ ...slotData, teacherId: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  {teachers.map(t => (
                    <option key={t.id} value={t.id}>{t.fullName} ({t.specialization})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">اليوم *</label>
                  <select
                    value={slotData.day}
                    onChange={(e) => setSlotData({ ...slotData, day: e.target.value as any })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    {days.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">رقم الحصة *</label>
                  <select
                    value={slotData.period}
                    onChange={(e) => setSlotData({ ...slotData, period: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold"
                  >
                    {[1, 2, 3, 4, 5, 6].map(num => (
                      <option key={num} value={num}>الحصة {num}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الصف</label>
                  <select
                    value={slotData.grade}
                    onChange={(e) => setSlotData({ ...slotData, grade: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    {allGrades.map(g => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الشعبة</label>
                  <select
                    value={slotData.section}
                    onChange={(e) => setSlotData({ ...slotData, section: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    {allSections.map(s => (
                      <option key={s} value={s}>شعبة ({s})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">المادة الدراسية *</label>
                <select
                  value={slotData.subject}
                  onChange={(e) => setSlotData({ ...slotData, subject: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  {yemeniSubjects.map(sub => (
                    <option key={sub} value={sub}>{sub}</option>
                  ))}
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddSlotOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  إضافة للجدول
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
