import React, { useState, useMemo } from 'react';
import { 
  Receipt, 
  Search, 
  Filter, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Printer, 
  Plus, 
  Calendar, 
  CreditCard,
  Percent,
  TrendingDown,
  ArrowDownLeft,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { formatCurrency } from '../../utils/numberToWordsArabic';
import { initialFeeItems } from '../../data/initialData';

export const FeesModule: React.FC = () => {
  const { 
    students, 
    feePlans, 
    feeItems, 
    createVoucher, 
    schoolInfo, 
    openPrintModal,
    showToast 
  } = useSchool();

  const [activeSubTab, setActiveSubTab] = useState<'plans' | 'types' | 'arrears'>('plans');
  const [filterStage, setFilterStage] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchStudent, setSearchStudent] = useState('');

  // Quick Pay Modal State
  const [paymentModal, setPaymentModal] = useState<{
    isOpen: boolean;
    studentId: string;
    studentName: string;
    installmentTitle: string;
    amountToPay: number;
    paymentMethod: 'نقداً - الصندوق' | 'بنك الكريمي' | 'حوالة مصرفية';
  } | null>(null);

  // Filtered Fee Plans
  const filteredPlans = useMemo(() => {
    return feePlans.map(plan => {
      const student = students.find(s => s.id === plan.studentId);
      return { plan, student };
    }).filter(({ plan, student }) => {
      if (!student) return false;

      const matchSearch = searchStudent === '' || 
        student.fullName.includes(searchStudent) ||
        student.id.toLowerCase().includes(searchStudent.toLowerCase()) ||
        student.grade.includes(searchStudent);

      const matchStage = filterStage === 'all' || student.stage === filterStage;
      const matchStatus = filterStatus === 'all' || 
        (filterStatus === 'settled' && plan.remaining === 0) ||
        (filterStatus === 'arrears' && plan.remaining > 0);

      return matchSearch && matchStage && matchStatus;
    });
  }, [feePlans, students, searchStudent, filterStage, filterStatus]);

  // Arrears List
  const arrearsList = useMemo(() => {
    return filteredPlans.filter(({ plan }) => plan.remaining > 0);
  }, [filteredPlans]);

  const handleQuickPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentModal || paymentModal.amountToPay <= 0) return;

    const voucher = createVoucher({
      type: 'receipt',
      date: new Date().toISOString().split('T')[0],
      amount: paymentModal.amountToPay,
      recipientOrPayer: `${paymentModal.studentName} (عن الطالب)`,
      studentId: paymentModal.studentId,
      category: `رسوم دراسية - ${paymentModal.installmentTitle}`,
      paymentMethod: paymentModal.paymentMethod,
      accountFrom: paymentModal.paymentMethod === 'بنك الكريمي' ? 'حساب بنك الكريمي' : 'صندوق الخزينة الرئيسي',
      accountTo: 'إيرادات الرسوم الدراسية وأقساط الطلاب',
      notes: `تسديد قسط بموجب الإيصال المدرسي`,
      preparedBy: 'المحاسب المالي'
    });

    setPaymentModal(null);
    openPrintModal('voucher', voucher);
  };

  const handleSendReminder = (phone: string, studentName: string, amount: number) => {
    const text = encodeURIComponent(
      `الأخ ولي أمر الطالب/ة: ${studentName}\nالسلام عليكم ورحمة الله وبركاته،\nتذكركم إدارة ${schoolInfo.name} بضرورة سداد القسط الدراسي المستحق وقدره: ${amount.toLocaleString()} ريال يمني، ليتسنى لنا إصدار بطاقة الاختبار وتسليم النتائج.\nشاكرين تعاونكم.`
    );
    window.open(`https://wa.me/967${phone}?text=${text}`, '_blank');
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Header and SubTabs */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Receipt className="w-5 h-5 text-emerald-600" />
              <span>إدارة الرسوم الدراسية والأقساط</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              متابعة تسديد الأقساط، الخصومات الممنوحة، وسندات القبض الفورية
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setActiveSubTab('plans')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeSubTab === 'plans' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              خطط وأقساط الطلاب
            </button>
            <button
              onClick={() => setActiveSubTab('arrears')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeSubTab === 'arrears' ? 'bg-white text-amber-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              كشف المتأخرات ({arrearsList.length})
            </button>
            <button
              onClick={() => setActiveSubTab('types')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                activeSubTab === 'types' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              لائحة الرسوم والأنشطة
            </button>
          </div>
        </div>

        {/* Filter bar for Plans and Arrears */}
        {activeSubTab !== 'types' && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-100">
            <input 
              type="text"
              placeholder="بحث باسم الطالب أو الصف..."
              value={searchStudent}
              onChange={(e) => setSearchStudent(e.target.value)}
              className="p-1.5 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white"
            />
            <select
              value={filterStage}
              onChange={(e) => setFilterStage(e.target.value)}
              className="p-1.5 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white"
            >
              <option value="all">جميع المراحل</option>
              <option value="primary">الأساسي الأدنى (1-6)</option>
              <option value="middle">الأساسي الأعلى (7-9)</option>
              <option value="secondary">المرحلة الثانوية</option>
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="p-1.5 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white"
            >
              <option value="all">جميع الحالات</option>
              <option value="arrears">عليهم متبقي / متأخرات</option>
              <option value="settled">مسددين بالكامل</option>
            </select>
          </div>
        )}
      </div>

      {/* SUBTAB 1: Student Fee Plans & Installments */}
      {activeSubTab === 'plans' && (
        <div className="space-y-3">
          {filteredPlans.map(({ plan, student }) => {
            if (!student) return null;
            const progress = plan.netRequired > 0 ? Math.round((plan.totalPaid / plan.netRequired) * 100) : 100;
            return (
              <div 
                key={plan.studentId}
                className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3"
              >
                {/* Student row info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <img 
                      src={student.photoUrl} 
                      alt=""
                      className="w-10 h-10 rounded-full object-cover border border-slate-200"
                    />
                    <div>
                      <div className="font-bold text-slate-900 text-sm">{student.fullName}</div>
                      <div className="text-slate-500 text-[11px] flex items-center gap-2">
                        <span>{student.grade} - {student.section}</span>
                        <span>·</span>
                        <span className="font-mono text-slate-400">{student.id}</span>
                        <span>·</span>
                        <span>ولي الأمر: {student.parentPhone}</span>
                      </div>
                    </div>
                  </div>

                  {/* Financial summary numbers */}
                  <div className="flex items-center gap-4 text-left sm:text-right">
                    <div>
                      <div className="text-[10px] text-slate-400">إجمالي المطلوب</div>
                      <div className="font-mono font-bold text-slate-800 tabular-nums">
                        {plan.netRequired.toLocaleString()} ر.ي
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-emerald-600">المسدد</div>
                      <div className="font-mono font-bold text-emerald-700 tabular-nums">
                        {plan.totalPaid.toLocaleString()} ر.ي
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-amber-600">المتبقي</div>
                      <div className={`font-mono font-bold tabular-nums ${plan.remaining > 0 ? 'text-amber-700' : 'text-slate-400'}`}>
                        {plan.remaining.toLocaleString()} ر.ي
                      </div>
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                    <span>نسبة السداد: {progress}%</span>
                    {plan.totalDiscount > 0 && (
                      <span className="text-teal-600 font-semibold">
                        خصم ممنوح: {plan.totalDiscount.toLocaleString()} ر.ي
                      </span>
                    )}
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${progress >= 100 ? 'bg-emerald-500' : 'bg-emerald-600'}`}
                      style={{ width: `${Math.min(100, progress)}%` }}
                    />
                  </div>
                </div>

                {/* Installments Breakdown Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  {plan.installments.map((inst, idx) => (
                    <div 
                      key={inst.id}
                      className={`p-2.5 rounded-lg border flex flex-col justify-between ${
                        inst.status === 'مسدد' ? 'bg-emerald-50/50 border-emerald-200' :
                        inst.status === 'متأخر' ? 'bg-rose-50/50 border-rose-200' : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-semibold text-slate-800 text-[11px]">{inst.title}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                          inst.status === 'مسدد' ? 'bg-emerald-100 text-emerald-800' :
                          inst.status === 'متأخر' ? 'bg-rose-100 text-rose-800' : 'bg-slate-200 text-slate-700'
                        }`}>
                          {inst.status}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between font-mono text-[11px] mb-2">
                        <span className="text-slate-500">المبلغ: {inst.amount.toLocaleString()}</span>
                        <span className="font-bold text-slate-900">مسدد: {inst.paidAmount.toLocaleString()}</span>
                      </div>

                      {inst.status !== 'مسدد' && (
                        <button
                          onClick={() => setPaymentModal({
                            isOpen: true,
                            studentId: student.id,
                            studentName: student.fullName,
                            installmentTitle: inst.title,
                            amountToPay: inst.amount - inst.paidAmount,
                            paymentMethod: 'نقداً - الصندوق'
                          })}
                          className="w-full py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold text-[11px] flex items-center justify-center gap-1 transition-colors"
                        >
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                          <span>سداد وإصدار سند</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* SUBTAB 2: Arrears List with WhatsApp action */}
      {activeSubTab === 'arrears' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="p-3 bg-amber-50 border-b border-amber-100 text-amber-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span className="font-bold">كشف الطلاب المتأخرين عن سداد الأقساط</span>
            </div>
            <span className="font-bold font-mono">
              إجمالي المتأخرات: {arrearsList.reduce((sum, item) => sum + item.plan.remaining, 0).toLocaleString()} ر.ي
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {arrearsList.map(({ plan, student }) => {
              if (!student) return null;
              return (
                <div key={plan.studentId} className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div>
                    <div className="font-bold text-slate-900">{student.fullName}</div>
                    <div className="text-slate-500 text-[11px]">
                      {student.grade} - شعبة {student.section} · ولي الأمر: {student.parentName} ({student.parentPhone})
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-left font-mono">
                      <div className="text-amber-700 font-bold tabular-nums">
                        {plan.remaining.toLocaleString()} ر.ي
                      </div>
                      <div className="text-[10px] text-slate-400">متبقي غير مسدد</div>
                    </div>

                    <button
                      onClick={() => handleSendReminder(student.parentPhone, student.fullName, plan.remaining)}
                      className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1.5 transition-colors"
                      title="إرسال تذكير عبر واتساب"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>إرسال واتساب</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB 3: Fee Item Tariffs */}
      {activeSubTab === 'types' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="p-3.5 border-b border-slate-100 font-bold text-slate-800">
            لائحة الرسوم الدراسية المعتمدة للعام الدراسي {schoolInfo.currentYear}
          </div>
          <table className="w-full text-right">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">بند الرسوم</th>
                <th className="p-3">التصنيف</th>
                <th className="p-3">المرحلة / الصف المستهدف</th>
                <th className="p-3 text-left">المبلغ المقرر</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {feeItems.map(item => (
                <tr key={item.id} className="hover:bg-slate-50">
                  <td className="p-3 font-semibold text-slate-900">{item.title}</td>
                  <td className="p-3 text-slate-600">{item.category}</td>
                  <td className="p-3 text-slate-600">{item.grade}</td>
                  <td className="p-3 text-left font-mono font-bold text-emerald-700 tabular-nums">
                    {item.amount.toLocaleString()} ر.ي
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* QUICK PAYMENT & VOUCHER CREATION MODAL */}
      {paymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">
                سداد قسط وإصدار سند قبض رسمي
              </h3>
              <button onClick={() => setPaymentModal(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleQuickPaymentSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] text-slate-500 mb-1">اسم الطالب</label>
                <input 
                  type="text" 
                  disabled 
                  value={paymentModal.studentName}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-500 mb-1">البند / القسط</label>
                <input 
                  type="text" 
                  disabled 
                  value={paymentModal.installmentTitle}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">المبلغ المراد سداده (ريال يمني) *</label>
                <input 
                  type="number" 
                  required
                  min="1000"
                  value={paymentModal.amountToPay}
                  onChange={(e) => setPaymentModal({ ...paymentModal, amountToPay: Number(e.target.value) })}
                  className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold text-emerald-700 text-base"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">طريقة الدفع والحساب *</label>
                <select
                  value={paymentModal.paymentMethod}
                  onChange={(e) => setPaymentModal({ ...paymentModal, paymentMethod: e.target.value as any })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  <option value="نقداً - الصندوق">نقداً - صندوق الخزينة المدرسي</option>
                  <option value="بنك الكريمي">إيداع / تحويل - بنك الكريمي</option>
                  <option value="حوالة مصرفية">حوالة مصرفية (النجم / الامتياز / سويد)</option>
                </select>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentModal(null)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تأكيد السداد والطباعة</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
