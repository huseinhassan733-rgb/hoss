import React from 'react';
import { 
  Users, 
  Wallet, 
  Receipt, 
  AlertCircle, 
  UserPlus, 
  PlusCircle, 
  FileText, 
  CheckCircle2, 
  Send, 
  Printer, 
  ArrowUpRight, 
  ArrowDownLeft,
  Calendar,
  Building2,
  TrendingUp,
  Award
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { formatCurrency } from '../../utils/numberToWordsArabic';

interface DashboardHomeProps {
  onRegisterStudent: () => void;
  onNewVoucher: (type: 'receipt' | 'payment') => void;
}

export const DashboardHome: React.FC<DashboardHomeProps> = ({ 
  onRegisterStudent, 
  onNewVoucher 
}) => {
  const { 
    schoolInfo, 
    students, 
    feePlans, 
    vouchers, 
    financialSummary, 
    studentSummary,
    setActiveTab,
    openPrintModal,
    showToast
  } = useSchool();

  const recentVouchers = vouchers.slice(0, 5);
  const studentsWithArrears = feePlans
    .filter(p => p.remaining > 0)
    .slice(0, 4)
    .map(p => {
      const student = students.find(s => s.id === p.studentId);
      return { plan: p, student };
    });

  const handleSendWhatsAppReminder = (phone: string, studentName: string, amount: number) => {
    const text = encodeURIComponent(
      `الأخ ولي أمر الطالب/ة: ${studentName}\nتحية طيبة من إدارة ${schoolInfo.name}،\nنود تذكيركم بلطف بأن المبلغ المستحق من الرسوم الدراسية هو: ${amount.toLocaleString()} ريال يمني.\nشاكرين ومقدرين حسن تعاونكم وحرصكم الدائم.`
    );
    window.open(`https://wa.me/967${phone}?text=${text}`, '_blank');
    showToast('تم فتح محادثة الواتساب لإرسال الإشعار');
  };

  return (
    <div className="space-y-4 sm:space-y-6 pb-16 sm:pb-8">
      
      {/* Welcome & Fast Actions Header */}
      <div className="bg-gradient-to-l from-slate-900 via-slate-800 to-slate-900 rounded-2xl p-4 sm:p-6 text-white shadow-md relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
          <div>
            <div className="text-xs font-semibold text-emerald-400 mb-1 flex items-center gap-1.5">
              <span>{schoolInfo.currentYear}</span>
              <span>·</span>
              <span>{schoolInfo.currentTerm}</span>
            </div>
            <h2 className="text-lg sm:text-2xl font-bold tracking-tight">
              أهلاً بكم في منظومة {schoolInfo.name}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
              إدارة متكاملة من الجوال للطلاب والرسوم والحسابات والدرجات الرسمية
            </p>
          </div>

          {/* Quick Buttons for Mobile thumb zone */}
          <div className="flex flex-wrap gap-2 pt-2 sm:pt-0">
            <button
              onClick={onRegisterStudent}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl transition-all shadow-sm shadow-emerald-700/30"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>تسجيل طالب</span>
            </button>
            <button
              onClick={() => onNewVoucher('receipt')}
              className="flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all"
            >
              <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-300" />
              <span>سند قبض</span>
            </button>
            <button
              onClick={() => onNewVoucher('payment')}
              className="flex items-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all"
            >
              <ArrowUpRight className="w-3.5 h-3.5 text-rose-300" />
              <span>سند صرف</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Total Students */}
        <div 
          onClick={() => setActiveTab('students')}
          className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs cursor-pointer hover:border-emerald-300 transition-all group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">إجمالي الطلاب</span>
            <Users className="w-4 h-4 text-emerald-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {studentSummary.total}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5">
            <span>بنين: {studentSummary.boys}</span>
            <span>·</span>
            <span>بنات: {studentSummary.girls}</span>
          </div>
        </div>

        {/* Cash Balance */}
        <div 
          onClick={() => setActiveTab('accounting')}
          className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs cursor-pointer hover:border-emerald-300 transition-all group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">رصيد الخزينة (الصندوق)</span>
            <Wallet className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums truncate">
            {financialSummary.cashBalance.toLocaleString()} <span className="text-xs font-normal text-slate-500">ر.ي</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span>البنوك:</span>
            <span className="font-mono tabular-nums">{financialSummary.bankBalance.toLocaleString()} ر.ي</span>
          </div>
        </div>

        {/* Total Collections */}
        <div 
          onClick={() => setActiveTab('fees')}
          className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs cursor-pointer hover:border-emerald-300 transition-all group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">المحصل من الرسوم</span>
            <TrendingUp className="w-4 h-4 text-teal-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-lg sm:text-xl font-bold text-emerald-700 font-mono tabular-nums truncate">
            {financialSummary.totalRevenue.toLocaleString()} <span className="text-xs font-normal text-emerald-600">ر.ي</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span>صافي الفائض: {(financialSummary.netProfit).toLocaleString()} ر.ي</span>
          </div>
        </div>

        {/* Total Arrears */}
        <div 
          onClick={() => setActiveTab('fees')}
          className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-xs cursor-pointer hover:border-amber-300 transition-all group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-medium">المتأخرات على الطلاب</span>
            <AlertCircle className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-lg sm:text-xl font-bold text-amber-700 font-mono tabular-nums truncate">
            {financialSummary.totalArrears.toLocaleString()} <span className="text-xs font-normal text-amber-600">ر.ي</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span>{studentSummary.withArrears} طلاب مستحق عليهم أقساط</span>
          </div>
        </div>

      </div>

      {/* Two Column Layout: Recent Vouchers + Arrears Alert */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Recent Vouchers */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">أحدث السندات المالية المعتمدة</h3>
              <p className="text-[11px] text-slate-500">سندات القبض والصرف الصادرة اليوم والمرحلة محاسبياً</p>
            </div>
            <button 
              onClick={() => setActiveTab('accounting')}
              className="text-xs font-semibold text-emerald-700 hover:underline"
            >
              عرض الكل
            </button>
          </div>

          <div className="space-y-2">
            {recentVouchers.map(v => (
              <div 
                key={v.id}
                className="flex items-center justify-between p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                    v.type === 'receipt' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                  }`}>
                    {v.type === 'receipt' ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-900 truncate">
                      {v.recipientOrPayer}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                      <span>سند {v.type === 'receipt' ? 'قبض' : 'صرف'} #{v.voucherNumber}</span>
                      <span>·</span>
                      <span>{v.date}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className={`font-mono font-bold tabular-nums ${v.type === 'receipt' ? 'text-emerald-700' : 'text-rose-700'}`}>
                    {v.type === 'receipt' ? '+' : '-'}{v.amount.toLocaleString()} ر.ي
                  </span>
                  <button
                    onClick={() => openPrintModal('voucher', v)}
                    className="p-1 text-slate-400 hover:text-slate-800 rounded transition-colors"
                    title="معاينة وطباعة السند الرسمي"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Arrears Follow-up */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">متابعة متأخرات الرسوم والأقساط</h3>
              <p className="text-[11px] text-slate-500">إشعار فوري وتواصل مباشر مع أولياء الأمور عبر واتساب</p>
            </div>
            <button 
              onClick={() => setActiveTab('fees')}
              className="text-xs font-semibold text-amber-700 hover:underline"
            >
              كشف المتأخرات
            </button>
          </div>

          <div className="space-y-2">
            {studentsWithArrears.map(({ plan, student }) => {
              if (!student) return null;
              return (
                <div 
                  key={plan.studentId}
                  className="p-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors text-xs flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-slate-900 truncate">
                      {student.fullName}
                    </div>
                    <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                      <span>{student.grade} - {student.section}</span>
                      <span>·</span>
                      <span>ولي الأمر: {student.parentName}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <div className="text-right">
                      <div className="font-mono font-bold text-amber-700 tabular-nums">
                        {plan.remaining.toLocaleString()} ر.ي
                      </div>
                      <div className="text-[10px] text-slate-400">متبقي</div>
                    </div>

                    <button
                      onClick={() => handleSendWhatsAppReminder(student.parentPhone, student.fullName, plan.remaining)}
                      className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-[11px] font-semibold flex items-center gap-1 transition-colors"
                      title="مراسلة ولي الأمر عبر واتساب"
                    >
                      <Send className="w-3 h-3" />
                      <span className="hidden sm:inline">إشعار</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Quick Navigation Cards Grid (School Modules shortcut) */}
      <div className="bg-slate-100/70 p-4 rounded-xl border border-slate-200">
        <div className="text-xs font-bold text-slate-600 mb-3">
          الوصول السريع للأعمال الإدارية والميدانية:
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <button
            onClick={() => setActiveTab('attendance')}
            className="p-3 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 text-right flex flex-col justify-between shadow-2xs transition-all"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mb-2" />
            <div className="text-xs font-bold text-slate-900">تحضير الطلاب اليومي</div>
            <div className="text-[10px] text-slate-500">رصد الحضور والغياب والأعذار</div>
          </button>

          <button
            onClick={() => setActiveTab('grades')}
            className="p-3 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 text-right flex flex-col justify-between shadow-2xs transition-all"
          >
            <Award className="w-5 h-5 text-purple-600 mb-2" />
            <div className="text-xs font-bold text-slate-900">الدرجات والشهادات</div>
            <div className="text-[10px] text-slate-500">رصد الاختبارات وشيت الكنترول</div>
          </button>

          <button
            onClick={() => setActiveTab('staff')}
            className="p-3 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 text-right flex flex-col justify-between shadow-2xs transition-all"
          >
            <Users className="w-5 h-5 text-blue-600 mb-2" />
            <div className="text-xs font-bold text-slate-900">مسير رواتب الموظفين</div>
            <div className="text-[10px] text-slate-500">احتساب المستحقات والصرف</div>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className="p-3 bg-white hover:bg-slate-50 rounded-xl border border-slate-200 text-right flex flex-col justify-between shadow-2xs transition-all"
          >
            <FileText className="w-5 h-5 text-amber-600 mb-2" />
            <div className="text-xs font-bold text-slate-900">التقارير والكشوفات</div>
            <div className="text-[10px] text-slate-500">طباعة وتصدير ملفات Excel</div>
          </button>
        </div>
      </div>

    </div>
  );
};
