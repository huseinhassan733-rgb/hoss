import React, { useState, useMemo } from 'react';
import { 
  Award, 
  Search, 
  Filter, 
  Printer, 
  Plus, 
  Trophy, 
  CheckCircle2, 
  Save, 
  FileSpreadsheet,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { GradeRecord, Student } from '../../types';
import { allGrades, yemeniSubjects, allSections } from '../../data/initialData';

export const GradesControlModule: React.FC = () => {
  const { 
    students, 
    grades, 
    saveGrade, 
    schoolInfo, 
    openPrintModal,
    showToast 
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'entry' | 'control_sheet' | 'top_students'>('entry');
  const [selectedGrade, setSelectedGrade] = useState<string>('تاسع أساسي');
  const [selectedSection, setSelectedSection] = useState<string>('أ');
  const [selectedSubject, setSelectedSubject] = useState<string>('الرياضيات');
  const [selectedTerm, setSelectedTerm] = useState<'الفصل الأول' | 'الفصل الثاني'>('الفصل الأول');

  // Filter students for the selected class
  const classStudents = useMemo(() => {
    return students.filter(s => s.grade === selectedGrade && s.section === selectedSection);
  }, [students, selectedGrade, selectedSection]);

  // Grade Entry temporary state for classStudents
  const [editScores, setEditScores] = useState<Record<string, { m1: number; m2: number; act: number; fin: number }>>({});

  // Initialize edit scores when class/subject changes
  React.useEffect(() => {
    const scoresMap: Record<string, { m1: number; m2: number; act: number; fin: number }> = {};
    classStudents.forEach(stu => {
      const record = grades.find(g => 
        g.studentId === stu.id && 
        g.subject === selectedSubject && 
        g.term === selectedTerm
      );
      if (record) {
        scoresMap[stu.id] = {
          m1: record.monthlyScore1,
          m2: record.monthlyScore2,
          act: record.activitiesScore,
          fin: record.finalExamScore
        };
      } else {
        scoresMap[stu.id] = { m1: 18, m2: 18, act: 9, fin: 45 };
      }
    });
    setEditScores(scoresMap);
  }, [classStudents, selectedSubject, selectedTerm, grades]);

  const handleScoreChange = (studentId: string, field: 'm1' | 'm2' | 'act' | 'fin', val: number) => {
    setEditScores(prev => ({
      ...prev,
      [studentId]: {
        ...(prev[studentId] || { m1: 0, m2: 0, act: 0, fin: 0 }),
        [field]: Math.max(0, val)
      }
    }));
  };

  const handleSaveAllScores = () => {
    classStudents.forEach(stu => {
      const cur = editScores[stu.id];
      if (cur) {
        saveGrade({
          studentId: stu.id,
          academicYear: schoolInfo.currentYear,
          term: selectedTerm,
          subject: selectedSubject,
          monthlyScore1: cur.m1,
          monthlyScore2: cur.m2,
          activitiesScore: cur.act,
          finalExamScore: cur.fin
        });
      }
    });
    showToast(`تم حفظ واعتماد درجات مادة (${selectedSubject}) لجميع طلاب الشعبة`);
  };

  // Top Students calculation for the honor board
  const topStudents = useMemo(() => {
    const studentAverages = students.map(student => {
      const studentGrades = grades.filter(g => g.studentId === student.id && g.term === selectedTerm);
      if (studentGrades.length === 0) return null;
      const sum = studentGrades.reduce((acc, curr) => acc + curr.totalScore, 0);
      const avg = Math.round((sum / studentGrades.length) * 10) / 10;
      return {
        student,
        gradesCount: studentGrades.length,
        average: avg,
        totalSum: sum
      };
    }).filter(Boolean) as { student: Student; gradesCount: number; average: number; totalSum: number }[];

    return studentAverages.sort((a, b) => b.average - a.average);
  }, [students, grades, selectedTerm]);

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Header & Sub-Tabs */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-600" />
              <span>إدارة الدرجات والاختبارات والكنترول</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              رصد أعمال السنة، الامتحانات الشهرية والفصلية، كشوف الكنترول والشهادات الرسمية
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg overflow-x-auto hide-scrollbar">
            <button
              onClick={() => setActiveTab('entry')}
              className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'entry' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              شيت رصد الدرجات
            </button>
            <button
              onClick={() => setActiveTab('control_sheet')}
              className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'control_sheet' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              كشف الكنترول والنتائج
            </button>
            <button
              onClick={() => setActiveTab('top_students')}
              className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'top_students' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              أوائل الطلاب ولوحة الشرف
            </button>
          </div>
        </div>

        {/* Filters for grade entry */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">الصف الدراسي</label>
            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
            >
              {allGrades.map(g => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">الشعبة</label>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
            >
              {allSections.map(s => (
                <option key={s} value={s}>شعبة ({s})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">المادة الدراسية</label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
            >
              {yemeniSubjects.map(sub => (
                <option key={sub} value={sub}>{sub}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">الفصل الدراسي</label>
            <select
              value={selectedTerm}
              onChange={(e) => setSelectedTerm(e.target.value as any)}
              className="w-full p-1.5 border border-slate-200 rounded-lg bg-slate-50"
            >
              <option value="الفصل الأول">الفصل الدراسي الأول</option>
              <option value="الفصل الثاني">الفصل الدراسي الثاني</option>
            </select>
          </div>
        </div>
      </div>

      {/* TAB 1: Quick Grade Entry */}
      {activeTab === 'entry' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="font-bold text-slate-800">
              رصد مادة: <span className="text-emerald-700">{selectedSubject}</span> · {selectedGrade} (شعبة {selectedSection})
            </div>
            
            <div className="flex items-center gap-2">
              <button
                onClick={handleSaveAllScores}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
              >
                <Save className="w-3.5 h-3.5" />
                <span>حفظ ورصد جميع الدرجات</span>
              </button>
            </div>
          </div>

          {classStudents.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
              لا يوجد طلاب مسجلين في هذا الصف والشعبة حالياً.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">الطالب</th>
                    <th className="p-2 text-center">شهري 1 (20)</th>
                    <th className="p-2 text-center">شهري 2 (20)</th>
                    <th className="p-2 text-center">أنشطة (10)</th>
                    <th className="p-2 text-center">نهائي (50)</th>
                    <th className="p-2 text-center">المجموع (100)</th>
                    <th className="p-2 text-center">التقدير</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {classStudents.map(student => {
                    const sc = editScores[student.id] || { m1: 0, m2: 0, act: 0, fin: 0 };
                    const total = Number(sc.m1) + Number(sc.m2) + Number(sc.act) + Number(sc.fin);
                    const letter = total >= 90 ? 'ممتاز' : total >= 80 ? 'جيد جداً' : total >= 65 ? 'جيد' : total >= 50 ? 'مقبول' : 'ضعيف';

                    return (
                      <tr key={student.id} className="hover:bg-slate-50">
                        <td className="p-3 font-semibold text-slate-900">
                          {student.fullName}
                          <span className="block text-[10px] text-slate-400 font-mono">{student.id}</span>
                        </td>
                        
                        <td className="p-2 text-center">
                          <input 
                            type="number"
                            min="0"
                            max="20"
                            value={sc.m1}
                            onChange={(e) => handleScoreChange(student.id, 'm1', Number(e.target.value))}
                            className="w-14 p-1 text-center border border-slate-300 rounded font-mono font-bold"
                          />
                        </td>

                        <td className="p-2 text-center">
                          <input 
                            type="number"
                            min="0"
                            max="20"
                            value={sc.m2}
                            onChange={(e) => handleScoreChange(student.id, 'm2', Number(e.target.value))}
                            className="w-14 p-1 text-center border border-slate-300 rounded font-mono font-bold"
                          />
                        </td>

                        <td className="p-2 text-center">
                          <input 
                            type="number"
                            min="0"
                            max="10"
                            value={sc.act}
                            onChange={(e) => handleScoreChange(student.id, 'act', Number(e.target.value))}
                            className="w-14 p-1 text-center border border-slate-300 rounded font-mono font-bold"
                          />
                        </td>

                        <td className="p-2 text-center">
                          <input 
                            type="number"
                            min="0"
                            max="50"
                            value={sc.fin}
                            onChange={(e) => handleScoreChange(student.id, 'fin', Number(e.target.value))}
                            className="w-14 p-1 text-center border border-slate-300 rounded font-mono font-bold"
                          />
                        </td>

                        <td className="p-2 text-center font-mono font-bold text-slate-900 text-sm">
                          {total}
                        </td>

                        <td className="p-2 text-center">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            total >= 90 ? 'bg-emerald-100 text-emerald-800' :
                            total >= 80 ? 'bg-blue-100 text-blue-800' :
                            total >= 50 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {letter}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Control Sheet & Result Certificates */}
      {activeTab === 'control_sheet' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs space-y-3 p-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                كشف نتائج طلاب {selectedGrade} (شعبة {selectedSection})
              </h3>
              <p className="text-[11px] text-slate-500">استخراج الشهادات الرسمية المعتمدة بضغطة زر</p>
            </div>

            <button
              onClick={() => window.print()}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة شيت الكنترول</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {classStudents.map(student => {
              const studentGrades = grades.filter(g => g.studentId === student.id && g.term === selectedTerm);
              const sum = studentGrades.reduce((a, b) => a + b.totalScore, 0);
              const avg = studentGrades.length > 0 ? Math.round(sum / studentGrades.length) : 0;
              const letter = avg >= 90 ? 'ممتاز' : avg >= 80 ? 'جيد جداً' : avg >= 65 ? 'جيد' : avg >= 50 ? 'مقبول' : 'ضعيف';

              return (
                <div key={student.id} className="py-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-2.5">
                    <img src={student.photoUrl} alt="" className="w-9 h-9 rounded-full object-cover border" />
                    <div>
                      <div className="font-bold text-slate-900">{student.fullName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {student.id} · المواد المرصودة: {studentGrades.length}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="font-mono font-bold text-slate-900 text-sm">{avg}%</div>
                      <div className="text-[10px] text-slate-500 font-semibold">{letter}</div>
                    </div>

                    <button
                      onClick={() => openPrintModal('report_card', { student, grades: studentGrades, average: avg, letter, term: selectedTerm })}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1 transition-colors"
                      title="طباعة شهادة الدرجات الرسمية"
                    >
                      <Award className="w-3.5 h-3.5" />
                      <span>إصدار الشهادة</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: Honor Board / Top Students */}
      {activeTab === 'top_students' && (
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-100">
            <Trophy className="w-5 h-5 text-amber-500" />
            <div>
              <h3 className="font-bold text-slate-900 text-sm">لوحة الشرف وأوائل المدارس النموذجية</h3>
              <p className="text-[11px] text-slate-500">قائمة المتفوقين أصحاب أعلى المعدلات العامة</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {topStudents.slice(0, 6).map((item, idx) => (
              <div 
                key={item.student.id}
                className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/40 relative overflow-hidden flex items-center gap-3"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-sm shrink-0 shadow-xs ${
                  idx === 0 ? 'bg-amber-500 text-white' : idx === 1 ? 'bg-slate-400 text-white' : idx === 2 ? 'bg-amber-700 text-white' : 'bg-slate-200 text-slate-700'
                }`}>
                  {idx + 1}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="font-bold text-slate-900 truncate">{item.student.fullName}</div>
                  <div className="text-[11px] text-slate-500">{item.student.grade} - {item.student.section}</div>
                </div>

                <div className="text-left font-mono shrink-0">
                  <div className="text-base font-bold text-emerald-800 tabular-nums">{item.average}%</div>
                  <div className="text-[10px] text-amber-700 font-bold">ممتاز</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
