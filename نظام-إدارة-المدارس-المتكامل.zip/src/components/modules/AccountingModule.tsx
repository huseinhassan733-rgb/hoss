import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Printer, 
  Plus, 
  Search, 
  Calendar, 
  FileText, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Wallet, 
  Building,
  CheckCircle2,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Voucher, AccountLedgerItem } from '../../types';
import { formatCurrency, tafqeet } from '../../utils/numberToWordsArabic';

interface AccountingModuleProps {
  initialVoucherType?: 'receipt' | 'payment';
}

export const AccountingModule: React.FC<AccountingModuleProps> = ({ initialVoucherType }) => {
  const { 
    vouchers, 
    accounts, 
    createVoucher, 
    financialSummary, 
    openPrintModal,
    showToast 
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'vouchers' | 'accounts' | 'trial_balance' | 'income_statement'>('vouchers');
  const [voucherFilter, setVoucherFilter] = useState<'all' | 'receipt' | 'payment'>('all');
  const [searchVoucher, setSearchVoucher] = useState('');

  // Voucher creation modal
  const [isVoucherModalOpen, setIsVoucherModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'receipt' | 'payment'>('receipt');
  const [voucherFormData, setVoucherFormData] = useState({
    amount: 50000,
    recipientOrPayer: '',
    category: 'رسوم دراسية',
    paymentMethod: 'نقداً - الصندوق' as const,
    accountFrom: 'صندوق الخزينة الرئيسي',
    accountTo: 'إيرادات الرسوم الدراسية',
    notes: 'بموجب السند الرسمي للمدرسة'
  });

  // Filtered vouchers
  const filteredVouchers = useMemo(() => {
    return vouchers.filter(v => {
      const matchType = voucherFilter === 'all' || v.type === voucherFilter;
      const matchSearch = searchVoucher === '' ||
        v.recipientOrPayer.includes(searchVoucher) ||
        String(v.voucherNumber).includes(searchVoucher) ||
        v.category.includes(searchVoucher) ||
        v.notes.includes(searchVoucher);
      return matchType && matchSearch;
    });
  }, [vouchers, voucherFilter, searchVoucher]);

  const handleOpenNewVoucher = (type: 'receipt' | 'payment') => {
    setModalType(type);
    setVoucherFormData({
      amount: type === 'receipt' ? 50000 : 25000,
      recipientOrPayer: '',
      category: type === 'receipt' ? 'رسوم دراسية وأقساط' : 'مصروفات تشغيلية وصيانة',
      paymentMethod: 'نقداً - الصندوق',
      accountFrom: type === 'receipt' ? 'صندوق الخزينة الرئيسي' : 'صندوق الخزينة الرئيسي',
      accountTo: type === 'receipt' ? 'إيرادات الرسوم الدراسية وأقساط الطلاب' : 'مصروفات الصيانة والتشغيل',
      notes: ''
    });
    setIsVoucherModalOpen(true);
  };

  const handleCreateVoucherSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!voucherFormData.recipientOrPayer.trim() || voucherFormData.amount <= 0) {
      showToast('يرجى تحديد المبلغ والطرف المستلم أو المصروف إليه', 'error');
      return;
    }

    const newVoucher = createVoucher({
      type: modalType,
      date: new Date().toISOString().split('T')[0],
      amount: voucherFormData.amount,
      recipientOrPayer: voucherFormData.recipientOrPayer,
      category: voucherFormData.category,
      paymentMethod: voucherFormData.paymentMethod,
      accountFrom: voucherFormData.accountFrom,
      accountTo: voucherFormData.accountTo,
      notes: voucherFormData.notes || `سند ${modalType === 'receipt' ? 'قبض' : 'صرف'} معتمد`,
      preparedBy: 'المحاسب المالي'
    });

    setIsVoucherModalOpen(false);
    openPrintModal('voucher', newVoucher);
  };

  // Trial balance calculations
  const trialBalance = useMemo(() => {
    return accounts.map(acc => {
      const isDebitNature = acc.type === 'أصول' || acc.type === 'مصروفات';
      const debit = isDebitNature ? acc.balance : 0;
      const credit = !isDebitNature ? acc.balance : 0;
      return { ...acc, debit, credit };
    });
  }, [accounts]);

  const totalDebits = trialBalance.reduce((sum, item) => sum + item.debit, 0);
  const totalCredits = trialBalance.reduce((sum, item) => sum + item.credit, 0);

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Top Bar with KPI and actions */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calculator className="w-5 h-5 text-emerald-600" />
              <span>النظام المحاسبي والسندات المالية</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              إصدار سندات القبض والصرف الرسمية مع الترحيل الآلي لدليل الحسابات
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleOpenNewVoucher('receipt')}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>سند قبض جديد</span>
            </button>
            <button
              onClick={() => handleOpenNewVoucher('payment')}
              className="px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>سند صرف جديد</span>
            </button>
          </div>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto hide-scrollbar">
          <button
            onClick={() => setActiveTab('vouchers')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'vouchers' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            سجل السندات ({vouchers.length})
          </button>
          <button
            onClick={() => setActiveTab('accounts')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'accounts' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            دليل الحسابات والأرصدة
          </button>
          <button
            onClick={() => setActiveTab('trial_balance')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'trial_balance' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ميزان المراجعة
          </button>
          <button
            onClick={() => setActiveTab('income_statement')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'income_statement' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            قائمة الدخل والأرباح
          </button>
        </div>
      </div>

      {/* TAB 1: Vouchers List */}
      {activeTab === 'vouchers' && (
        <div className="space-y-3">
          
          {/* Voucher filters */}
          <div className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setVoucherFilter('all')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold ${
                  voucherFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                الكل
              </button>
              <button
                onClick={() => setVoucherFilter('receipt')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold ${
                  voucherFilter === 'receipt' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-800'
                }`}
              >
                سندات القبض (+)
              </button>
              <button
                onClick={() => setVoucherFilter('payment')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold ${
                  voucherFilter === 'payment' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-800'
                }`}
              >
                سندات الصرف (-)
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text"
                placeholder="بحث برقم السند، الاسم، التصنيف..."
                value={searchVoucher}
                onChange={(e) => setSearchVoucher(e.target.value)}
                className="pr-8 pl-3 py-1.5 border border-slate-200 rounded-lg bg-slate-50 focus:bg-white text-xs w-full sm:w-64"
              />
            </div>
          </div>

          {/* Vouchers Table */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-right">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3">رقم السند</th>
                  <th className="p-3">النوع والتاريخ</th>
                  <th className="p-3">الطرف المستلم / المصروف إليه</th>
                  <th className="p-3">البند والبيان</th>
                  <th className="p-3">طريقة الدفع</th>
                  <th className="p-3">المبلغ</th>
                  <th className="p-3 text-center">معاينة وطباعة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredVouchers.map(v => (
                  <tr key={v.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-slate-900">
                      #{v.voucherNumber}
                    </td>
                    <td className="p-3">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                        v.type === 'receipt' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                      }`}>
                        سند {v.type === 'receipt' ? 'قبض' : 'صرف'}
                      </span>
                      <div className="text-[10px] text-slate-400 mt-0.5">{v.date}</div>
                    </td>
                    <td className="p-3 font-semibold text-slate-800">
                      {v.recipientOrPayer}
                    </td>
                    <td className="p-3">
                      <div className="text-slate-800">{v.category}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-xs">{v.notes}</div>
                    </td>
                    <td className="p-3 text-slate-600">
                      {v.paymentMethod}
                    </td>
                    <td className="p-3 font-mono font-bold tabular-nums">
                      <span className={v.type === 'receipt' ? 'text-emerald-700' : 'text-rose-700'}>
                        {v.type === 'receipt' ? '+' : '-'}{v.amount.toLocaleString()} ر.ي
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => openPrintModal('voucher', v)}
                        className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md font-semibold text-[11px] inline-flex items-center gap-1 transition-colors"
                        title="طباعة السند الرسمي"
                      >
                        <Printer className="w-3 h-3" />
                        <span>طباعة</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Chart of Accounts */}
      {activeTab === 'accounts' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
            <span className="font-bold text-slate-800">دليل الحسابات والأرصدة الحالية</span>
            <span className="text-slate-500 font-mono">العملة: ريال يمني (YER)</span>
          </div>

          <table className="w-full text-right">
            <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3">رمز الحساب</th>
                <th className="p-3">اسم الحساب</th>
                <th className="p-3">التصنيف المحاسبي</th>
                <th className="p-3 text-left">الرصيد الدفتري الحالي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {accounts.map(acc => (
                <tr key={acc.code} className="hover:bg-slate-50">
                  <td className="p-3 font-mono font-bold text-slate-600">{acc.code}</td>
                  <td className="p-3 font-semibold text-slate-900">{acc.name}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                      {acc.type}
                    </span>
                  </td>
                  <td className="p-3 text-left font-mono font-bold tabular-nums text-slate-900">
                    {acc.balance.toLocaleString()} ر.ي
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 3: Trial Balance */}
      {activeTab === 'trial_balance' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-3.5 border-b border-slate-100 flex items-center justify-between">
            <span className="font-bold text-slate-800">ميزان المراجعة بالأرصدة (Trial Balance)</span>
            <button 
              onClick={() => window.print()}
              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs font-semibold flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة الميزان</span>
            </button>
          </div>

          <table className="w-full text-right">
            <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="p-3">رقم الحساب</th>
                <th className="p-3">اسم الحساب</th>
                <th className="p-3 text-left">مدين (Debit)</th>
                <th className="p-3 text-left">دائن (Credit)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {trialBalance.map(item => (
                <tr key={item.code} className="hover:bg-slate-50">
                  <td className="p-3 text-slate-500">{item.code}</td>
                  <td className="p-3 font-sans font-semibold text-slate-900">{item.name}</td>
                  <td className="p-3 text-left tabular-nums text-slate-800">
                    {item.debit > 0 ? item.debit.toLocaleString() : '-'}
                  </td>
                  <td className="p-3 text-left tabular-nums text-slate-800">
                    {item.credit > 0 ? item.credit.toLocaleString() : '-'}
                  </td>
                </tr>
              ))}
              <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
                <td colSpan={2} className="p-3 font-sans">الإجمالي المتوازن</td>
                <td className="p-3 text-left text-emerald-800 tabular-nums">{totalDebits.toLocaleString()} ر.ي</td>
                <td className="p-3 text-left text-emerald-800 tabular-nums">{totalCredits.toLocaleString()} ر.ي</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 4: Income Statement */}
      {activeTab === 'income_statement' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs max-w-3xl mx-auto space-y-4">
          <div className="text-center pb-3 border-b border-slate-200">
            <h3 className="text-base font-bold text-slate-900">قائمة الدخل والأرباح التشغيلية للمدرسة</h3>
            <p className="text-slate-500 text-[11px]">عن العام الدراسي الحالي {new Date().getFullYear()}</p>
          </div>

          {/* Revenues */}
          <div>
            <div className="font-bold text-emerald-800 text-sm mb-2 flex items-center justify-between pb-1 border-b border-emerald-100">
              <span>أولاً: الإيرادات المدرسية التشغيلية</span>
              <span className="font-mono">{financialSummary.totalRevenue.toLocaleString()} ر.ي</span>
            </div>
            <div className="space-y-1.5 pr-3 text-slate-700">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>إيرادات رسوم الطلاب وأقساط التسجيل</span>
                <span className="font-mono">{financialSummary.totalRevenue.toLocaleString()} ر.ي</span>
              </div>
            </div>
          </div>

          {/* Expenses */}
          <div>
            <div className="font-bold text-rose-800 text-sm mb-2 flex items-center justify-between pb-1 border-b border-rose-100">
              <span>ثانياً: المصروفات التشغيلية والرواتب</span>
              <span className="font-mono">{financialSummary.totalExpenses.toLocaleString()} ر.ي</span>
            </div>
            <div className="space-y-1.5 pr-3 text-slate-700">
              {vouchers.filter(v => v.type === 'payment').map(v => (
                <div key={v.id} className="flex justify-between py-1 border-b border-slate-100">
                  <span>{v.category} ({v.recipientOrPayer})</span>
                  <span className="font-mono">{v.amount.toLocaleString()} ر.ي</span>
                </div>
              ))}
            </div>
          </div>

          {/* Net Result */}
          <div className="p-4 rounded-xl bg-slate-900 text-white flex items-center justify-between mt-4">
            <div>
              <div className="font-bold text-sm">صافي الفائض التشغيلي (الأرباح)</div>
              <div className="text-[11px] text-slate-300">الفارق بين إجمالي الإيرادات وإجمالي المصروفات</div>
            </div>
            <div className="text-right font-mono">
              <div className="text-xl font-bold text-emerald-400 tabular-nums">
                {financialSummary.netProfit.toLocaleString()} ر.ي
              </div>
              <div className="text-[10px] text-slate-400">ريال يمني</div>
            </div>
          </div>
        </div>
      )}

      {/* CREATE VOUCHER MODAL */}
      {isVoucherModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-lg border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                {modalType === 'receipt' ? (
                  <ArrowDownLeft className="w-5 h-5 text-emerald-600" />
                ) : (
                  <ArrowUpRight className="w-5 h-5 text-rose-600" />
                )}
                <h3 className="font-bold text-slate-900 text-sm">
                  إصدار سند {modalType === 'receipt' ? 'قبض رسمي (استلام مبالغ)' : 'صرف رسمي (صرف مبالغ)'}
                </h3>
              </div>
              <button onClick={() => setIsVoucherModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateVoucherSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {modalType === 'receipt' ? 'استلمنا من الأخ / ولي الأمر / الطالب *' : 'يصرف للأخ / الجهة *'}
                </label>
                <input 
                  type="text" 
                  required
                  placeholder={modalType === 'receipt' ? 'مثال: خالد محمد الشرجبي' : 'مثال: شركة الكهرباء أو المدرس فؤاد الزبيري'}
                  value={voucherFormData.recipientOrPayer}
                  onChange={(e) => setVoucherFormData({ ...voucherFormData, recipientOrPayer: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">المبلغ (ريال يمني) *</label>
                  <input 
                    type="number" 
                    required
                    min="100"
                    value={voucherFormData.amount}
                    onChange={(e) => setVoucherFormData({ ...voucherFormData, amount: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">طريقة الدفع والحساب *</label>
                  <select
                    value={voucherFormData.paymentMethod}
                    onChange={(e) => setVoucherFormData({ ...voucherFormData, paymentMethod: e.target.value as any })}
                    className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="نقداً - الصندوق">نقداً - الصندوق الرئيسي</option>
                    <option value="بنك الكريمي">بنك الكريمي</option>
                    <option value="شيك بنكي">شيك بنكي</option>
                    <option value="حوالة مصرفية">حوالة مصرفية</option>
                  </select>
                </div>
              </div>

              {/* Amount preview in words (Tafqeet) */}
              <div className="p-2.5 bg-slate-50 rounded-lg text-slate-600 text-[11px] font-medium border border-slate-100">
                التفقيط: <span className="font-semibold text-slate-900">{tafqeet(voucherFormData.amount, 'ريال يمني')}</span>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">بند الحساب والتصنيف</label>
                <input 
                  type="text" 
                  value={voucherFormData.category}
                  onChange={(e) => setVoucherFormData({ ...voucherFormData, category: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">البيان / ملاحظات السند</label>
                <textarea 
                  rows={2}
                  placeholder="وذلك مقابل..."
                  value={voucherFormData.notes}
                  onChange={(e) => setVoucherFormData({ ...voucherFormData, notes: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsVoucherModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 text-white font-bold rounded-lg transition-colors flex items-center gap-1.5 ${
                    modalType === 'receipt' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تأكيد السند وطباعته</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
