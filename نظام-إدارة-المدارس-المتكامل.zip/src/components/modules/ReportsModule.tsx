import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Printer, 
  Download, 
  Users, 
  DollarSign, 
  Award, 
  UserCheck, 
  FileText,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';

export const ReportsModule: React.FC = () => {
  const { 
    students, 
    feePlans, 
    vouchers, 
    employees, 
    grades, 
    attendance, 
    financialSummary, 
    studentSummary,
    schoolInfo, 
    openPrintModal,
    showToast 
  } = useSchool();

  const [activeReportCategory, setActiveReportCategory] = useState<'students' | 'financial' | 'academic' | 'staff'>('students');

  // Generic CSV exporter helper
  const exportCsvFile = (filename: string, headers: string[], rows: (string | number)[][]) => {
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`تم تصدير التقرير "${filename}" بصيغة Excel / CSV بنجاح`);
  };

  const handleExportStudentsReport = () => {
    const headers = ['رقم الطالب', 'الاسم الرباعي', 'الجنس', 'المرحلة', 'الصف', 'الشعبة', 'ولي الأمر', 'الهاتف', 'الحالة'];
    const rows = students.map(s => [
      s.id,
      `"${s.fullName}"`,
      s.gender,
      s.stage,
      `"${s.grade}"`,
      s.section,
      `"${s.parentName}"`,
      s.parentPhone,
      s.status
    ]);
    exportCsvFile('تقرير_الطلاب_الشامل', headers, rows);
  };

  const handleExportFinancialReport = () => {
    const headers = ['رقم السند', 'النوع', 'التاريخ', 'المبلغ', 'الطرف', 'البند', 'طريقة الدفع', 'البيان'];
    const rows = vouchers.map(v => [
      v.voucherNumber,
      v.type === 'receipt' ? 'سند قبض' : 'سند صرف',
      v.date,
      v.amount,
      `"${v.recipientOrPayer}"`,
      `"${v.category}"`,
      v.paymentMethod,
      `"${v.notes}"`
    ]);
    exportCsvFile('تقرير_الحركة_المالية_والسندات', headers, rows);
  };

  const handleExportGradesReport = () => {
    const headers = ['رقم الطالب', 'اسم الطالب', 'الفصل', 'المادة', 'شهري 1', 'شهري 2', 'أنشطة', 'نهائي', 'المجموع', 'التقدير'];
    const rows = grades.map(g => {
      const student = students.find(s => s.id === g.studentId);
      return [
        g.studentId,
        `"${student?.fullName || 'طالب'}"`,
        g.term,
        `"${g.subject}"`,
        g.monthlyScore1,
        g.monthlyScore2,
        g.activitiesScore,
        g.finalExamScore,
        g.totalScore,
        g.gradeLetter
      ];
    });
    exportCsvFile('تقرير_الدرجات_والنتائج_الكنترول', headers, rows);
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Top Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
              <span>التقارير الإدارية والمالية والتعليمية</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              استخراج الكشوفات الرسمية، الطباعة المباشرة، وتصدير ملفات Excel لجميع أقسام المدرسة
            </p>
          </div>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors self-start sm:self-auto shadow-2xs"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة التقرير الحالي</span>
          </button>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg overflow-x-auto hide-scrollbar">
          <button
            onClick={() => setActiveReportCategory('students')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeReportCategory === 'students' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تقارير شؤون الطلاب
          </button>
          <button
            onClick={() => setActiveReportCategory('financial')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeReportCategory === 'financial' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            التقارير المالية والتحصيل
          </button>
          <button
            onClick={() => setActiveReportCategory('academic')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeReportCategory === 'academic' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            التقارير التعليمية والنتائج
          </button>
          <button
            onClick={() => setActiveReportCategory('staff')}
            className={`px-3 py-1.5 rounded-md font-semibold whitespace-nowrap transition-colors ${
              activeReportCategory === 'staff' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تقارير الكادر والموظفين
          </button>
        </div>
      </div>

      {/* STUDENTS REPORTS */}
      {activeReportCategory === 'students' && (
        <div className="space-y-3">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">كشف الطلاب العام الشامل</h3>
              <p className="text-slate-500 text-[11px]">يتضمن بيانات الطالب الكاملة، الصفوف، والشعب، ومعلومات أولياء الأمور</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleExportStudentsReport}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تصدير Excel</span>
              </button>
              <button
                onClick={() => openPrintModal('student_list', students)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center gap-1 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-slate-500 font-semibold mb-1">المرحلة الأساسية (1 - 6)</div>
              <div className="font-mono text-xl font-bold text-slate-900">
                {students.filter(s => s.stage === 'primary').length} طالب وطالبة
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-slate-500 font-semibold mb-1">المرحلة الإعدادية (7 - 9)</div>
              <div className="font-mono text-xl font-bold text-slate-900">
                {students.filter(s => s.stage === 'middle').length} طالب وطالبة
              </div>
            </div>
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-slate-500 font-semibold mb-1">المرحلة الثانوية (10 - 12)</div>
              <div className="font-mono text-xl font-bold text-slate-900">
                {students.filter(s => s.stage === 'secondary').length} طالب وطالبة
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FINANCIAL REPORTS */}
      {activeReportCategory === 'financial' && (
        <div className="space-y-3">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">تقرير السندات والتحصيل المالي التفصيلي</h3>
              <p className="text-slate-500 text-[11px]">كشف مفصل بجميع سندات القبض والصرف المرحلة في النظام</p>
            </div>
            <button
              onClick={handleExportFinancialReport}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير Excel</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 font-mono">
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] text-slate-500 font-sans">إجمالي الإيرادات</div>
              <div className="text-lg font-bold text-emerald-700 tabular-nums">
                {financialSummary.totalRevenue.toLocaleString()} ر.ي
              </div>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] text-slate-500 font-sans">إجمالي المصروفات</div>
              <div className="text-lg font-bold text-rose-700 tabular-nums">
                {financialSummary.totalExpenses.toLocaleString()} ر.ي
              </div>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] text-slate-500 font-sans">صافي الفائض التشغيلي</div>
              <div className="text-lg font-bold text-slate-900 tabular-nums">
                {financialSummary.netProfit.toLocaleString()} ر.ي
              </div>
            </div>
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="text-[11px] text-slate-500 font-sans">المتأخرات على الطلاب</div>
              <div className="text-lg font-bold text-amber-700 tabular-nums">
                {financialSummary.totalArrears.toLocaleString()} ر.ي
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ACADEMIC REPORTS */}
      {activeReportCategory === 'academic' && (
        <div className="space-y-3">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">شيت الدرجات والنتائج العامة</h3>
              <p className="text-slate-500 text-[11px]">سجل الدرجات المرصودة بالاختبارات الشهرية وأعمال السنة والنهائي</p>
            </div>
            <button
              onClick={handleExportGradesReport}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير Excel</span>
            </button>
          </div>
        </div>
      )}

      {/* STAFF REPORTS */}
      {activeReportCategory === 'staff' && (
        <div className="space-y-3">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h3 className="font-bold text-slate-900 text-sm mb-1">مسير رواتب الكادر التعليمي والإداري</h3>
            <p className="text-slate-500 text-[11px]">كشف الرواتب الأساسية والبدلات والخصميات والصافي</p>
          </div>
        </div>
      )}

    </div>
  );
};
