import React, { useState, useMemo } from 'react';
import { 
  Users, 
  UserPlus, 
  Search, 
  Filter, 
  Printer, 
  FileSpreadsheet, 
  CreditCard, 
  ArrowRightLeft, 
  UserCheck, 
  UserX, 
  Edit3, 
  Eye, 
  MoreVertical,
  X,
  FileText,
  Phone,
  MapPin,
  CheckCircle2
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Student, EducationStage } from '../../types';
import { allGrades, allSections, schoolStages } from '../../data/initialData';

export const StudentsModule: React.FC = () => {
  const { 
    students, 
    addStudent, 
    updateStudent, 
    transferStudent, 
    setStudentStatus, 
    searchQuery,
    openPrintModal,
    showToast
  } = useSchool();

  // Filters
  const [selectedStage, setSelectedStage] = useState<string>('all');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [selectedSection, setSelectedSection] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modals
  const [isRegisterOpen, setIsRegisterOpen] = useState(false);
  const [selectedStudentForView, setSelectedStudentForView] = useState<Student | null>(null);
  const [studentForTransfer, setStudentForTransfer] = useState<Student | null>(null);
  const [transferGrade, setTransferGrade] = useState<string>('');
  const [transferSection, setTransferSection] = useState<string>('أ');

  // New Student Form State
  const [formData, setFormData] = useState({
    fullName: '',
    gender: 'ذكر' as 'ذكر' | 'أنثى',
    birthDate: '2014-01-01',
    birthPlace: 'صنعاء',
    stage: 'primary' as EducationStage,
    grade: 'أول ابتدائي',
    section: 'أ',
    parentName: '',
    parentRelation: 'الأب',
    parentPhone: '77',
    parentJob: 'موظف',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - حي ',
    photoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=200&h=200&q=80',
    discountType: 'لا يوجد',
    discountPercent: 0
  });

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const matchSearch = searchQuery === '' || 
        s.fullName.includes(searchQuery) ||
        s.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.parentPhone.includes(searchQuery) ||
        s.grade.includes(searchQuery);

      const matchStage = selectedStage === 'all' || s.stage === selectedStage;
      const matchGrade = selectedGrade === 'all' || s.grade === selectedGrade;
      const matchSection = selectedSection === 'all' || s.section === selectedSection;
      const matchStatus = selectedStatus === 'all' || s.status === selectedStatus;

      return matchSearch && matchStage && matchGrade && matchSection && matchStatus;
    });
  }, [students, searchQuery, selectedStage, selectedGrade, selectedSection, selectedStatus]);

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim() || !formData.parentName.trim() || !formData.parentPhone.trim()) {
      showToast('يرجى تعبئة الحقول الأساسية للطالب وولي الأمر', 'error');
      return;
    }

    const discounts = formData.discountPercent > 0 ? [
      {
        type: formData.discountType,
        percentage: formData.discountPercent,
        amount: Math.round((formData.stage === 'primary' ? 350000 : 450000) * (formData.discountPercent / 100)),
        notes: 'ممنوح عند التسجيل'
      }
    ] : [];

    addStudent({
      fullName: formData.fullName,
      gender: formData.gender,
      birthDate: formData.birthDate,
      birthPlace: formData.birthPlace,
      stage: formData.stage,
      grade: formData.grade,
      section: formData.section,
      parentName: formData.parentName,
      parentRelation: formData.parentRelation,
      parentPhone: formData.parentPhone,
      parentJob: formData.parentJob,
      parentSocialStatus: formData.parentSocialStatus,
      address: formData.address,
      photoUrl: formData.photoUrl,
      status: 'منتظم',
      discounts,
      documents: [{ name: 'شهادة الميلاد الأصلية', type: 'PDF', date: new Date().toISOString().split('T')[0] }]
    });

    setIsRegisterOpen(false);
    // Reset form
    setFormData({
      fullName: '',
      gender: 'ذكر',
      birthDate: '2014-01-01',
      birthPlace: 'صنعاء',
      stage: 'primary',
      grade: 'أول ابتدائي',
      section: 'أ',
      parentName: '',
      parentRelation: 'الأب',
      parentPhone: '77',
      parentJob: 'موظف',
      parentSocialStatus: 'متزوج',
      address: 'صنعاء - حي ',
      photoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=200&h=200&q=80',
      discountType: 'لا يوجد',
      discountPercent: 0
    });
  };

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentForTransfer || !transferGrade) return;
    transferStudent(studentForTransfer.id, transferGrade, transferSection);
    setStudentForTransfer(null);
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['الرقم الطلابي', 'الاسم الرباعي', 'الجنس', 'الصف', 'الشعبة', 'ولي الأمر', 'هاتف ولي الأمر', 'الحالة', 'العنوان'];
    const rows = filteredStudents.map(s => [
      s.id,
      `"${s.fullName}"`,
      s.gender,
      `"${s.grade}"`,
      s.section,
      `"${s.parentName}"`,
      s.parentPhone,
      s.status,
      `"${s.address}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `كشف_الطلاب_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('تم تصدير كشف الطلاب بصيغة Excel / CSV بنجاح');
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-600" />
            <span>سجل الطلاب والشعب المدرسية</span>
          </h2>
          <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
            <span>إجمالي الطلاب: {students.length}</span>
            <span>·</span>
            <span>النتائج المعروضة: {filteredStudents.length}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
            title="تصدير كشف إكسل"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span className="hidden sm:inline">تصدير إكسل</span>
          </button>
          
          <button
            onClick={() => openPrintModal('student_list', filteredStudents)}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
            title="طباعة الكشف الرسمي"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>طباعة الكشف</span>
          </button>

          <button
            onClick={() => setIsRegisterOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors shadow-xs"
          >
            <UserPlus className="w-4 h-4" />
            <span>تسجيل طالب جديد</span>
          </button>
        </div>
      </div>

      {/* Filter Row */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">المرحلة الدراسية</label>
          <select 
            value={selectedStage}
            onChange={(e) => {
              setSelectedStage(e.target.value);
              setSelectedGrade('all');
            }}
            className="w-full p-1.5 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white"
          >
            <option value="all">جميع المراحل</option>
            <option value="primary">الأساسي (1 - 6)</option>
            <option value="middle">الأساسي الأعلى (7 - 9)</option>
            <option value="secondary">المرحلة الثانوية</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">الصف الدراسي</label>
          <select 
            value={selectedGrade}
            onChange={(e) => setSelectedGrade(e.target.value)}
            className="w-full p-1.5 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white"
          >
            <option value="all">جميع الصفوف</option>
            {allGrades.map(g => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">الشعبة</label>
          <select 
            value={selectedSection}
            onChange={(e) => setSelectedSection(e.target.value)}
            className="w-full p-1.5 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white"
          >
            <option value="all">جميع الشعب</option>
            {allSections.map(s => (
              <option key={s} value={s}>شعبة ({s})</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">حالة القيد</label>
          <select 
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full p-1.5 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white"
          >
            <option value="all">جميع الحالات</option>
            <option value="منتظم">منتظم</option>
            <option value="منقول">منقول</option>
            <option value="مرقن قيد">مرقن قيد</option>
            <option value="معاد قيد">معاد قيد</option>
          </select>
        </div>
      </div>

      {/* Students Table / Mobile Cards */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        {filteredStudents.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            لا توجد سجلات تطابق معايير البحث والفلترة المحددة.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                <tr>
                  <th className="p-3">الطالب</th>
                  <th className="p-3">الصف والشعبة</th>
                  <th className="p-3">ولي الأمر والتواصل</th>
                  <th className="p-3">حالة القيد</th>
                  <th className="p-3 text-center">إجراءات الطالب</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.map(student => (
                  <tr key={student.id} className="hover:bg-slate-50/80 transition-colors">
                    
                    {/* Student Name & ID */}
                    <td className="p-3">
                      <div className="flex items-center gap-2.5">
                        <img 
                          src={student.photoUrl} 
                          alt={student.fullName}
                          referrerPolicy="no-referrer"
                          className="w-9 h-9 rounded-full object-cover shrink-0 border border-slate-200"
                        />
                        <div>
                          <div className="font-bold text-slate-900">{student.fullName}</div>
                          <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5">
                            <span>{student.id}</span>
                            <span>·</span>
                            <span>{student.gender}</span>
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Grade & Section */}
                    <td className="p-3">
                      <div className="font-semibold text-slate-800">{student.grade}</div>
                      <div className="text-[11px] text-slate-500">شعبة ({student.section})</div>
                    </td>

                    {/* Parent Info */}
                    <td className="p-3">
                      <div className="text-slate-800">{student.parentName} ({student.parentRelation})</div>
                      <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{student.parentPhone}</span>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="p-3">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                        student.status === 'منتظم' ? 'bg-emerald-50 text-emerald-700' :
                        student.status === 'منقول' ? 'bg-blue-50 text-blue-700' :
                        student.status === 'مرقن قيد' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'
                      }`}>
                        {student.status}
                      </span>
                    </td>

                    {/* Operations */}
                    <td className="p-3">
                      <div className="flex items-center justify-center gap-1">
                        {/* Student ID Card Print */}
                        <button
                          onClick={() => openPrintModal('card', student)}
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors"
                          title="طباعة بطاقة الطالب المدرسية"
                        >
                          <CreditCard className="w-4 h-4" />
                        </button>

                        {/* Admission Form Print */}
                        <button
                          onClick={() => openPrintModal('admission_form', student)}
                          className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-slate-100 rounded-lg transition-colors"
                          title="طباعة استمارة التسجيل الرسمية"
                        >
                          <FileText className="w-4 h-4" />
                        </button>

                        {/* Transfer Button */}
                        <button
                          onClick={() => {
                            setStudentForTransfer(student);
                            setTransferGrade(student.grade);
                            setTransferSection(student.section);
                          }}
                          className="p-1.5 text-slate-500 hover:text-amber-700 hover:bg-slate-100 rounded-lg transition-colors"
                          title="نقل الطالب لصف أو شعبة أخرى"
                        >
                          <ArrowRightLeft className="w-4 h-4" />
                        </button>

                        {/* View Details */}
                        <button
                          onClick={() => setSelectedStudentForView(student)}
                          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                          title="عرض ملف الطالب"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL: Register New Student */}
      {isRegisterOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-2xl border border-slate-200 shadow-2xl overflow-hidden my-6">
            <div className="p-4 bg-emerald-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5" />
                <h3 className="font-bold text-sm sm:text-base">استمارة تسجيل وقيد طالب جديد</h3>
              </div>
              <button onClick={() => setIsRegisterOpen(false)} className="text-white/80 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRegisterSubmit} className="p-4 sm:p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs">
              
              {/* Section 1: Basic Info */}
              <div>
                <div className="font-bold text-slate-800 text-sm mb-2 pb-1 border-b border-slate-100">
                  1. بيانات الطالب الأساسية
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">الاسم الرباعي للطالب *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="مثال: يحيى أحمد علي الحاوري"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">الجنس *</label>
                      <select 
                        value={formData.gender}
                        onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                        className="w-full p-2 border border-slate-300 rounded-lg"
                      >
                        <option value="ذكر">ذكر</option>
                        <option value="أنثى">أنثى</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">مكان الميلاد</label>
                      <input 
                        type="text" 
                        value={formData.birthPlace}
                        onChange={(e) => setFormData({ ...formData, birthPlace: e.target.value })}
                        className="w-full p-2 border border-slate-300 rounded-lg"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">تاريخ الميلاد *</label>
                    <input 
                      type="date" 
                      required
                      value={formData.birthDate}
                      onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">المرحلة والصف *</label>
                    <select 
                      value={formData.grade}
                      onChange={(e) => {
                        const grade = e.target.value;
                        let stage: EducationStage = 'primary';
                        if (['سابع أساسي', 'ثامن أساسي', 'تاسع أساسي'].includes(grade)) stage = 'middle';
                        if (grade.includes('ثانوي')) stage = 'secondary';
                        setFormData({ ...formData, grade, stage });
                      }}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    >
                      {allGrades.map(g => (
                        <option key={g} value={g}>{g}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">الشعبة الموزع عليها</label>
                    <select 
                      value={formData.section}
                      onChange={(e) => setFormData({ ...formData, section: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    >
                      {allSections.map(s => (
                        <option key={s} value={s}>شعبة ({s})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">رابط صورة الطالب</label>
                    <input 
                      type="text" 
                      value={formData.photoUrl}
                      onChange={(e) => setFormData({ ...formData, photoUrl: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: Parent Info */}
              <div>
                <div className="font-bold text-slate-800 text-sm mb-2 pb-1 border-b border-slate-100">
                  2. بيانات ولي الأمر والتواصل
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">اسم ولي الأمر الرباعي *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="اسم الأب أو الوصي الشرعي"
                      value={formData.parentName}
                      onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">صلة القرابة</label>
                    <select 
                      value={formData.parentRelation}
                      onChange={(e) => setFormData({ ...formData, parentRelation: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    >
                      <option value="الأب">الأب</option>
                      <option value="الأم">الأم</option>
                      <option value="العم">العم</option>
                      <option value="الأخ">الأخ</option>
                      <option value="الجد">الجد</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">رقم الهاتف الجوال (واتساب) *</label>
                    <input 
                      type="tel" 
                      required
                      placeholder="مثال: 771234567"
                      value={formData.parentPhone}
                      onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">مهنة ولي الأمر</label>
                    <input 
                      type="text" 
                      value={formData.parentJob}
                      onChange={(e) => setFormData({ ...formData, parentJob: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">عنوان السكن بالتفصيل</label>
                    <input 
                      type="text" 
                      placeholder="المدينة - الحي - الشارع - جوار..."
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Fees & Discounts */}
              <div>
                <div className="font-bold text-slate-800 text-sm mb-2 pb-1 border-b border-slate-100">
                  3. الرسوم والخصومات الممنوحة
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">نوع الخصم / المنحة</label>
                    <select 
                      value={formData.discountType}
                      onChange={(e) => setFormData({ ...formData, discountType: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    >
                      <option value="لا يوجد">لا يوجد خصم</option>
                      <option value="خصم إخوة">خصم إخوة (10%)</option>
                      <option value="خصم تفوق">خصم تفوق (15%)</option>
                      <option value="منحة أبناء معلمين">منحة أبناء معلمين (20%)</option>
                      <option value="منحة أيتام">منحة أيتام (50%)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">نسبة الخصم %</label>
                    <input 
                      type="number" 
                      min="0" 
                      max="100"
                      value={formData.discountPercent}
                      onChange={(e) => setFormData({ ...formData, discountPercent: Number(e.target.value) })}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRegisterOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors"
                >
                  حفظ وتسجيل الطالب
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* MODAL: Transfer Student */}
      {studentForTransfer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 text-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-2">
              نقل وتعديل صف الطالب: {studentForTransfer.fullName}
            </h3>
            <p className="text-slate-500 mb-4">
              الصف الحالي: {studentForTransfer.grade} (شعبة {studentForTransfer.section})
            </p>

            <form onSubmit={handleTransferSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">الصف الدراسي الجديد</label>
                <select 
                  value={transferGrade}
                  onChange={(e) => setTransferGrade(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  {allGrades.map(g => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">الشعبة الجديدة</label>
                <select 
                  value={transferSection}
                  onChange={(e) => setTransferSection(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  {allSections.map(s => (
                    <option key={s} value={s}>شعبة ({s})</option>
                  ))}
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStudentForTransfer(null)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 text-white font-bold rounded-lg"
                >
                  تأكيد النقل
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Student Profile Details View */}
      {selectedStudentForView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-lg border border-slate-200 shadow-2xl p-5 text-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <img 
                  src={selectedStudentForView.photoUrl} 
                  alt={selectedStudentForView.fullName}
                  className="w-12 h-12 rounded-full object-cover border"
                />
                <div>
                  <h3 className="font-bold text-slate-900 text-sm">{selectedStudentForView.fullName}</h3>
                  <div className="text-slate-400 font-mono">{selectedStudentForView.id}</div>
                </div>
              </div>
              <button onClick={() => setSelectedStudentForView(null)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-slate-700">
              <div><span className="text-slate-400">الصف والشعبة:</span> {selectedStudentForView.grade} - {selectedStudentForView.section}</div>
              <div><span className="text-slate-400">تاريخ الميلاد:</span> {selectedStudentForView.birthDate} ({selectedStudentForView.birthPlace})</div>
              <div><span className="text-slate-400">ولي الأمر:</span> {selectedStudentForView.parentName}</div>
              <div><span className="text-slate-400">رقم الهاتف:</span> {selectedStudentForView.parentPhone}</div>
              <div className="col-span-2"><span className="text-slate-400">العنوان:</span> {selectedStudentForView.address}</div>
              <div><span className="text-slate-400">تاريخ التسجيل:</span> {selectedStudentForView.registrationDate}</div>
              <div><span className="text-slate-400">حالة القيد:</span> {selectedStudentForView.status}</div>
            </div>

            {/* Quick Status Toggles */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-2">
              <span className="text-[11px] font-semibold text-slate-500 self-center">تغيير الحالة:</span>
              <button 
                onClick={() => setStudentStatus(selectedStudentForView.id, 'منتظم')}
                className="px-2 py-1 bg-emerald-50 text-emerald-700 rounded border border-emerald-200 text-[11px] font-bold"
              >
                منتظم
              </button>
              <button 
                onClick={() => setStudentStatus(selectedStudentForView.id, 'مرقن قيد')}
                className="px-2 py-1 bg-rose-50 text-rose-700 rounded border border-rose-200 text-[11px] font-bold"
              >
                ترقين قيد
              </button>
              <button 
                onClick={() => setStudentStatus(selectedStudentForView.id, 'معاد قيد')}
                className="px-2 py-1 bg-amber-50 text-amber-700 rounded border border-amber-200 text-[11px] font-bold"
              >
                إعادة قيد
              </button>
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
              <button 
                onClick={() => {
                  openPrintModal('card', selectedStudentForView);
                  setSelectedStudentForView(null);
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg font-semibold flex items-center gap-1"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>طباعة البطاقة</span>
              </button>
              <button 
                onClick={() => {
                  openPrintModal('admission_form', selectedStudentForView);
                  setSelectedStudentForView(null);
                }}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>استمارة التسجيل</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
