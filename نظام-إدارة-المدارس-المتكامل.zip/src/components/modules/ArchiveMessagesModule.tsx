import React, { useState } from 'react';
import { 
  FolderArchive, 
  MessageSquare, 
  Plus, 
  Send, 
  FileText, 
  Trash2, 
  Download, 
  Upload, 
  CheckCircle2, 
  Share2, 
  Phone,
  FileCheck,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { ArchiveDocument, SchoolNotification } from '../../types';

export const ArchiveMessagesModule: React.FC = () => {
  const { 
    archiveDocs, 
    addArchiveDoc, 
    deleteArchiveDoc, 
    notifications, 
    sendNotification, 
    schoolInfo,
    students,
    showToast 
  } = useSchool();

  const [activeTab, setActiveTab] = useState<'archive' | 'messages'>('archive');
  
  // Archive Modal State
  const [isAddDocOpen, setIsAddDocOpen] = useState(false);
  const [docData, setDocData] = useState({
    title: '',
    category: 'ملفات طلاب' as ArchiveDocument['category'],
    fileName: 'document.pdf',
    fileSize: '2.1 MB',
    referenceId: '',
    notes: ''
  });

  // Message Modal State
  const [isNewMsgOpen, setIsNewMsgOpen] = useState(false);
  const [msgData, setMsgData] = useState({
    title: 'تذكير بسداد القسط الدراسي الثاني',
    content: 'المكرم ولي الأمر، نود تذكيركم بموعد سداد القسط الثاني للرسوم الدراسية...',
    targetAudience: 'أولياء الأمور' as const,
    type: 'مالي' as const,
    channel: 'واتساب' as const
  });

  const handleAddDocSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!docData.title.trim()) return;
    addArchiveDoc({
      title: docData.title,
      category: docData.category,
      fileName: docData.fileName,
      fileSize: docData.fileSize,
      referenceId: docData.referenceId,
      notes: docData.notes
    });
    setIsAddDocOpen(false);
    setDocData({
      title: '',
      category: 'ملفات طلاب',
      fileName: 'document.pdf',
      fileSize: '2.1 MB',
      referenceId: '',
      notes: ''
    });
  };

  const handleSendMsgSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgData.title.trim() || !msgData.content.trim()) return;

    sendNotification({
      title: msgData.title,
      content: msgData.content,
      targetAudience: msgData.targetAudience,
      type: msgData.type,
      channel: msgData.channel,
      status: 'مرسل'
    });

    setIsNewMsgOpen(false);
  };

  const handleWhatsAppBroadcast = (content: string) => {
    const encoded = encodeURIComponent(`${schoolInfo.name}\n\n${content}`);
    window.open(`https://wa.me/?text=${encoded}`, '_blank');
    showToast('تم فتح واتساب لبدء النشر والإرسال');
  };

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Header and Switcher */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              {activeTab === 'archive' ? (
                <FolderArchive className="w-5 h-5 text-emerald-600" />
              ) : (
                <MessageSquare className="w-5 h-5 text-emerald-600" />
              )}
              <span>{activeTab === 'archive' ? 'الأرشيف الإلكتروني والوثائق' : 'الرسائل والإشعارات المدرسية'}</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              {activeTab === 'archive' ? 'حفظ وأرشفة ملفات الطلاب، الموظفين، العقود والتعاميم الرسمية' : 'إرسال التنبيهات وتذكيرات الرسوم والغياب عبر واتساب وSMS'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'archive' ? (
              <button
                onClick={() => setIsAddDocOpen(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
              >
                <Plus className="w-4 h-4" />
                <span>أرشفة وثيقة جديدة</span>
              </button>
            ) : (
              <button
                onClick={() => setIsNewMsgOpen(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء رسالة إشعار</span>
              </button>
            )}
          </div>
        </div>

        {/* Subtabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setActiveTab('archive')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeTab === 'archive' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            سجلات الأرشيف الإلكتروني ({archiveDocs.length})
          </button>
          <button
            onClick={() => setActiveTab('messages')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              activeTab === 'messages' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            الرسائل والإشعارات المرسلة ({notifications.length})
          </button>
        </div>
      </div>

      {/* ARCHIVE TAB */}
      {activeTab === 'archive' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-3 bg-slate-50 border-b border-slate-200 font-bold text-slate-800 flex items-center justify-between">
            <span>الملفات والمستندات المؤرشفة رقمياً</span>
            <span className="text-[11px] text-slate-500">حفظ مشفر وآمن محلياً</span>
          </div>

          <div className="divide-y divide-slate-100">
            {archiveDocs.map(doc => (
              <div key={doc.id} className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 text-sm leading-tight">{doc.title}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                      <span className="text-teal-800 font-semibold">{doc.category}</span>
                      <span>·</span>
                      <span>{doc.date}</span>
                      <span>·</span>
                      <span className="font-mono text-slate-400">{doc.fileSize}</span>
                    </div>
                    {doc.notes && <div className="text-[11px] text-slate-400 mt-1">{doc.notes}</div>}
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => showToast(`تم تنزيل الوثيقة: ${doc.fileName}`)}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>تحميل</span>
                  </button>
                  <button
                    onClick={() => deleteArchiveDoc(doc.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                    title="حذف من الأرشيف"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MESSAGES TAB */}
      {activeTab === 'messages' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {notifications.map(n => (
              <div key={n.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-slate-900 text-sm">{n.title}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {n.channel}
                    </span>
                  </div>
                  <p className="text-slate-600 text-xs leading-relaxed">{n.content}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>{n.date} · موجه إلى: {n.targetAudience}</span>
                  
                  <button
                    onClick={() => handleWhatsAppBroadcast(n.content)}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md font-semibold flex items-center gap-1 text-[11px] transition-colors"
                    title="إعادة إرسال عبر واتساب"
                  >
                    <Share2 className="w-3 h-3" />
                    <span>مشاركة واتساب</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: Add Document */}
      {isAddDocOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">أرشفة وحفظ وثيقة جديدة</h3>
              <button onClick={() => setIsAddDocOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDocSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">عنوان الوثيقة *</label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: شهادة ميلاد الطالب / عقد إيجار المبنى"
                  value={docData.title}
                  onChange={(e) => setDocData({ ...docData, title: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">تصنيف الوثيقة</label>
                <select
                  value={docData.category}
                  onChange={(e) => setDocData({ ...docData, category: e.target.value as any })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  <option value="ملفات طلاب">ملفات طلاب</option>
                  <option value="ملفات موظفين">ملفات موظفين</option>
                  <option value="عقود واتفاقيات">عقود واتفاقيات</option>
                  <option value="تعاميم وزارية">تعاميم وزارية</option>
                  <option value="سجلات مالية">سجلات مالية</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">اسم الملف والمرفق</label>
                <input 
                  type="text" 
                  value={docData.fileName}
                  onChange={(e) => setDocData({ ...docData, fileName: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">ملاحظات إضافية</label>
                <textarea 
                  rows={2}
                  value={docData.notes}
                  onChange={(e) => setDocData({ ...docData, notes: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddDocOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  حفظ في الأرشيف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Create Message */}
      {isNewMsgOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">إرسال إشعار / رسالة جماعية</h3>
              <button onClick={() => setIsNewMsgOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendMsgSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">عنوان الإشعار *</label>
                <input 
                  type="text" 
                  required
                  value={msgData.title}
                  onChange={(e) => setMsgData({ ...msgData, title: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الفئة المستهدفة</label>
                  <select
                    value={msgData.targetAudience}
                    onChange={(e) => setMsgData({ ...msgData, targetAudience: e.target.value as any })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option value="أولياء الأمور">أولياء الأمور</option>
                    <option value="المعلمون">المعلمون والكادر</option>
                    <option value="الكل">الجميع</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">قناة الإرسال</label>
                  <select
                    value={msgData.channel}
                    onChange={(e) => setMsgData({ ...msgData, channel: e.target.value as any })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option value="واتساب">واتساب (مباشر)</option>
                    <option value="رسائل نصية">رسائل نصية SMS</option>
                    <option value="إشعار داخلي">إشعار نظام داخلي</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">نص الرسالة *</label>
                <textarea 
                  rows={4}
                  required
                  value={msgData.content}
                  onChange={(e) => setMsgData({ ...msgData, content: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsNewMsgOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>إرسال واعتماد</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
