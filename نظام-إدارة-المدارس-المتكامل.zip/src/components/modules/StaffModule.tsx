import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  DollarSign, 
  Printer, 
  FileText, 
  Phone, 
  Briefcase, 
  CheckCircle2,
  AlertCircle,
  X
} from 'lucide-react';
import { useSchool } from '../../context/SchoolContext';
import { Employee } from '../../types';

export const StaffModule: React.FC = () => {
  const { 
    employees, 
    addEmployee, 
    updateEmployee, 
    disburseSalary, 
    schoolInfo, 
    showToast 
  } = useSchool();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState('أكتوبر 2026');

  const [formData, setFormData] = useState({
    fullName: '',
    role: 'معلم',
    phone: '77',
    qualification: 'بكالوريوس تربية',
    specialization: 'لغة عربية',
    hireDate: '2026-09-01',
    baseSalary: 200000,
    allowances: 25000,
    deductions: 0
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim() || formData.baseSalary <= 0) {
      showToast('يرجى كتابة اسم الموظف والراتب الأساسي', 'error');
      return;
    }

    const net = formData.baseSalary + formData.allowances - formData.deductions;

    addEmployee({
      fullName: formData.fullName,
      role: formData.role,
      phone: formData.phone,
      qualification: formData.qualification,
      specialization: formData.specialization,
      hireDate: formData.hireDate,
      baseSalary: formData.baseSalary,
      allowances: formData.allowances,
      deductions: formData.deductions,
      netSalary: net,
      status: 'على رأس العمل'
    });

    setIsAddOpen(false);
    setFormData({
      fullName: '',
      role: 'معلم',
      phone: '77',
      qualification: 'بكالوريوس تربية',
      specialization: 'لغة عربية',
      hireDate: '2026-09-01',
      baseSalary: 200000,
      allowances: 25000,
      deductions: 0
    });
  };

  const totalPayroll = employees.reduce((sum, e) => sum + e.netSalary, 0);

  return (
    <div className="space-y-4 pb-16 sm:pb-8 text-xs">
      
      {/* Top Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-600" />
              <span>إدارة الموظفين ومسير الرواتب</span>
            </h2>
            <p className="text-slate-500 text-[11px] mt-0.5">
              بيانات الكادر، البدلات، الخصومات، وصرف مسير الرواتب المعتمد
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAddOpen(true)}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-2xs"
            >
              <UserPlus className="w-4 h-4" />
              <span>إضافة موظف جديد</span>
            </button>
          </div>
        </div>

        {/* Payroll Summary Bar */}
        <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="font-bold text-slate-700">مسير شهر:</span>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="p-1 border border-slate-300 rounded bg-white text-xs font-semibold"
            >
              <option value="سبتمبر 2026">سبتمبر 2026</option>
              <option value="أكتوبر 2026">أكتوبر 2026</option>
              <option value="نوفمبر 2026">نوفمبر 2026</option>
              <option value="ديسمبر 2026">ديسمبر 2026</option>
            </select>
            <span className="text-slate-400">·</span>
            <span className="text-slate-600">إجمالي الكادر: {employees.length} موظف</span>
          </div>

          <div className="font-mono text-xs">
            <span className="text-slate-500">إجمالي الرواتب الصافية: </span>
            <span className="font-bold text-emerald-700 text-sm tabular-nums">
              {totalPayroll.toLocaleString()} ر.ي
            </span>
          </div>
        </div>
      </div>

      {/* Employees Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <table className="w-full text-right">
          <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
            <tr>
              <th className="p-3">الموظف</th>
              <th className="p-3">الوظيفة والتخصص</th>
              <th className="p-3">الهاتف</th>
              <th className="p-3 text-left">الأساسي</th>
              <th className="p-3 text-left">البدلات (+)</th>
              <th className="p-3 text-left">الخصميات (-)</th>
              <th className="p-3 text-left">الصافي المستحق</th>
              <th className="p-3 text-center">صرف الراتب</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono">
            {employees.map(emp => (
              <tr key={emp.id} className="hover:bg-slate-50">
                <td className="p-3 font-sans font-bold text-slate-900">
                  {emp.fullName}
                  <span className="block font-mono text-[10px] text-slate-400 font-normal">{emp.id}</span>
                </td>
                <td className="p-3 font-sans">
                  <div className="font-semibold text-slate-800">{emp.role}</div>
                  <div className="text-[10px] text-slate-500">{emp.specialization}</div>
                </td>
                <td className="p-3 font-sans text-slate-600">{emp.phone}</td>
                <td className="p-3 text-left text-slate-700 tabular-nums">{emp.baseSalary.toLocaleString()}</td>
                <td className="p-3 text-left text-emerald-700 tabular-nums">+{emp.allowances.toLocaleString()}</td>
                <td className="p-3 text-left text-rose-700 tabular-nums">-{emp.deductions.toLocaleString()}</td>
                <td className="p-3 text-left font-bold text-slate-900 tabular-nums text-sm">
                  {emp.netSalary.toLocaleString()} ر.ي
                </td>
                <td className="p-3 font-sans text-center">
                  <button
                    onClick={() => disburseSalary(emp.id, selectedMonth)}
                    className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded font-semibold text-[11px] transition-colors inline-flex items-center gap-1"
                    title="صرف الراتب وتوليد سند صرف معتمد"
                  >
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>صرف وسند</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* MODAL: Add New Employee */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl w-full max-w-lg border border-slate-200 shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">إضافة موظف / معلم جديد</h3>
              <button onClick={() => setIsAddOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">الاسم الرباعي للموظف *</label>
                <input 
                  type="text" 
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الوظيفة / المسمى *</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option value="معلم">معلم</option>
                    <option value="معلمة">معلمة</option>
                    <option value="وكيل شؤون معلمين">وكيل شؤون معلمين</option>
                    <option value="وكيل شؤون طلاب">وكيل شؤون طلاب</option>
                    <option value="محاسب">محاسب</option>
                    <option value="أمين مكتبة">أمين مكتبة</option>
                    <option value="أمين مخزن">أمين مخزن</option>
                    <option value="إداري">إداري</option>
                    <option value="مشرف حركة وباصات">مشرف حركة وباصات</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الهاتف الجوال *</label>
                  <input 
                    type="tel" 
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">المؤهل العلمي</label>
                  <input 
                    type="text" 
                    value={formData.qualification}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">التخصص الدقيق</label>
                  <input 
                    type="text" 
                    value={formData.specialization}
                    onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الراتب الأساسي *</label>
                  <input 
                    type="number" 
                    required
                    value={formData.baseSalary}
                    onChange={(e) => setFormData({ ...formData, baseSalary: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">البدلات</label>
                  <input 
                    type="number" 
                    value={formData.allowances}
                    onChange={(e) => setFormData({ ...formData, allowances: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 mb-1">الخصميات</label>
                  <input 
                    type="number" 
                    value={formData.deductions}
                    onChange={(e) => setFormData({ ...formData, deductions: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-600 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg"
                >
                  حفظ وتعيين الموظف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
