export type SchoolRole = 
  | 'admin'          // مدير النظام
  | 'principal'      // المدير العام
  | 'accountant'     // المحاسب
  | 'student_affairs'// شؤون الطلاب
  | 'control'        // الكنترول والاختبارات
  | 'archive'        // الأرشيف والوثائق
  | 'teacher';       // المعلم

export interface UserAccount {
  id: string;
  name: string;
  username: string;
  role: SchoolRole;
  roleLabel: string;
  avatar?: string;
}

export type EducationStage = 'primary' | 'middle' | 'secondary';

export interface SchoolInfo {
  name: string;
  subName: string;
  logo: string;
  seal: string;
  phone: string;
  phoneAlt: string;
  email: string;
  address: string;
  city: string;
  currentYear: string;
  currentTerm: 'الفصل الأول' | 'الفصل الثاني';
  branches: string[];
}

export interface Student {
  id: string; // STU-2026-001
  fullName: string;
  gender: 'ذكر' | 'أنثى';
  birthDate: string;
  birthPlace: string;
  stage: EducationStage;
  grade: string; // e.g. "أول ابتدائي", "سابع", "ثالث ثانوي علمي"
  section: string; // e.g. "أ", "ب", "ج"
  parentName: string;
  parentRelation: string;
  parentPhone: string;
  parentJob: string;
  parentSocialStatus: string;
  address: string;
  photoUrl: string;
  status: 'منتظم' | 'منقول' | 'مرقن قيد' | 'معاد قيد';
  registrationDate: string;
  discounts: {
    type: string;
    percentage: number;
    amount: number;
    notes?: string;
  }[];
  documents: {
    name: string;
    type: string;
    date: string;
  }[];
}

export interface FeeItem {
  id: string;
  title: string;
  category: 'تسجيل' | 'دراسة' | 'امتحانات' | 'مواصلات' | 'أنشطة' | 'كتب' | 'أخرى';
  grade: string;
  amount: number;
}

export interface StudentFeePlan {
  studentId: string;
  academicYear: string;
  totalOriginal: number;
  totalDiscount: number;
  netRequired: number;
  totalPaid: number;
  remaining: number;
  installments: {
    id: string;
    title: string;
    dueDate: string;
    amount: number;
    paidAmount: number;
    status: 'مسدد' | 'جزئي' | 'متأخر' | 'قادم';
  }[];
}

export type VoucherType = 'receipt' | 'payment'; // قبض / صرف

export interface Voucher {
  id: string; // REC-001 or PAY-001
  type: VoucherType;
  voucherNumber: number;
  date: string;
  amount: number;
  amountInWords: string;
  recipientOrPayer: string; // استلمنا من / صرفنا إلى
  studentId?: string;
  category: string; // رسوم دراسة، رواتب، صيانة، إيجار، قرطاسية
  paymentMethod: 'نقداً - الصندوق' | 'حوالة مصرفية' | 'شيك بنكي' | 'بنك الكريمي' | 'محفظة جوال';
  accountFrom: string;
  accountTo: string;
  notes: string;
  preparedBy: string;
}

export interface AccountLedgerItem {
  code: string;
  name: string;
  type: 'أصول' | 'خصوم' | 'حقوق ملكية' | 'إيرادات' | 'مصروفات';
  balance: number;
}

export interface Employee {
  id: string; // EMP-001
  fullName: string;
  role: string; // مدير، معلم، وكيل، محاسب، إداري، مشرف
  phone: string;
  qualification: string;
  specialization: string;
  hireDate: string;
  baseSalary: number;
  allowances: number;
  deductions: number;
  netSalary: number;
  status: 'على رأس العمل' | 'إجازة' | 'منهي خدمته';
  subjects?: string[];
  assignedGrades?: string[];
}

export interface TeacherScheduleSlot {
  id: string;
  teacherId: string;
  day: 'السبت' | 'الأحد' | 'الإثنين' | 'الثلاثاء' | 'الأربعاء';
  period: number; // 1 to 6
  grade: string;
  section: string;
  subject: string;
}

export interface GradeRecord {
  id: string;
  studentId: string;
  academicYear: string;
  term: 'الفصل الأول' | 'الفصل الثاني';
  subject: string;
  monthlyScore1: number; // Max 20
  monthlyScore2: number; // Max 20
  activitiesScore: number; // Max 10
  finalExamScore: number; // Max 50
  totalScore: number; // Max 100
  gradeLetter: string; // ممتاز، جيد جداً...
  status: 'ناجح' | 'راسب' | 'مكمل';
}

export interface AttendanceRecord {
  id: string;
  date: string;
  type: 'student' | 'employee';
  targetId: string;
  grade?: string;
  section?: string;
  status: 'حاضر' | 'غائب' | 'متأخر' | 'معذور';
  notes?: string;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  isbn?: string;
  category: string;
  copiesTotal: number;
  copiesAvailable: number;
  loans: {
    id: string;
    borrowerName: string;
    borrowerType: 'طالب' | 'معلم';
    borrowDate: string;
    dueDate: string;
    returnDate?: string;
    status: 'معار' | 'مسترجع' | 'متأخر';
  }[];
}

export interface InventoryItem {
  id: string;
  name: string;
  category: 'كتب مدرسية' | 'قرطاسية' | 'أثاث مدرسي' | 'مستلزمات معامل' | 'زي مدرسي';
  quantity: number;
  unit: string;
  minThreshold: number;
  unitPrice: number;
  lastUpdated: string;
}

export interface SchoolNotification {
  id: string;
  title: string;
  content: string;
  date: string;
  targetAudience: 'أولياء الأمور' | 'المعلمون' | 'الكل';
  type: 'مالي' | 'غياب' | 'درجات' | 'عام';
  channel: 'واتساب' | 'رسائل نصية' | 'إشعار داخلي';
  status: 'مرسل' | 'مسودة';
}

export interface ArchiveDocument {
  id: string;
  title: string;
  category: 'ملفات طلاب' | 'ملفات موظفين' | 'عقود واتفاقيات' | 'تعاميم وزارية' | 'سجلات مالية';
  date: string;
  fileSize: string;
  referenceId?: string;
  fileName: string;
  notes: string;
}
