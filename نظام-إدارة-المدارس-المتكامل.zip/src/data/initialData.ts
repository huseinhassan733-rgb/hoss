import { 
  SchoolInfo, 
  Student, 
  FeeItem, 
  StudentFeePlan, 
  Voucher, 
  AccountLedgerItem, 
  Employee, 
  TeacherScheduleSlot, 
  GradeRecord, 
  AttendanceRecord, 
  LibraryBook, 
  InventoryItem, 
  SchoolNotification, 
  ArchiveDocument 
} from '../types';

export const initialSchoolInfo: SchoolInfo = {
  name: 'مدارس النهضة الحديثة الأهلية النموذجية',
  subName: 'الجمهورية اليمنية - وزارة التربية والتعليم - أمانة العاصمة',
  logo: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=200&h=200&q=80',
  seal: 'ختم الإدارة المدرسية المعتمد',
  phone: '01-445566',
  phoneAlt: '777-123456',
  email: 'info@alnahda-school.edu.ye',
  address: 'صنعاء - حي حدة - جوار بريد حدة',
  city: 'صنعاء',
  currentYear: '2026 / 2027 م',
  currentTerm: 'الفصل الأول',
  branches: ['الفرع الرئيسي (بنين - حدة)', 'فرع البنات (الأصبحي)', 'فرع التمهيدي والأساسي (حدة)'],
};

export const schoolStages = [
  { id: 'primary', name: 'المرحلة الأساسية (1 - 6)', grades: ['أول ابتدائي', 'ثاني ابتدائي', 'ثالث ابتدائي', 'رابع ابتدائي', 'خامس ابتدائي', 'سادس ابتدائي'] },
  { id: 'middle', name: 'المرحلة الأساسية العليا (7 - 9)', grades: ['سابع أساسي', 'ثامن أساسي', 'تاسع أساسي'] },
  { id: 'secondary', name: 'المرحلة الثانوية (10 - 12)', grades: ['أول ثانوي', 'ثاني ثانوي علمي', 'ثاني ثانوي أدبي', 'ثالث ثانوي علمي', 'ثالث ثانوي أدبي'] }
];

export const allGrades = [
  'أول ابتدائي', 'ثاني ابتدائي', 'ثالث ابتدائي', 'رابع ابتدائي', 'خامس ابتدائي', 'سادس ابتدائي',
  'سابع أساسي', 'ثامن أساسي', 'تاسع أساسي',
  'أول ثانوي', 'ثاني ثانوي علمي', 'ثاني ثانوي أدبي', 'ثالث ثانوي علمي', 'ثالث ثانوي أدبي'
];

export const allSections = ['أ', 'ب', 'ج'];

export const yemeniSubjects = [
  'القرآن الكريم وعلومه',
  'التربية الإسلامية',
  'اللغة العربية (نحو وقراءة وإملاء)',
  'اللغة الإنجليزية',
  'الرياضيات',
  'العلوم العامة',
  'الفيزياء',
  'الكيمياء',
  'الأحياء',
  'الاجتماعيات (تاريخ وجغرافيا ووطنية)',
  'الحاسوب وتقنية المعلومات'
];

export const initialStudents: Student[] = [
  {
    id: 'STU-2026-001',
    fullName: 'أسامة محمد علي الحميري',
    gender: 'ذكر',
    birthDate: '2012-05-14',
    birthPlace: 'صنعاء',
    stage: 'middle',
    grade: 'تاسع أساسي',
    section: 'أ',
    parentName: 'محمد علي الحميري',
    parentRelation: 'الأب',
    parentPhone: '771234567',
    parentJob: 'مهندس اتصالات',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - فج عطان - شارع 14',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=200&h=200&q=80',
    status: 'منتظم',
    registrationDate: '2026-08-15',
    discounts: [{ type: 'خصم تفوق دراسي', percentage: 15, amount: 67500, notes: 'الأول على الصف الثامن العام الماضي' }],
    documents: [
      { name: 'شهادة الميلاد الأصل', type: 'PDF', date: '2026-08-15' },
      { name: 'شهادة ثامن أساسي معمدة', type: 'صورة', date: '2026-08-15' }
    ]
  },
  {
    id: 'STU-2026-002',
    fullName: 'سارة خالد أحمد الشرجبي',
    gender: 'أنثى',
    birthDate: '2014-09-22',
    birthPlace: 'تعز',
    stage: 'primary',
    grade: 'سادس ابتدائي',
    section: 'أ',
    parentName: 'خالد أحمد الشرجبي',
    parentRelation: 'الأب',
    parentPhone: '772345678',
    parentJob: 'طبيب استشاري',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - الأصبحي - شارع المقالح',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&h=200&q=80',
    status: 'منتظم',
    registrationDate: '2026-08-18',
    discounts: [{ type: 'خصم إخوة', percentage: 10, amount: 35000 }],
    documents: [{ name: 'كرت التطعيم وشهادة خامس', type: 'PDF', date: '2026-08-18' }]
  },
  {
    id: 'STU-2026-003',
    fullName: 'يوسف عادل عبدالملك المتوكل',
    gender: 'ذكر',
    birthDate: '2009-03-10',
    birthPlace: 'صنعاء',
    stage: 'secondary',
    grade: 'ثالث ثانوي علمي',
    section: 'أ',
    parentName: 'عادل عبدالملك المتوكل',
    parentRelation: 'الأب',
    parentPhone: '773456789',
    parentJob: 'أستاذ جامعي',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - حدة - الحي السياسي',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&h=200&q=80',
    status: 'منتظم',
    registrationDate: '2026-08-10',
    discounts: [],
    documents: [{ name: 'شهادة تاسع وزارية كرتونية', type: 'PDF', date: '2026-08-10' }]
  },
  {
    id: 'STU-2026-004',
    fullName: 'فاطمة رضوان طه القدسي',
    gender: 'أنثى',
    birthDate: '2016-11-05',
    birthPlace: 'عدن',
    stage: 'primary',
    grade: 'رابع ابتدائي',
    section: 'ب',
    parentName: 'رضوان طه القدسي',
    parentRelation: 'الأب',
    parentPhone: '774567890',
    parentJob: 'تاجر مواد غذائية',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - بيت بوس - شارع الخمسين',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&h=200&q=80',
    status: 'منتظم',
    registrationDate: '2026-08-20',
    discounts: [],
    documents: [{ name: 'شهادة ميلاد + 4 صور شمسية', type: 'وثيقة', date: '2026-08-20' }]
  },
  {
    id: 'STU-2026-005',
    fullName: 'عبدالرحمن طارق يحيى السقاف',
    gender: 'ذكر',
    birthDate: '2010-07-19',
    birthPlace: 'إب',
    stage: 'secondary',
    grade: 'أول ثانوي',
    section: 'ب',
    parentName: 'طارق يحيى السقاف',
    parentRelation: 'الأب',
    parentPhone: '775678901',
    parentJob: 'محاسب قانوني',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - شارع بغداد',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&h=200&q=80',
    status: 'منتظم',
    registrationDate: '2026-08-22',
    discounts: [{ type: 'منحة أبناء معلمين', percentage: 20, amount: 100000 }],
    documents: [{ name: 'ملف نقل من مدرسة الرشيد', type: 'PDF', date: '2026-08-22' }]
  },
  {
    id: 'STU-2026-006',
    fullName: 'مريم نبيل حسان العريقي',
    gender: 'أنثى',
    birthDate: '2013-01-30',
    birthPlace: 'تعز',
    stage: 'middle',
    grade: 'سابع أساسي',
    section: 'أ',
    parentName: 'نبيل حسان العريقي',
    parentRelation: 'الأب',
    parentPhone: '776789012',
    parentJob: 'صيدلاني',
    parentSocialStatus: 'متزوج',
    address: 'صنعاء - الستين الغربي',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&h=200&q=80',
    status: 'منتظم',
    registrationDate: '2026-08-25',
    discounts: [],
    documents: [{ name: 'استمارة التحاق معتمدة', type: 'PDF', date: '2026-08-25' }]
  }
];

export const initialFeeItems: FeeItem[] = [
  { id: 'FEE-01', title: 'رسوم تسجيل طالب جديد', category: 'تسجيل', grade: 'الكل', amount: 30000 },
  { id: 'FEE-02', title: 'الرسوم الدراسية السنوية (المرحلة الأساسية 1-6)', category: 'دراسة', grade: 'أساسي أدنى', amount: 350000 },
  { id: 'FEE-03', title: 'الرسوم الدراسية السنوية (المرحلة الأساسية 7-9)', category: 'دراسة', grade: 'أساسي أعلى', amount: 450000 },
  { id: 'FEE-04', title: 'الرسوم الدراسية السنوية (المرحلة الثانوية)', category: 'دراسة', grade: 'ثانوي', amount: 550000 },
  { id: 'FEE-05', title: 'رسوم الكتب المدرسية والأنشطة', category: 'كتب', grade: 'الكل', amount: 45000 },
  { id: 'FEE-06', title: 'رسوم باص المدرسة (خط كامل ذهاب وإياب)', category: 'مواصلات', grade: 'الكل', amount: 120000 },
  { id: 'FEE-07', title: 'رسوم استمارة ورقم جلوس الشهادة العامة', category: 'امتحانات', grade: 'تاسع وثالث ثانوي', amount: 25000 }
];

export const initialFeePlans: StudentFeePlan[] = [
  {
    studentId: 'STU-2026-001',
    academicYear: '2026 / 2027 م',
    totalOriginal: 495000,
    totalDiscount: 67500,
    netRequired: 427500,
    totalPaid: 300000,
    remaining: 127500,
    installments: [
      { id: 'INS-01', title: 'القسط الأول (عند التسجيل)', dueDate: '2026-09-01', amount: 150000, paidAmount: 150000, status: 'مسدد' },
      { id: 'INS-02', title: 'القسط الثاني (نوفمبر)', dueDate: '2026-11-01', amount: 150000, paidAmount: 150000, status: 'مسدد' },
      { id: 'INS-03', title: 'القسط الثالث (يناير - بداية الفصل الثاني)', dueDate: '2027-01-15', amount: 127500, paidAmount: 0, status: 'قادم' }
    ]
  },
  {
    studentId: 'STU-2026-002',
    academicYear: '2026 / 2027 م',
    totalOriginal: 395000,
    totalDiscount: 35000,
    netRequired: 360000,
    totalPaid: 360000,
    remaining: 0,
    installments: [
      { id: 'INS-04', title: 'القسط الأول (عند التسجيل)', dueDate: '2026-09-01', amount: 180000, paidAmount: 180000, status: 'مسدد' },
      { id: 'INS-05', title: 'القسط الثاني (نوفمبر)', dueDate: '2026-11-01', amount: 180000, paidAmount: 180000, status: 'مسدد' }
    ]
  },
  {
    studentId: 'STU-2026-003',
    academicYear: '2026 / 2027 م',
    totalOriginal: 620000,
    totalDiscount: 0,
    netRequired: 620000,
    totalPaid: 250000,
    remaining: 370000,
    installments: [
      { id: 'INS-06', title: 'القسط الأول (عند التسجيل)', dueDate: '2026-09-01', amount: 250000, paidAmount: 250000, status: 'مسدد' },
      { id: 'INS-07', title: 'القسط الثاني (نوفمبر)', dueDate: '2026-11-01', amount: 200000, paidAmount: 0, status: 'متأخر' },
      { id: 'INS-08', title: 'القسط الثالث (فبراير)', dueDate: '2027-02-01', amount: 170000, paidAmount: 0, status: 'قادم' }
    ]
  },
  {
    studentId: 'STU-2026-004',
    academicYear: '2026 / 2027 م',
    totalOriginal: 395000,
    totalDiscount: 0,
    netRequired: 395000,
    totalPaid: 200000,
    remaining: 195000,
    installments: [
      { id: 'INS-09', title: 'القسط الأول', dueDate: '2026-09-01', amount: 200000, paidAmount: 200000, status: 'مسدد' },
      { id: 'INS-10', title: 'القسط الثاني', dueDate: '2026-12-01', amount: 195000, paidAmount: 0, status: 'متأخر' }
    ]
  },
  {
    studentId: 'STU-2026-005',
    academicYear: '2026 / 2027 م',
    totalOriginal: 550000,
    totalDiscount: 100000,
    netRequired: 450000,
    totalPaid: 300000,
    remaining: 150000,
    installments: [
      { id: 'INS-11', title: 'القسط الأول', dueDate: '2026-09-01', amount: 250000, paidAmount: 250000, status: 'مسدد' },
      { id: 'INS-12', title: 'القسط الثاني', dueDate: '2026-11-15', amount: 100000, paidAmount: 50000, status: 'جزئي' },
      { id: 'INS-13', title: 'القسط الثالث', dueDate: '2027-02-15', amount: 100000, paidAmount: 0, status: 'قادم' }
    ]
  },
  {
    studentId: 'STU-2026-006',
    academicYear: '2026 / 2027 م',
    totalOriginal: 495000,
    totalDiscount: 0,
    netRequired: 495000,
    totalPaid: 200000,
    remaining: 295000,
    installments: [
      { id: 'INS-14', title: 'القسط الأول', dueDate: '2026-09-01', amount: 200000, paidAmount: 200000, status: 'مسدد' },
      { id: 'INS-15', title: 'القسط الثاني', dueDate: '2026-11-20', amount: 150000, paidAmount: 0, status: 'متأخر' },
      { id: 'INS-16', title: 'القسط الثالث', dueDate: '2027-02-15', amount: 145000, paidAmount: 0, status: 'قادم' }
    ]
  }
];

export const initialVouchers: Voucher[] = [
  {
    id: 'REC-2026-001',
    type: 'receipt',
    voucherNumber: 1001,
    date: '2026-09-01',
    amount: 150000,
    amountInWords: 'فقط مائة وخمسون ألف ريال يمني لا غير',
    recipientOrPayer: 'محمد علي الحميري (عن الطالب: أسامة الحميري)',
    studentId: 'STU-2026-001',
    category: 'رسوم دراسية - قسط أول',
    paymentMethod: 'نقداً - الصندوق',
    accountFrom: 'صندوق الخزينة الرئيسي',
    accountTo: 'إيرادات الرسوم الدراسية',
    notes: 'تسديد القسط الأول للعام الدراسي 2026/2027',
    preparedBy: 'عصام البعداني (المحاسب)'
  },
  {
    id: 'REC-2026-002',
    type: 'receipt',
    voucherNumber: 1002,
    date: '2026-09-02',
    amount: 180000,
    amountInWords: 'فقط مائة وثمانون ألف ريال يمني لا غير',
    recipientOrPayer: 'خالد أحمد الشرجبي (عن الطالبة: سارة الشرجبي)',
    studentId: 'STU-2026-002',
    category: 'رسوم دراسية - قسط أول',
    paymentMethod: 'بنك الكريمي',
    accountFrom: 'حساب بنك الكريمي',
    accountTo: 'إيرادات الرسوم الدراسية',
    notes: 'إيداع بنكي مباشر - إشعار رقم 88721',
    preparedBy: 'عصام البعداني (المحاسب)'
  },
  {
    id: 'REC-2026-003',
    type: 'receipt',
    voucherNumber: 1003,
    date: '2026-09-05',
    amount: 250000,
    amountInWords: 'فقط مائتان وخمسون ألف ريال يمني لا غير',
    recipientOrPayer: 'عادل عبدالملك المتوكل (عن الطالب: يوسف المتوكل)',
    studentId: 'STU-2026-003',
    category: 'رسوم دراسية - قسط أول',
    paymentMethod: 'نقداً - الصندوق',
    accountFrom: 'صندوق الخزينة الرئيسي',
    accountTo: 'إيرادات الرسوم الدراسية',
    notes: 'تسجيل وقسط أول ثالث ثانوي علمي',
    preparedBy: 'عصام البعداني (المحاسب)'
  },
  {
    id: 'REC-2026-004',
    type: 'receipt',
    voucherNumber: 1004,
    date: '2026-11-01',
    amount: 150000,
    amountInWords: 'فقط مائة وخمسون ألف ريال يمني لا غير',
    recipientOrPayer: 'محمد علي الحميري (عن الطالب: أسامة الحميري)',
    studentId: 'STU-2026-001',
    category: 'رسوم دراسية - قسط ثان',
    paymentMethod: 'نقداً - الصندوق',
    accountFrom: 'صندوق الخزينة الرئيسي',
    accountTo: 'إيرادات الرسوم الدراسية',
    notes: 'القسط الثاني بموجب السند الرسمي',
    preparedBy: 'عصام البعداني (المحاسب)'
  },
  {
    id: 'PAY-2026-001',
    type: 'payment',
    voucherNumber: 2001,
    date: '2026-09-30',
    amount: 320000,
    amountInWords: 'فقط ثلاثمائة وعشرون ألف ريال يمني لا غير',
    recipientOrPayer: 'شركة النفط اليمنية - محطة حدة',
    category: 'مصروفات تشغيل ومحروقات',
    paymentMethod: 'نقداً - الصندوق',
    accountFrom: 'صندوق الخزينة الرئيسي',
    accountTo: 'مصروفات وقود المولدات والباصات',
    notes: 'شراء ديزل لمولد الكهرباء الاحتياطي للمدرسة وباصات النقل',
    preparedBy: 'عصام البعداني (المحاسب)'
  },
  {
    id: 'PAY-2026-002',
    type: 'payment',
    voucherNumber: 2002,
    date: '2026-10-02',
    amount: 185000,
    amountInWords: 'فقط مائة وخمسة وثمانون ألف ريال يمني لا غير',
    recipientOrPayer: 'مكتبة الجيل الجديد - التحرير',
    category: 'أدوات وقرطاسية ومطبوعات',
    paymentMethod: 'نقداً - الصندوق',
    accountFrom: 'صندوق الخزينة الرئيسي',
    accountTo: 'مصروفات قرطاسية ومطبوعات',
    notes: 'طباعة دفاتر المتابعة اليومية وكشوفات الدرجات وسجلات الغياب',
    preparedBy: 'عصام البعداني (المحاسب)'
  },
  {
    id: 'PAY-2026-003',
    type: 'payment',
    voucherNumber: 2003,
    date: '2026-10-31',
    amount: 850000,
    amountInWords: 'فقط ثمانمائة وخمسون ألف ريال يمني لا غير',
    recipientOrPayer: 'كادر المعلمين والموظفين (مسير رواتب أكتوبر الجزئي)',
    category: 'رواتب وأجور الكادر',
    paymentMethod: 'حوالة مصرفية',
    accountFrom: 'حساب بنك الكريمي',
    accountTo: 'مصروفات الرواتب والأجور',
    notes: 'صرف رواتب شهر أكتوبر عبر شبكة الكريمي إكسبرس للموظفين',
    preparedBy: 'عصام البعداني (المحاسب)'
  }
];

export const initialAccounts: AccountLedgerItem[] = [
  { code: '101', name: 'صندوق الخزينة الرئيسي (الكاش)', type: 'أصول', balance: 1425000 },
  { code: '102', name: 'حساب بنك الكريمي للتمويل الأصغر', type: 'أصول', balance: 3840000 },
  { code: '103', name: 'حساب بنك التضامن الإسلامي الدولي', type: 'أصول', balance: 2150000 },
  { code: '104', name: 'أرصدة الرسوم المستحقة على الطلاب (مدينون)', type: 'أصول', balance: 1137500 },
  { code: '105', name: 'الأصول الثابتة (أثاث، معامل، باصات، أجهزة)', type: 'أصول', balance: 18500000 },
  { code: '201', name: 'أمانات ورسوم مقدمة من أولياء الأمور', type: 'خصوم', balance: 350000 },
  { code: '202', name: 'مستحقات الموردين ومكتبات الطباعة', type: 'خصوم', balance: 185000 },
  { code: '301', name: 'رأس مال المدرسة وصافي حقوق الملكية', type: 'حقوق ملكية', balance: 22000000 },
  { code: '401', name: 'إيرادات الرسوم الدراسية وأقساط الطلاب', type: 'إيرادات', balance: 8450000 },
  { code: '402', name: 'إيرادات باصات النقل والمواصلات', type: 'إيرادات', balance: 1250000 },
  { code: '403', name: 'إيرادات الأنشطة والزي والكتب المدرسية', type: 'إيرادات', balance: 680000 },
  { code: '501', name: 'مصروفات رواتب المعلمين والإداريين', type: 'مصروفات', balance: 4250000 },
  { code: '502', name: 'مصروفات الديزل والكهرباء والمياه', type: 'مصروفات', balance: 740000 },
  { code: '503', name: 'مصروفات الإيجار السنوي للمبنى المدرسي', type: 'مصروفات', balance: 2400000 },
  { code: '504', name: 'مصروفات الصيانة والترميمات والنظافة', type: 'مصروفات', balance: 290000 },
  { code: '505', name: 'مصروفات القرطاسية ومطبوعات الاختبارات', type: 'مصروفات', balance: 320000 }
];

export const initialEmployees: Employee[] = [
  {
    id: 'EMP-001',
    fullName: 'أ.د. عبدالجليل سعيد الأهدل',
    role: 'المدير العام للمدارس',
    phone: '777112233',
    qualification: 'دكتوراه في الإدارة التربوية',
    specialization: 'إدارة وتخطيط تعليمي',
    hireDate: '2018-09-01',
    baseSalary: 380000,
    allowances: 70000,
    deductions: 0,
    netSalary: 450000,
    status: 'على رأس العمل'
  },
  {
    id: 'EMP-002',
    fullName: 'عصام محمد البعداني',
    role: 'المحاسب المالي العام',
    phone: '777223344',
    qualification: 'بكالوريوس محاسبة - جامعة صنعاء',
    specialization: 'محاسبة مالية وضريبية',
    hireDate: '2020-10-15',
    baseSalary: 260000,
    allowances: 40000,
    deductions: 0,
    netSalary: 300000,
    status: 'على رأس العمل'
  },
  {
    id: 'EMP-003',
    fullName: 'أ. فؤاد إسماعيل الزبيري',
    role: 'معلم ومسؤول كنترول',
    phone: '777334455',
    qualification: 'بكالوريوس رياضيات وفيزياء',
    specialization: 'رياضيات المنهج اليمني',
    hireDate: '2019-08-20',
    baseSalary: 220000,
    allowances: 35000,
    deductions: 10000,
    netSalary: 245000,
    status: 'على رأس العمل',
    subjects: ['الرياضيات'],
    assignedGrades: ['تاسع أساسي', 'ثالث ثانوي علمي']
  },
  {
    id: 'EMP-004',
    fullName: 'أ. منى عبده قاسم الصلوي',
    role: 'معلمة لغة إنجليزية',
    phone: '777445566',
    qualification: 'ماجستير لغويات تطبيقية',
    specialization: 'اللغة الإنجليزية',
    hireDate: '2021-09-01',
    baseSalary: 200000,
    allowances: 30000,
    deductions: 0,
    netSalary: 230000,
    status: 'على رأس العمل',
    subjects: ['اللغة الإنجليزية'],
    assignedGrades: ['سابع أساسي', 'ثامن أساسي', 'أول ثانوي']
  },
  {
    id: 'EMP-005',
    fullName: 'أ. طه ناصر الجبلي',
    role: 'معلم قرآن وإسلامية',
    phone: '777556677',
    qualification: 'إجازة بالقراءات وبكالوريوس شريعة',
    specialization: 'القرآن الكريم والتربية الإسلامية',
    hireDate: '2019-09-01',
    baseSalary: 210000,
    allowances: 25000,
    deductions: 0,
    netSalary: 235000,
    status: 'على رأس العمل',
    subjects: ['القرآن الكريم وعلومه', 'التربية الإسلامية'],
    assignedGrades: ['سادس ابتدائي', 'تاسع أساسي']
  },
  {
    id: 'EMP-006',
    fullName: 'أ. سحر علي الأكوع',
    role: 'مسؤولة شؤون الطلاب والتسجيل',
    phone: '777667788',
    qualification: 'بكالوريوس نظم معلومات إدارية',
    specialization: 'أرشفة إلكترونية وشؤون طلاب',
    hireDate: '2022-01-10',
    baseSalary: 180000,
    allowances: 30000,
    deductions: 0,
    netSalary: 210000,
    status: 'على رأس العمل'
  }
];

export const initialScheduleSlots: TeacherScheduleSlot[] = [
  { id: 'SCH-01', teacherId: 'EMP-003', day: 'السبت', period: 1, grade: 'تاسع أساسي', section: 'أ', subject: 'الرياضيات' },
  { id: 'SCH-02', teacherId: 'EMP-003', day: 'السبت', period: 2, grade: 'ثالث ثانوي علمي', section: 'أ', subject: 'الرياضيات' },
  { id: 'SCH-03', teacherId: 'EMP-004', day: 'السبت', period: 3, grade: 'سابع أساسي', section: 'أ', subject: 'اللغة الإنجليزية' },
  { id: 'SCH-04', teacherId: 'EMP-005', day: 'السبت', period: 4, grade: 'تاسع أساسي', section: 'أ', subject: 'القرآن الكريم وعلومه' },
  { id: 'SCH-05', teacherId: 'EMP-003', day: 'الأحد', period: 1, grade: 'ثالث ثانوي علمي', section: 'أ', subject: 'الرياضيات' },
  { id: 'SCH-06', teacherId: 'EMP-004', day: 'الأحد', period: 2, grade: 'أول ثانوي', section: 'ب', subject: 'اللغة الإنجليزية' },
  { id: 'SCH-07', teacherId: 'EMP-005', day: 'الإثنين', period: 1, grade: 'سادس ابتدائي', section: 'أ', subject: 'التربية الإسلامية' },
  { id: 'SCH-08', teacherId: 'EMP-003', day: 'الثلاثاء', period: 3, grade: 'تاسع أساسي', section: 'أ', subject: 'الرياضيات' }
];

export const initialGrades: GradeRecord[] = [
  {
    id: 'GRD-01',
    studentId: 'STU-2026-001',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'القرآن الكريم وعلومه',
    monthlyScore1: 20,
    monthlyScore2: 19,
    activitiesScore: 10,
    finalExamScore: 48,
    totalScore: 97,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  },
  {
    id: 'GRD-02',
    studentId: 'STU-2026-001',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'الرياضيات',
    monthlyScore1: 19,
    monthlyScore2: 19,
    activitiesScore: 10,
    finalExamScore: 47,
    totalScore: 95,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  },
  {
    id: 'GRD-03',
    studentId: 'STU-2026-001',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'العلوم العامة',
    monthlyScore1: 18,
    monthlyScore2: 19,
    activitiesScore: 9,
    finalExamScore: 46,
    totalScore: 92,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  },
  {
    id: 'GRD-04',
    studentId: 'STU-2026-001',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'اللغة الإنجليزية',
    monthlyScore1: 18,
    monthlyScore2: 18,
    activitiesScore: 10,
    finalExamScore: 44,
    totalScore: 90,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  },
  {
    id: 'GRD-05',
    studentId: 'STU-2026-002',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'الرياضيات',
    monthlyScore1: 20,
    monthlyScore2: 20,
    activitiesScore: 10,
    finalExamScore: 49,
    totalScore: 99,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  },
  {
    id: 'GRD-06',
    studentId: 'STU-2026-002',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'اللغة العربية (نحو وقراءة وإملاء)',
    monthlyScore1: 19,
    monthlyScore2: 19,
    activitiesScore: 10,
    finalExamScore: 48,
    totalScore: 96,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  },
  {
    id: 'GRD-07',
    studentId: 'STU-2026-003',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'الرياضيات',
    monthlyScore1: 17,
    monthlyScore2: 18,
    activitiesScore: 9,
    finalExamScore: 43,
    totalScore: 87,
    gradeLetter: 'جيد جداً',
    status: 'ناجح'
  },
  {
    id: 'GRD-08',
    studentId: 'STU-2026-003',
    academicYear: '2026 / 2027 م',
    term: 'الفصل الأول',
    subject: 'الفيزياء',
    monthlyScore1: 18,
    monthlyScore2: 19,
    activitiesScore: 9,
    finalExamScore: 45,
    totalScore: 91,
    gradeLetter: 'ممتاز',
    status: 'ناجح'
  }
];

export const initialAttendance: AttendanceRecord[] = [
  { id: 'ATT-01', date: new Date().toISOString().split('T')[0], type: 'student', targetId: 'STU-2026-001', grade: 'تاسع أساسي', section: 'أ', status: 'حاضر' },
  { id: 'ATT-02', date: new Date().toISOString().split('T')[0], type: 'student', targetId: 'STU-2026-002', grade: 'سادس ابتدائي', section: 'أ', status: 'حاضر' },
  { id: 'ATT-03', date: new Date().toISOString().split('T')[0], type: 'student', targetId: 'STU-2026-003', grade: 'ثالث ثانوي علمي', section: 'أ', status: 'غائب', notes: 'وعكة صحية' },
  { id: 'ATT-04', date: new Date().toISOString().split('T')[0], type: 'student', targetId: 'STU-2026-004', grade: 'رابع ابتدائي', section: 'ب', status: 'حاضر' },
  { id: 'ATT-05', date: new Date().toISOString().split('T')[0], type: 'student', targetId: 'STU-2026-005', grade: 'أول ثانوي', section: 'ب', status: 'متأخر', notes: 'تأخر 15 دقيقة باص' },
  { id: 'ATT-06', date: new Date().toISOString().split('T')[0], type: 'student', targetId: 'STU-2026-006', grade: 'سابع أساسي', section: 'أ', status: 'حاضر' },
  { id: 'ATT-101', date: new Date().toISOString().split('T')[0], type: 'employee', targetId: 'EMP-001', status: 'حاضر' },
  { id: 'ATT-102', date: new Date().toISOString().split('T')[0], type: 'employee', targetId: 'EMP-002', status: 'حاضر' },
  { id: 'ATT-103', date: new Date().toISOString().split('T')[0], type: 'employee', targetId: 'EMP-003', status: 'حاضر' },
  { id: 'ATT-104', date: new Date().toISOString().split('T')[0], type: 'employee', targetId: 'EMP-004', status: 'حاضر' },
  { id: 'ATT-105', date: new Date().toISOString().split('T')[0], type: 'employee', targetId: 'EMP-005', status: 'حاضر' },
  { id: 'ATT-106', date: new Date().toISOString().split('T')[0], type: 'employee', targetId: 'EMP-006', status: 'حاضر' }
];

export const initialLibraryBooks: LibraryBook[] = [
  {
    id: 'BK-001',
    title: 'رياض الصالحين من كلام سيد المرسلين',
    author: 'الإمام النووي',
    category: 'علوم إسلامية',
    copiesTotal: 10,
    copiesAvailable: 8,
    loans: [
      { id: 'LN-01', borrowerName: 'أسامة محمد الحميري', borrowerType: 'طالب', borrowDate: '2026-09-10', dueDate: '2026-09-24', status: 'معار' }
    ]
  },
  {
    id: 'BK-002',
    title: 'موسوعة تاريخ اليمن القديم والحديث',
    author: 'مجموعة من المؤرخين اليمنيين',
    category: 'تاريخ وجغرافيا',
    copiesTotal: 5,
    copiesAvailable: 4,
    loans: [
      { id: 'LN-02', borrowerName: 'أ. فؤاد الزبيري', borrowerType: 'معلم', borrowDate: '2026-09-15', dueDate: '2026-10-01', status: 'معار' }
    ]
  },
  {
    id: 'BK-003',
    title: 'أساسيات الفيزياء الحديثة وتجارب المعامل',
    author: 'د. يحيى الشعيبي',
    category: 'علوم وفيزياء',
    copiesTotal: 12,
    copiesAvailable: 11,
    loans: []
  },
  {
    id: 'BK-004',
    title: 'قاموس أكسفورد المصور (عربي - إنجليزي)',
    author: 'جامعة أكسفورد',
    category: 'لغات ومعاجم',
    copiesTotal: 15,
    copiesAvailable: 15,
    loans: []
  }
];

export const initialInventory: InventoryItem[] = [
  { id: 'INV-01', name: 'كتب منهج الصف الأول الابتدائي (مجموعة كاملة)', category: 'كتب مدرسية', quantity: 85, unit: 'حزمة', minThreshold: 20, unitPrice: 12000, lastUpdated: '2026-08-25' },
  { id: 'INV-02', name: 'كتب منهج الصف التاسع الأساسي', category: 'كتب مدرسية', quantity: 60, unit: 'حزمة', minThreshold: 15, unitPrice: 18000, lastUpdated: '2026-08-25' },
  { id: 'INV-03', name: 'دفاتر متابعة الطالب المدرسية الرسمية', category: 'قرطاسية', quantity: 450, unit: 'دفتر', minThreshold: 100, unitPrice: 800, lastUpdated: '2026-09-02' },
  { id: 'INV-04', name: 'أقلام سبورة وايت بورد (أزرق وأسود وأحمر)', category: 'قرطاسية', quantity: 240, unit: 'حبة', minThreshold: 50, unitPrice: 350, lastUpdated: '2026-09-05' },
  { id: 'INV-05', name: 'مقاعد دراسية مزدوجة خشب وحديد', category: 'أثاث مدرسي', quantity: 120, unit: 'مقعد', minThreshold: 10, unitPrice: 45000, lastUpdated: '2026-08-10' },
  { id: 'INV-06', name: 'مجموعات تشريح وأنابيب اختبار لمعمل العلوم', category: 'مستلزمات معامل', quantity: 25, unit: 'طقم', minThreshold: 5, unitPrice: 35000, lastUpdated: '2026-08-15' }
];

export const initialNotifications: SchoolNotification[] = [
  {
    id: 'NOT-01',
    title: 'تذكير باستحقاق القسط الدراسي الثاني',
    content: 'السادة أولياء الأمور الكرام، نود تذكيركم بموعد سداد القسط الثاني للرسوم الدراسية للعام 2026/2027 ليتسنى لنا استكمال تسليم الكتب وبطائق الاختبارات.',
    date: '2026-10-01',
    targetAudience: 'أولياء الأمور',
    type: 'مالي',
    channel: 'واتساب',
    status: 'مرسل'
  },
  {
    id: 'NOT-02',
    title: 'إشعار غياب طالب عن الدوام المدرسي',
    content: 'المكرم ولي أمر الطالب يوسف عادل المتوكل، نود إحاطتكم بغياب الطالب عن مقاعد الدراسة اليوم بدون إذن مسبق، يرجى التكرم بتزويد إدارة المدرسة بسبب الغياب.',
    date: new Date().toISOString().split('T')[0],
    targetAudience: 'أولياء الأمور',
    type: 'غياب',
    channel: 'رسائل نصية',
    status: 'مرسل'
  },
  {
    id: 'NOT-03',
    title: 'بدء اختبارات الشهر الأول للفصل الدراسي الأول',
    content: 'أبناءنا وبناتنا الطلاب وأولياء أمورهم الكرام، تبدأ يوم السبت القادم بمشيئة الله تعالى اختبارات الشهر الأول لجميع المراحل الدراسية وفق الجداول المعلنة.',
    date: '2026-09-20',
    targetAudience: 'الكل',
    type: 'درجات',
    channel: 'إشعار داخلي',
    status: 'مرسل'
  }
];

export const initialArchive: ArchiveDocument[] = [
  {
    id: 'DOC-01',
    title: 'ملف الطالب أسامة محمد علي الحميري - الأرشيف الأساسي',
    category: 'ملفات طلاب',
    date: '2026-08-15',
    fileSize: '3.4 MB',
    referenceId: 'STU-2026-001',
    fileName: 'student_file_STU_001.pdf',
    notes: 'يحتوي على شهادة الميلاد، صور شخصية، شهادات الصفوف السابقة معتمدة من وزارة التربية'
  },
  {
    id: 'DOC-02',
    title: 'عقد عمل وتعيين المعلم أ. فؤاد إسماعيل الزبيري',
    category: 'عقود واتفاقيات',
    date: '2026-08-01',
    fileSize: '1.8 MB',
    referenceId: 'EMP-003',
    fileName: 'contract_emp_003.pdf',
    notes: 'عقد سنوي مصدق متضمن الراتب الأساسي والنصاب الأسبوعي والبدلات'
  },
  {
    id: 'DOC-03',
    title: 'التعميم الوزاري بخصوص التقويم المدرسي والاختبارات 2026/2027',
    category: 'تعاميم وزارية',
    date: '2026-07-20',
    fileSize: '4.2 MB',
    fileName: 'ministry_calendar_2026.pdf',
    notes: 'صادر عن وزارة التربية والتعليم - قطاع المناهج والتوجيه'
  },
  {
    id: 'DOC-04',
    title: 'محضر جرد وتدقيق الصندوق وحسابات البنوك للربع الأول',
    category: 'سجلات مالية',
    date: '2026-09-30',
    fileSize: '2.1 MB',
    fileName: 'audit_q1_2026.pdf',
    notes: 'معتمد من المحاسب القانوني والمدير العام'
  }
];
