import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { 
  SchoolInfo, 
  Student, 
  FeeItem, 
  StudentFeePlan, 
  Voucher, 
  AccountLedgerItem, 
  Employee, 
  TeacherScheduleSlot, 
  GradeRecord, 
  AttendanceRecord, 
  LibraryBook, 
  InventoryItem, 
  SchoolNotification, 
  ArchiveDocument,
  SchoolRole,
  UserAccount
} from '../types';
import { 
  initialSchoolInfo, 
  initialStudents, 
  initialFeeItems, 
  initialFeePlans, 
  initialVouchers, 
  initialAccounts, 
  initialEmployees, 
  initialScheduleSlots, 
  initialGrades, 
  initialAttendance, 
  initialLibraryBooks, 
  initialInventory, 
  initialNotifications, 
  initialArchive 
} from '../data/initialData';
import { tafqeet } from '../utils/numberToWordsArabic';

export const DEFAULT_USERS: UserAccount[] = [
  {
    id: 'USR-01',
    name: 'م. عبدالرحمن الماوري',
    username: 'admin',
    role: 'admin',
    roleLabel: 'مدير النظام (كامل الصلاحيات)',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80'
  },
  {
    id: 'USR-02',
    name: 'أ.د. عبدالجليل سعيد الأهدل',
    username: 'principal',
    role: 'principal',
    roleLabel: 'المدير العام للمدارس',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150&q=80'
  },
  {
    id: 'USR-03',
    name: 'عصام محمد البعداني',
    username: 'accountant',
    role: 'accountant',
    roleLabel: 'المحاسب المالي العام',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80'
  },
  {
    id: 'USR-04',
    name: 'أ. سحر علي الأكوع',
    username: 'students',
    role: 'student_affairs',
    roleLabel: 'مسؤولة شؤون الطلاب والتسجيل',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80'
  },
  {
    id: 'USR-05',
    name: 'أ. فؤاد إسماعيل الزبيري',
    username: 'control',
    role: 'control',
    roleLabel: 'رئيس لجنة الكنترول والاختبارات',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80'
  },
  {
    id: 'USR-06',
    name: 'أ. منى عبده قاسم الصلوي',
    username: 'teacher',
    role: 'teacher',
    roleLabel: 'المعلم (رصد الدرجات والتحضير)',
    avatar: 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?auto=format&fit=crop&w=150&h=150&q=80'
  }
];

interface PrintPayload {
  isOpen: boolean;
  type: 'voucher' | 'card' | 'report_card' | 'admission_form' | 'student_list' | 'financial_statement';
  payload: any;
}

interface ToastInfo {
  show: boolean;
  text: string;
  type: 'success' | 'info' | 'error';
}

interface SchoolContextType {
  // Auth state
  currentUser: UserAccount | null;
  isAuthenticated: boolean;
  login: (username: string, password?: string, specificRole?: SchoolRole) => boolean;
  logout: () => void;

  // School info
  schoolInfo: SchoolInfo;
  updateSchoolInfo: (info: Partial<SchoolInfo>) => void;

  // Roles & View
  currentRole: SchoolRole;
  setCurrentRole: (role: SchoolRole) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // Students
  students: Student[];
  addStudent: (studentData: Omit<Student, 'id' | 'registrationDate'>) => Student;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  transferStudent: (id: string, newGrade: string, newSection: string) => void;
  setStudentStatus: (id: string, status: Student['status']) => void;

  // Fees & Installments
  feeItems: FeeItem[];
  feePlans: StudentFeePlan[];
  updateStudentFeePlan: (studentId: string, updates: Partial<StudentFeePlan>) => void;
  getStudentFeePlan: (studentId: string) => StudentFeePlan | undefined;

  // Vouchers & Accounting
  vouchers: Voucher[];
  createVoucher: (data: Omit<Voucher, 'id' | 'voucherNumber' | 'amountInWords'>) => Voucher;
  deleteVoucher: (id: string) => void;
  accounts: AccountLedgerItem[];
  updateAccountBalance: (code: string, newBalance: number) => void;

  // Staff & Employees
  employees: Employee[];
  addEmployee: (emp: Omit<Employee, 'id'>) => Employee;
  updateEmployee: (id: string, updates: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;
  disburseSalary: (empId: string, monthName: string) => void;

  // Timetable
  scheduleSlots: TeacherScheduleSlot[];
  addScheduleSlot: (slot: Omit<TeacherScheduleSlot, 'id'>) => void;
  deleteScheduleSlot: (id: string) => void;

  // Grades & Control
  grades: GradeRecord[];
  saveGrade: (gradeData: Omit<GradeRecord, 'id' | 'totalScore' | 'gradeLetter' | 'status'>) => void;
  getStudentGrades: (studentId: string) => GradeRecord[];

  // Attendance
  attendance: AttendanceRecord[];
  markAttendance: (record: Omit<AttendanceRecord, 'id'>) => void;
  markBatchAttendance: (date: string, type: 'student' | 'employee', items: { targetId: string; status: AttendanceRecord['status']; notes?: string; grade?: string; section?: string }[]) => void;

  // Library
  libraryBooks: LibraryBook[];
  borrowBook: (bookId: string, borrowerName: string, borrowerType: 'طالب' | 'معلم', days: number) => void;
  returnBook: (bookId: string, loanId: string) => void;
  addBook: (book: Omit<LibraryBook, 'id' | 'loans'>) => void;

  // Inventory
  inventory: InventoryItem[];
  addInventoryItem: (item: Omit<InventoryItem, 'id' | 'lastUpdated'>) => void;
  adjustStock: (id: string, change: number, notes?: string) => void;

  // Messages & Notifications
  notifications: SchoolNotification[];
  sendNotification: (notif: Omit<SchoolNotification, 'id' | 'date'>) => void;

  // Archive
  archiveDocs: ArchiveDocument[];
  addArchiveDoc: (doc: Omit<ArchiveDocument, 'id' | 'date'>) => void;
  deleteArchiveDoc: (id: string) => void;

  // Print Modal
  printModal: PrintPayload;
  openPrintModal: (type: PrintPayload['type'], payload: any) => void;
  closePrintModal: () => void;

  // Toast
  toast: ToastInfo;
  showToast: (text: string, type?: ToastInfo['type']) => void;

  // Financial & General Calculations
  financialSummary: {
    totalRevenue: number;
    totalExpenses: number;
    netProfit: number;
    cashBalance: number;
    bankBalance: number;
    totalArrears: number;
  };

  studentSummary: {
    total: number;
    boys: number;
    girls: number;
    regular: number;
    withArrears: number;
  };

  // Backup & Reset
  exportDatabaseToJson: () => string;
  importDatabaseFromJson: (jsonStr: string) => boolean;
  resetDatabase: () => void;
}

const SchoolContext = createContext<SchoolContextType | undefined>(undefined);

const STORAGE_KEY = 'YEMEN_PRIVATE_SCHOOL_SYSTEM_STATE_V1';

export const SchoolProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from localStorage or defaults
  const loadState = <T,>(key: string, defaultValue: T): T => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_${key}`);
      return stored ? JSON.parse(stored) : defaultValue;
    } catch {
      return defaultValue;
    }
  };

  const [schoolInfo, setSchoolInfo] = useState<SchoolInfo>(() => loadState('schoolInfo', initialSchoolInfo));
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => loadState('currentUser', DEFAULT_USERS[0]));
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => loadState('isAuthenticated', true));
  const [currentRole, setCurrentRole] = useState<SchoolRole>(() => {
    const user = loadState<UserAccount | null>('currentUser', DEFAULT_USERS[0]);
    return user ? user.role : 'admin';
  });
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const login = (username: string, password?: string, specificRole?: SchoolRole): boolean => {
    let matchedUser = DEFAULT_USERS.find(u => u.username.toLowerCase() === username.trim().toLowerCase());
    if (!matchedUser && specificRole) {
      matchedUser = DEFAULT_USERS.find(u => u.role === specificRole);
    }
    if (!matchedUser) {
      matchedUser = {
        id: `USR-${Date.now()}`,
        name: username.trim(),
        username: username.trim().toLowerCase(),
        role: specificRole || 'admin',
        roleLabel: specificRole === 'admin' ? 'مدير النظام' : 'مستخدم مصرح'
      };
    }

    setCurrentUser(matchedUser);
    setCurrentRole(matchedUser.role);
    setIsAuthenticated(true);
    try {
      localStorage.setItem(`${STORAGE_KEY}_currentUser`, JSON.stringify(matchedUser));
      localStorage.setItem(`${STORAGE_KEY}_isAuthenticated`, JSON.stringify(true));
    } catch {}
    showToast(`مرحباً بك: ${matchedUser.name} (${matchedUser.roleLabel})`);
    return true;
  };

  const logout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    try {
      localStorage.setItem(`${STORAGE_KEY}_isAuthenticated`, JSON.stringify(false));
      localStorage.removeItem(`${STORAGE_KEY}_currentUser`);
    } catch {}
    showToast('تم تسجيل الخروج بنجاح', 'info');
  };

  const [students, setStudents] = useState<Student[]>(() => loadState('students', initialStudents));
  const [feeItems, setFeeItems] = useState<FeeItem[]>(() => loadState('feeItems', initialFeeItems));
  const [feePlans, setFeePlans] = useState<StudentFeePlan[]>(() => loadState('feePlans', initialFeePlans));
  const [vouchers, setVouchers] = useState<Voucher[]>(() => loadState('vouchers', initialVouchers));
  const [accounts, setAccounts] = useState<AccountLedgerItem[]>(() => loadState('accounts', initialAccounts));
  const [employees, setEmployees] = useState<Employee[]>(() => loadState('employees', initialEmployees));
  const [scheduleSlots, setScheduleSlots] = useState<TeacherScheduleSlot[]>(() => loadState('scheduleSlots', initialScheduleSlots));
  const [grades, setGrades] = useState<GradeRecord[]>(() => loadState('grades', initialGrades));
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() => loadState('attendance', initialAttendance));
  const [libraryBooks, setLibraryBooks] = useState<LibraryBook[]>(() => loadState('libraryBooks', initialLibraryBooks));
  const [inventory, setInventory] = useState<InventoryItem[]>(() => loadState('inventory', initialInventory));
  const [notifications, setNotifications] = useState<SchoolNotification[]>(() => loadState('notifications', initialNotifications));
  const [archiveDocs, setArchiveDocs] = useState<ArchiveDocument[]>(() => loadState('archiveDocs', initialArchive));

  const [printModal, setPrintModal] = useState<PrintPayload>({
    isOpen: false,
    type: 'voucher',
    payload: null
  });

  const [toast, setToast] = useState<ToastInfo>({
    show: false,
    text: '',
    type: 'success'
  });

  const showToast = (text: string, type: ToastInfo['type'] = 'success') => {
    setToast({ show: true, text, type });
    setTimeout(() => {
      setToast(prev => ({ ...prev, show: false }));
    }, 3200);
  };

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_schoolInfo`, JSON.stringify(schoolInfo));
      localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(students));
      localStorage.setItem(`${STORAGE_KEY}_feeItems`, JSON.stringify(feeItems));
      localStorage.setItem(`${STORAGE_KEY}_feePlans`, JSON.stringify(feePlans));
      localStorage.setItem(`${STORAGE_KEY}_vouchers`, JSON.stringify(vouchers));
      localStorage.setItem(`${STORAGE_KEY}_accounts`, JSON.stringify(accounts));
      localStorage.setItem(`${STORAGE_KEY}_employees`, JSON.stringify(employees));
      localStorage.setItem(`${STORAGE_KEY}_scheduleSlots`, JSON.stringify(scheduleSlots));
      localStorage.setItem(`${STORAGE_KEY}_grades`, JSON.stringify(grades));
      localStorage.setItem(`${STORAGE_KEY}_attendance`, JSON.stringify(attendance));
      localStorage.setItem(`${STORAGE_KEY}_libraryBooks`, JSON.stringify(libraryBooks));
      localStorage.setItem(`${STORAGE_KEY}_inventory`, JSON.stringify(inventory));
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(notifications));
      localStorage.setItem(`${STORAGE_KEY}_archiveDocs`, JSON.stringify(archiveDocs));
    } catch {
      // ignore
    }
  }, [schoolInfo, students, feeItems, feePlans, vouchers, accounts, employees, scheduleSlots, grades, attendance, libraryBooks, inventory, notifications, archiveDocs]);

  const updateSchoolInfo = (info: Partial<SchoolInfo>) => {
    setSchoolInfo(prev => ({ ...prev, ...info }));
    showToast('تم تحديث بيانات المدرسة بنجاح');
  };

  // Student actions
  const addStudent = (studentData: Omit<Student, 'id' | 'registrationDate'>) => {
    const nextNum = students.length + 1;
    const padded = String(nextNum).padStart(3, '0');
    const newId = `STU-2026-${padded}`;
    const newStudent: Student = {
      ...studentData,
      id: newId,
      registrationDate: new Date().toISOString().split('T')[0]
    };

    setStudents(prev => [newStudent, ...prev]);

    // Create default fee plan
    const tuitionBase = studentData.stage === 'primary' ? 350000 : (studentData.stage === 'middle' ? 450000 : 550000);
    const regFee = 30000;
    const books = 45000;
    const totalOriginal = tuitionBase + regFee + books;
    const discountSum = (studentData.discounts || []).reduce((acc, d) => acc + d.amount, 0);
    const netRequired = Math.max(0, totalOriginal - discountSum);

    const firstIns = Math.round(netRequired * 0.4);
    const secondIns = Math.round(netRequired * 0.35);
    const thirdIns = netRequired - firstIns - secondIns;

    const newPlan: StudentFeePlan = {
      studentId: newId,
      academicYear: schoolInfo.currentYear,
      totalOriginal,
      totalDiscount: discountSum,
      netRequired,
      totalPaid: 0,
      remaining: netRequired,
      installments: [
        { id: `INS-${newId}-1`, title: 'القسط الأول (عند التسجيل)', dueDate: '2026-09-01', amount: firstIns, paidAmount: 0, status: 'متأخر' },
        { id: `INS-${newId}-2`, title: 'القسط الثاني (نوفمبر)', dueDate: '2026-11-01', amount: secondIns, paidAmount: 0, status: 'قادم' },
        { id: `INS-${newId}-3`, title: 'القسط الثالث (فبراير)', dueDate: '2027-02-15', amount: thirdIns, paidAmount: 0, status: 'قادم' }
      ]
    };

    setFeePlans(prev => [...prev, newPlan]);

    // Add to archive
    setArchiveDocs(prev => [
      {
        id: `DOC-REG-${newId}`,
        title: `ملف التحاق الطالب: ${studentData.fullName}`,
        category: 'ملفات طلاب',
        date: new Date().toISOString().split('T')[0],
        fileSize: '1.5 MB',
        referenceId: newId,
        fileName: `admission_${newId}.pdf`,
        notes: `تم التسجيل في الصف ${studentData.grade} شعبة ${studentData.section}`
      },
      ...prev
    ]);

    showToast(`تم تسجيل الطالب ${studentData.fullName} بنجاح برقم (${newId})`);
    return newStudent;
  };

  const updateStudent = (id: string, updates: Partial<Student>) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
    showToast('تم تحديث بيانات الطالب بنجاح');
  };

  const deleteStudent = (id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
    showToast('تم حذف سجل الطالب', 'info');
  };

  const transferStudent = (id: string, newGrade: string, newSection: string) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, grade: newGrade, section: newSection } : s));
    showToast('تم نقل الطالب إلى الصف والشعبة الجديدة بنجاح');
  };

  const setStudentStatus = (id: string, status: Student['status']) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    showToast(`تم تغيير حالة الطالب إلى "${status}"`);
  };

  // Fees actions
  const updateStudentFeePlan = (studentId: string, updates: Partial<StudentFeePlan>) => {
    setFeePlans(prev => prev.map(p => p.studentId === studentId ? { ...p, ...updates } : p));
  };

  const getStudentFeePlan = (studentId: string) => {
    return feePlans.find(p => p.studentId === studentId);
  };

  // Accounting & Vouchers
  const createVoucher = (data: Omit<Voucher, 'id' | 'voucherNumber' | 'amountInWords'>) => {
    const isReceipt = data.type === 'receipt';
    const nextNumber = vouchers.filter(v => v.type === data.type).length + 1001;
    const prefix = isReceipt ? 'REC-2026' : 'PAY-2026';
    const newId = `${prefix}-${String(nextNumber).padStart(4, '0')}`;
    const amountInWords = tafqeet(data.amount, 'ريال يمني');

    const newVoucher: Voucher = {
      ...data,
      id: newId,
      voucherNumber: nextNumber,
      amountInWords
    };

    setVouchers(prev => [newVoucher, ...prev]);

    // If it's a receipt for a student, update the student fee plan automatically
    if (isReceipt && data.studentId) {
      setFeePlans(prevPlans => {
        return prevPlans.map(plan => {
          if (plan.studentId !== data.studentId) return plan;

          const newTotalPaid = plan.totalPaid + data.amount;
          const newRemaining = Math.max(0, plan.netRequired - newTotalPaid);

          // update installments progressively
          let unallocated = data.amount;
          const updatedInstallments = plan.installments.map(inst => {
            if (inst.status === 'مسدد' || unallocated <= 0) return inst;
            const needed = inst.amount - inst.paidAmount;
            if (unallocated >= needed) {
              unallocated -= needed;
              return { ...inst, paidAmount: inst.amount, status: 'مسدد' as const };
            } else {
              const newPaid = inst.paidAmount + unallocated;
              unallocated = 0;
              return { ...inst, paidAmount: newPaid, status: 'جزئي' as const };
            }
          });

          return {
            ...plan,
            totalPaid: newTotalPaid,
            remaining: newRemaining,
            installments: updatedInstallments
          };
        });
      });
    }

    // Update Accounts
    setAccounts(prev => {
      return prev.map(acc => {
        if (isReceipt) {
          if (acc.name.includes('صندوق') || acc.name.includes('الخزينة')) {
            return { ...acc, balance: acc.balance + data.amount };
          }
          if (acc.name.includes('إيرادات الرسوم')) {
            return { ...acc, balance: acc.balance + data.amount };
          }
        } else {
          // Payment
          if (acc.name.includes('صندوق') || acc.name.includes('الخزينة')) {
            return { ...acc, balance: acc.balance - data.amount };
          }
          if (acc.name.includes('مصروفات')) {
            return { ...acc, balance: acc.balance + data.amount };
          }
        }
        return acc;
      });
    });

    showToast(`تم إصدار السند بنجاح برقم (${nextNumber})`);
    return newVoucher;
  };

  const deleteVoucher = (id: string) => {
    setVouchers(prev => prev.filter(v => v.id !== id));
    showToast('تم حذف السند وإلغاء القيد', 'info');
  };

  const updateAccountBalance = (code: string, newBalance: number) => {
    setAccounts(prev => prev.map(a => a.code === code ? { ...a, balance: newBalance } : a));
    showToast('تم تعديل رصيد الحساب');
  };

  // Staff
  const addEmployee = (emp: Omit<Employee, 'id'>) => {
    const nextId = `EMP-${String(employees.length + 1).padStart(3, '0')}`;
    const newEmp: Employee = { ...emp, id: nextId };
    setEmployees(prev => [...prev, newEmp]);
    showToast(`تمت إضافة الموظف ${emp.fullName} بنجاح`);
    return newEmp;
  };

  const updateEmployee = (id: string, updates: Partial<Employee>) => {
    setEmployees(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
    showToast('تم تحديث بيانات الموظف بنجاح');
  };

  const deleteEmployee = (id: string) => {
    setEmployees(prev => prev.filter(e => e.id !== id));
    showToast('تم حذف الموظف', 'info');
  };

  const disburseSalary = (empId: string, monthName: string) => {
    const emp = employees.find(e => e.id === empId);
    if (!emp) return;

    createVoucher({
      type: 'payment',
      date: new Date().toISOString().split('T')[0],
      amount: emp.netSalary,
      recipientOrPayer: `${emp.fullName} (${emp.role})`,
      category: 'رواتب وأجور الموظفين',
      paymentMethod: 'نقداً - الصندوق',
      accountFrom: 'صندوق الخزينة الرئيسي',
      accountTo: 'مصروفات رواتب المعلمين والإداريين',
      notes: `صرف الراتب الشهري لشهر ${monthName} متضمناً البدلات والخصميات`,
      preparedBy: 'عصام البعداني (المحاسب)'
    });

    showToast(`تم صرف راتب الموظف ${emp.fullName} بمبلغ ${emp.netSalary.toLocaleString()} ر.ي`);
  };

  // Timetable
  const addScheduleSlot = (slot: Omit<TeacherScheduleSlot, 'id'>) => {
    const newId = `SCH-${Date.now()}`;
    setScheduleSlots(prev => [...prev, { ...slot, id: newId }]);
    showToast('تمت إضافة الحصة للجدول المدرسي');
  };

  const deleteScheduleSlot = (id: string) => {
    setScheduleSlots(prev => prev.filter(s => s.id !== id));
    showToast('تم حذف الحصة من الجدول');
  };

  // Grades & Control
  const saveGrade = (gradeData: Omit<GradeRecord, 'id' | 'totalScore' | 'gradeLetter' | 'status'>) => {
    const total = gradeData.monthlyScore1 + gradeData.monthlyScore2 + gradeData.activitiesScore + gradeData.finalExamScore;
    let letter = 'ضعيف';
    let status: 'ناجح' | 'راسب' | 'مكمل' = 'راسب';

    if (total >= 90) letter = 'ممتاز';
    else if (total >= 80) letter = 'جيد جداً';
    else if (total >= 65) letter = 'جيد';
    else if (total >= 50) letter = 'مقبول';

    if (total >= 50) status = 'ناجح';

    const existingIndex = grades.findIndex(g => 
      g.studentId === gradeData.studentId && 
      g.subject === gradeData.subject && 
      g.term === gradeData.term
    );

    const newRecord: GradeRecord = {
      ...gradeData,
      id: existingIndex >= 0 ? grades[existingIndex].id : `GRD-${Date.now()}`,
      totalScore: total,
      gradeLetter: letter,
      status
    };

    if (existingIndex >= 0) {
      setGrades(prev => prev.map((g, i) => i === existingIndex ? newRecord : g));
    } else {
      setGrades(prev => [...prev, newRecord]);
    }

    showToast('تم رصد الدرجة بنجاح');
  };

  const getStudentGrades = (studentId: string) => {
    return grades.filter(g => g.studentId === studentId);
  };

  // Attendance
  const markAttendance = (record: Omit<AttendanceRecord, 'id'>) => {
    const existingIndex = attendance.findIndex(a => 
      a.date === record.date && 
      a.type === record.type && 
      a.targetId === record.targetId
    );

    const newRecord: AttendanceRecord = {
      ...record,
      id: existingIndex >= 0 ? attendance[existingIndex].id : `ATT-${Date.now()}`
    };

    if (existingIndex >= 0) {
      setAttendance(prev => prev.map((a, i) => i === existingIndex ? newRecord : a));
    } else {
      setAttendance(prev => [...prev, newRecord]);
    }
  };

  const markBatchAttendance = (
    date: string, 
    type: 'student' | 'employee', 
    items: { targetId: string; status: AttendanceRecord['status']; notes?: string; grade?: string; section?: string }[]
  ) => {
    setAttendance(prev => {
      const filtered = prev.filter(a => !(a.date === date && a.type === type && items.some(item => item.targetId === a.targetId)));
      const newItems: AttendanceRecord[] = items.map((item, idx) => ({
        id: `ATT-${Date.now()}-${idx}`,
        date,
        type,
        targetId: item.targetId,
        status: item.status,
        notes: item.notes,
        grade: item.grade,
        section: item.section
      }));
      return [...filtered, ...newItems];
    });

    showToast(`تم تسجيل الحضور والغياب لعدد (${items.length}) فرد بنجاح`);
  };

  // Library
  const borrowBook = (bookId: string, borrowerName: string, borrowerType: 'طالب' | 'معلم', days: number) => {
    setLibraryBooks(prev => prev.map(book => {
      if (book.id !== bookId) return book;
      if (book.copiesAvailable <= 0) return book;

      const borrowDate = new Date().toISOString().split('T')[0];
      const due = new Date();
      due.setDate(due.getDate() + days);
      const dueDate = due.toISOString().split('T')[0];

      const newLoan = {
        id: `LN-${Date.now()}`,
        borrowerName,
        borrowerType,
        borrowDate,
        dueDate,
        status: 'معار' as const
      };

      return {
        ...book,
        copiesAvailable: book.copiesAvailable - 1,
        loans: [newLoan, ...book.loans]
      };
    }));

    showToast(`تمت إعارة الكتاب للمستفيد ${borrowerName}`);
  };

  const returnBook = (bookId: string, loanId: string) => {
    setLibraryBooks(prev => prev.map(book => {
      if (book.id !== bookId) return book;

      const returnDate = new Date().toISOString().split('T')[0];
      const updatedLoans = book.loans.map(loan => {
        if (loan.id === loanId) {
          return { ...loan, returnDate, status: 'مسترجع' as const };
        }
        return loan;
      });

      return {
        ...book,
        copiesAvailable: book.copiesAvailable + 1,
        loans: updatedLoans
      };
    }));

    showToast('تم استرجاع الكتاب وإعادته للرف بنجاح');
  };

  const addBook = (book: Omit<LibraryBook, 'id' | 'loans'>) => {
    const newId = `BK-${String(libraryBooks.length + 1).padStart(3, '0')}`;
    setLibraryBooks(prev => [...prev, { ...book, id: newId, loans: [] }]);
    showToast(`تمت إضافة الكتاب "${book.title}" إلى المكتبة`);
  };

  // Inventory
  const addInventoryItem = (item: Omit<InventoryItem, 'id' | 'lastUpdated'>) => {
    const newId = `INV-${String(inventory.length + 1).padStart(2, '0')}`;
    setInventory(prev => [...prev, { ...item, id: newId, lastUpdated: new Date().toISOString().split('T')[0] }]);
    showToast(`تمت إضافة الصنف "${item.name}" إلى المخزن`);
  };

  const adjustStock = (id: string, change: number, notes?: string) => {
    setInventory(prev => prev.map(item => {
      if (item.id !== id) return item;
      const newQty = Math.max(0, item.quantity + change);
      return {
        ...item,
        quantity: newQty,
        lastUpdated: new Date().toISOString().split('T')[0]
      };
    }));
    showToast(change > 0 ? `تم توريد (+${change}) للصنف` : `تم صرف (${change}) من الصنف`);
  };

  // Notifications
  const sendNotification = (notif: Omit<SchoolNotification, 'id' | 'date'>) => {
    const newId = `NOT-${Date.now()}`;
    const newNotif: SchoolNotification = {
      ...notif,
      id: newId,
      date: new Date().toISOString().split('T')[0],
      status: 'مرسل'
    };
    setNotifications(prev => [newNotif, ...prev]);
    showToast(`تم إرسال الإشعار عبر ${notif.channel} بنجاح`);
  };

  // Archive
  const addArchiveDoc = (doc: Omit<ArchiveDocument, 'id' | 'date'>) => {
    const newId = `DOC-${Date.now()}`;
    setArchiveDocs(prev => [{ ...doc, id: newId, date: new Date().toISOString().split('T')[0] }, ...prev]);
    showToast(`تمت أرشفة الوثيقة "${doc.title}" بنجاح`);
  };

  const deleteArchiveDoc = (id: string) => {
    setArchiveDocs(prev => prev.filter(d => d.id !== id));
    showToast('تم حذف الوثيقة من الأرشيف');
  };

  // Print Modal
  const openPrintModal = (type: PrintPayload['type'], payload: any) => {
    setPrintModal({ isOpen: true, type, payload });
  };

  const closePrintModal = () => {
    setPrintModal(prev => ({ ...prev, isOpen: false }));
  };

  // Financial calculations
  const financialSummary = useMemo(() => {
    const totalRev = vouchers.filter(v => v.type === 'receipt').reduce((sum, v) => sum + v.amount, 0);
    const totalExp = vouchers.filter(v => v.type === 'payment').reduce((sum, v) => sum + v.amount, 0);
    const netProf = totalRev - totalExp;

    const cashAcc = accounts.find(a => a.name.includes('صندوق') || a.name.includes('الخزينة'));
    const bankAcc = accounts.filter(a => a.name.includes('بنك'));
    const bankSum = bankAcc.reduce((s, b) => s + b.balance, 0);

    const arrearsTotal = feePlans.reduce((sum, p) => sum + p.remaining, 0);

    return {
      totalRevenue: totalRev,
      totalExpenses: totalExp,
      netProfit: netProf,
      cashBalance: cashAcc ? cashAcc.balance : 0,
      bankBalance: bankSum,
      totalArrears: arrearsTotal
    };
  }, [vouchers, accounts, feePlans]);

  // Student summary
  const studentSummary = useMemo(() => {
    const total = students.length;
    const boys = students.filter(s => s.gender === 'ذكر').length;
    const girls = students.filter(s => s.gender === 'أنثى').length;
    const regular = students.filter(s => s.status === 'منتظم').length;
    const withArrears = feePlans.filter(p => p.remaining > 0).length;

    return {
      total,
      boys,
      girls,
      regular,
      withArrears
    };
  }, [students, feePlans]);

  // Backup & Reset
  const exportDatabaseToJson = () => {
    const dump = {
      exportDate: new Date().toISOString(),
      schoolInfo,
      students,
      feeItems,
      feePlans,
      vouchers,
      accounts,
      employees,
      scheduleSlots,
      grades,
      attendance,
      libraryBooks,
      inventory,
      notifications,
      archiveDocs
    };
    return JSON.stringify(dump, null, 2);
  };

  const importDatabaseFromJson = (jsonStr: string): boolean => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.schoolInfo) setSchoolInfo(data.schoolInfo);
      if (data.students) setStudents(data.students);
      if (data.feeItems) setFeeItems(data.feeItems);
      if (data.feePlans) setFeePlans(data.feePlans);
      if (data.vouchers) setVouchers(data.vouchers);
      if (data.accounts) setAccounts(data.accounts);
      if (data.employees) setEmployees(data.employees);
      if (data.scheduleSlots) setScheduleSlots(data.scheduleSlots);
      if (data.grades) setGrades(data.grades);
      if (data.attendance) setAttendance(data.attendance);
      if (data.libraryBooks) setLibraryBooks(data.libraryBooks);
      if (data.inventory) setInventory(data.inventory);
      if (data.notifications) setNotifications(data.notifications);
      if (data.archiveDocs) setArchiveDocs(data.archiveDocs);

      showToast('تم استيراد قاعدة البيانات بنجاح واستعادة السجلات');
      return true;
    } catch {
      showToast('خطأ في صيغة ملف النسخة الاحتياطية', 'error');
      return false;
    }
  };

  const resetDatabase = () => {
    setSchoolInfo(initialSchoolInfo);
    setStudents(initialStudents);
    setFeeItems(initialFeeItems);
    setFeePlans(initialFeePlans);
    setVouchers(initialVouchers);
    setAccounts(initialAccounts);
    setEmployees(initialEmployees);
    setScheduleSlots(initialScheduleSlots);
    setGrades(initialGrades);
    setAttendance(initialAttendance);
    setLibraryBooks(initialLibraryBooks);
    setInventory(initialInventory);
    setNotifications(initialNotifications);
    setArchiveDocs(initialArchive);
    showToast('تمت استعادة البيانات الافتراضية الأولية للنظام');
  };

  return (
    <SchoolContext.Provider
      value={{
        currentUser,
        isAuthenticated,
        login,
        logout,
        schoolInfo,
        updateSchoolInfo,
        currentRole,
        setCurrentRole,
        activeTab,
        setActiveTab,
        searchQuery,
        setSearchQuery,
        students,
        addStudent,
        updateStudent,
        deleteStudent,
        transferStudent,
        setStudentStatus,
        feeItems,
        feePlans,
        updateStudentFeePlan,
        getStudentFeePlan,
        vouchers,
        createVoucher,
        deleteVoucher,
        accounts,
        updateAccountBalance,
        employees,
        addEmployee,
        updateEmployee,
        deleteEmployee,
        disburseSalary,
        scheduleSlots,
        addScheduleSlot,
        deleteScheduleSlot,
        grades,
        saveGrade,
        getStudentGrades,
        attendance,
        markAttendance,
        markBatchAttendance,
        libraryBooks,
        borrowBook,
        returnBook,
        addBook,
        inventory,
        addInventoryItem,
        adjustStock,
        notifications,
        sendNotification,
        archiveDocs,
        addArchiveDoc,
        deleteArchiveDoc,
        printModal,
        openPrintModal,
        closePrintModal,
        toast,
        showToast,
        financialSummary,
        studentSummary,
        exportDatabaseToJson,
        importDatabaseFromJson,
        resetDatabase
      }}
    >
      {children}
    </SchoolContext.Provider>
  );
};

export const useSchool = () => {
  const ctx = useContext(SchoolContext);
  if (!ctx) throw new Error('useSchool must be used within SchoolProvider');
  return ctx;
};
