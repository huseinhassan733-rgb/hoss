import React, { useState } from 'react';
import { SchoolProvider, useSchool } from './context/SchoolContext';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { SidebarDrawer } from './components/layout/SidebarDrawer';
import { DashboardHome } from './components/modules/DashboardHome';
import { StudentsModule } from './components/modules/StudentsModule';
import { FeesModule } from './components/modules/FeesModule';
import { AccountingModule } from './components/modules/AccountingModule';
import { GradesControlModule } from './components/modules/GradesControlModule';
import { AttendanceModule } from './components/modules/AttendanceModule';
import { StaffModule } from './components/modules/StaffModule';
import { TeachersTimetableModule } from './components/modules/TeachersTimetableModule';
import { LibraryWarehouseModule } from './components/modules/LibraryWarehouseModule';
import { ArchiveMessagesModule } from './components/modules/ArchiveMessagesModule';
import { ReportsModule } from './components/modules/ReportsModule';
import { SettingsModule } from './components/modules/SettingsModule';
import { PrintModal } from './components/print/PrintModal';
import { LoginScreen } from './components/auth/LoginScreen';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

const SchoolAppContent: React.FC = () => {
  const { activeTab, setActiveTab, toast, currentRole, isAuthenticated } = useSchool();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Helper callbacks from dashboard
  const handleOpenRegisterStudent = () => {
    setActiveTab('students');
  };

  const handleOpenNewVoucher = (type: 'receipt' | 'payment') => {
    setActiveTab('accounting');
  };

  if (!isAuthenticated) {
    return (
      <>
        <LoginScreen />
        {toast.show && (
          <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-xl shadow-xl text-xs font-semibold animate-in fade-in slide-in-from-bottom-2 duration-200">
            {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
            {toast.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{toast.text}</span>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Cairo',sans-serif] selection:bg-emerald-500 selection:text-white">
      
      {/* Top App Bar with Branding & Role Switcher */}
      <Header onOpenMenu={() => setIsMenuOpen(true)} />

      {/* Main Layout Area: Sidebar (desktop) + Content Canvas */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        
        {/* Responsive Drawer / Sidebar */}
        <SidebarDrawer 
          isOpen={isMenuOpen} 
          onClose={() => setIsMenuOpen(false)} 
        />

        {/* Dynamic Content View */}
        <main className="flex-1 min-w-0 px-3 sm:px-6 py-4 sm:py-6">
          {activeTab === 'dashboard' && (
            <DashboardHome 
              onRegisterStudent={handleOpenRegisterStudent}
              onNewVoucher={handleOpenNewVoucher}
            />
          )}

          {activeTab === 'students' && <StudentsModule />}

          {activeTab === 'fees' && <FeesModule />}

          {activeTab === 'accounting' && <AccountingModule />}

          {activeTab === 'grades' && <GradesControlModule />}

          {activeTab === 'attendance' && <AttendanceModule />}

          {activeTab === 'staff' && <StaffModule />}

          {activeTab === 'teachers' && <TeachersTimetableModule />}

          {(activeTab === 'library' || activeTab === 'warehouse') && <LibraryWarehouseModule />}

          {(activeTab === 'archive' || activeTab === 'messages') && <ArchiveMessagesModule />}

          {activeTab === 'reports' && <ReportsModule />}

          {activeTab === 'settings' && <SettingsModule />}
        </main>
      </div>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <BottomNav onOpenMore={() => setIsMenuOpen(true)} />

      {/* Official Print Modal (Receipts, Student ID Cards, Certificates) */}
      <PrintModal />

      {/* Toast Notification Notification Pill */}
      {toast.show && (
        <div className="fixed bottom-16 sm:bottom-6 right-4 sm:right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-slate-900 text-white rounded-xl shadow-xl text-xs font-semibold animate-in fade-in slide-in-from-bottom-2 duration-200">
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
          {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
          {toast.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
          <span>{toast.text}</span>
        </div>
      )}

    </div>
  );
};

export default function App() {
  return (
    <SchoolProvider>
      <SchoolAppContent />
    </SchoolProvider>
  );
}
