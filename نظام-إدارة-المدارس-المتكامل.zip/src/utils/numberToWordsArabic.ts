/**
 * Arabic number to words converter for Yemeni Rial (YER) and accounting vouchers
 */

const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
const teens = ['عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
const hundreds = ['', 'مائة', 'مئتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];

function convertGroup(n: number): string {
  let output = '';
  const h = Math.floor(n / 100);
  const t = Math.floor((n % 100) / 10);
  const o = n % 10;

  if (h > 0) {
    output += hundreds[h];
  }

  const remainder = n % 100;
  if (remainder > 0) {
    if (output !== '') output += ' و ';

    if (remainder >= 10 && remainder <= 19) {
      output += teens[remainder - 10];
    } else {
      if (o > 0) {
        output += ones[o];
        if (t > 0) output += ' و ';
      }
      if (t > 0) {
        output += tens[t];
      }
    }
  }

  return output;
}

export function tafqeet(amount: number, currency: string = 'ريال يمني'): string {
  if (amount === 0) return `صفر ${currency} لا غير`;
  if (amount < 0) return 'قيمة سالبة';

  const integerPart = Math.floor(amount);

  const billions = Math.floor(integerPart / 1000000000);
  const millions = Math.floor((integerPart % 1000000000) / 1000000);
  const thousands = Math.floor((integerPart % 1000000) / 1000);
  const remaining = integerPart % 1000;

  const parts: string[] = [];

  if (billions > 0) {
    if (billions === 1) parts.push('مليار');
    else if (billions === 2) parts.push('ملياران');
    else if (billions >= 3 && billions <= 10) parts.push(`${convertGroup(billions)} مليارات`);
    else parts.push(`${convertGroup(billions)} مليار`);
  }

  if (millions > 0) {
    if (millions === 1) parts.push('مليون');
    else if (millions === 2) parts.push('مليونان');
    else if (millions >= 3 && millions <= 10) parts.push(`${convertGroup(millions)} ملايين`);
    else parts.push(`${convertGroup(millions)} مليون`);
  }

  if (thousands > 0) {
    if (thousands === 1) parts.push('ألف');
    else if (thousands === 2) parts.push('ألفان');
    else if (thousands >= 3 && thousands <= 10) parts.push(`${convertGroup(thousands)} آلاف`);
    else parts.push(`${convertGroup(thousands)} ألف`);
  }

  if (remaining > 0) {
    parts.push(convertGroup(remaining));
  }

  const words = parts.join(' و ');
  return `فقط ${words} ${currency} لا غير`;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('ar-YE', {
    style: 'decimal',
    maximumFractionDigits: 0,
  }).format(amount) + ' ر.ي';
}
